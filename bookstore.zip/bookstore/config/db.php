<?php
// ===================================================
// Konfigurasi koneksi database - KanzBooks
// Sesuaikan DB_USER / DB_PASS dengan setup MySQL Anda
// ===================================================
// Zona waktu WIB - dipakai PHP & MySQL supaya waktu membership/pesanan konsisten
date_default_timezone_set('Asia/Jakarta');

// Alamat toko (tampil di label pengiriman & invoice)
define('STORE_NAME', 'KanzBooks');
define('STORE_ADDRESS', 'Jl. Arabika VII No.9 Blok Y9, RT.10/RW.6, Pd. Kopi, Kec. Duren Sawit, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta 13460');

// QRIS statis toko (isi teks QR dari gambar assets/images/qris.jpg). Dari sini dibuat QRIS DINAMIS
// dengan nominal terkunci tiap pesanan (lihat includes/qris.php). Ganti kalau QRIS toko berubah.
define('QRIS_STATIC', '00020101021126570011ID.DANA.WWW011893600915303604802802090360480280303UMI51440014ID.CO.QRIS.WWW0215ID10266166890420303UMI5204737253033605802ID5922arkan naufal, Komputer6013Jakarta Timur610513460630465C5');
// Batas waktu bayar QRIS (menit). Lewat dari ini pesanan batal otomatis & stok dikembalikan.
define('QRIS_EXPIRE_MINUTES', 30);

// Batas pengajuan pengembalian barang: berapa hari sejak pesanan berstatus Selesai
define('RETURN_WINDOW_DAYS', 7);

define('DB_HOST', 'localhost');
define('DB_NAME', 'bookstore');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
    $pdo->exec("SET time_zone = '+07:00'");
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

define('BASE_URL', '/bookstore'); // ubah sesuai folder instalasi
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', BASE_URL . '/uploads/');
