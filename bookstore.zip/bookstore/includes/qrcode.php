<?php
// ===================================================
// Generator QR Code (PHP murni, tanpa library / internet) - mode byte, level koreksi L/M, versi 1-15.
// Dipakai untuk QRIS dinamis (nominal terkunci). Pakai: qr_svg($teks)
// ===================================================
const QR_RS_TABLE = [
    1 => ['L' => [1,26,19], 'M' => [1,26,16]],
    2 => ['L' => [1,44,34], 'M' => [1,44,28]],
    3 => ['L' => [1,70,55], 'M' => [1,70,44]],
    4 => ['L' => [1,100,80], 'M' => [2,50,32]],
    5 => ['L' => [1,134,108], 'M' => [2,67,43]],
    6 => ['L' => [2,86,68], 'M' => [4,43,27]],
    7 => ['L' => [2,98,78], 'M' => [4,49,31]],
    8 => ['L' => [2,121,97], 'M' => [2,60,38,2,61,39]],
    9 => ['L' => [2,146,116], 'M' => [3,58,36,2,59,37]],
    10 => ['L' => [2,86,68,2,87,69], 'M' => [4,69,43,1,70,44]],
    11 => ['L' => [4,101,81], 'M' => [1,80,50,4,81,51]],
    12 => ['L' => [2,116,92,2,117,93], 'M' => [6,58,36,2,59,37]],
    13 => ['L' => [4,133,107], 'M' => [8,59,37,1,60,38]],
    14 => ['L' => [3,145,115,1,146,116], 'M' => [4,64,40,5,65,41]],
    15 => ['L' => [5,109,87,1,110,88], 'M' => [5,65,41,5,66,42]],
];
const QR_ALIGN = [1 => [], 2 => [6,18], 3 => [6,22], 4 => [6,26], 5 => [6,30], 6 => [6,34], 7 => [6,22,38], 8 => [6,24,42],
    9 => [6,26,46], 10 => [6,28,50], 11 => [6,30,54], 12 => [6,32,58], 13 => [6,34,62], 14 => [6,26,46,66], 15 => [6,26,48,70]];

function qr_gf(){
    static $t = null;
    if ($t === null){
        $exp = []; $log = array_fill(0, 256, 0); $x = 1;
        for ($i = 0; $i < 255; $i++){ $exp[$i] = $x; $log[$x] = $i; $x <<= 1; if ($x & 0x100) $x ^= 0x11D; }
        for ($i = 255; $i < 512; $i++) $exp[$i] = $exp[$i - 255];
        $t = [$exp, $log];
    }
    return $t;
}

function qr_rs_blocks($version, $level){
    $row = QR_RS_TABLE[$version][$level]; $blocks = [];
    for ($i = 0; $i < count($row); $i += 3) for ($j = 0; $j < $row[$i]; $j++) $blocks[] = [$row[$i + 1], $row[$i + 2]];
    return $blocks;   // [total, data]
}

function qr_ecc($data, $ecCount){
    list($exp, $log) = qr_gf();
    $g = [1];
    for ($i = 0; $i < $ecCount; $i++){
        $n = array_fill(0, count($g) + 1, 0);
        foreach ($g as $k => $c){ $n[$k] ^= $c; $n[$k + 1] ^= ($c === 0) ? 0 : $exp[$log[$c] + $i]; }
        $g = $n;
    }
    $msg = array_merge($data, array_fill(0, $ecCount, 0));
    for ($i = 0; $i < count($data); $i++){
        $c = $msg[$i];
        if ($c !== 0) for ($j = 1; $j <= $ecCount; $j++) if ($g[$j] !== 0) $msg[$i + $j] ^= $exp[$log[$g[$j]] + $log[$c]];
    }
    return array_slice($msg, count($data));
}

function qr_bch_digit($d){ $n = 0; while ($d !== 0){ $n++; $d >>= 1; } return $n; }
function qr_bch_info($data){
    $g = 0x537; $d = $data << 10;
    while (qr_bch_digit($d) - qr_bch_digit($g) >= 0) $d ^= ($g << (qr_bch_digit($d) - qr_bch_digit($g)));
    return (($data << 10) | $d) ^ 0x5412;
}
function qr_bch_version($data){
    $g = 0x1F25; $d = $data << 12;
    while (qr_bch_digit($d) - qr_bch_digit($g) >= 0) $d ^= ($g << (qr_bch_digit($d) - qr_bch_digit($g)));
    return ($data << 12) | $d;
}

function qr_mask($m, $i, $j){
    switch ($m){
        case 0: return ($i + $j) % 2 === 0;
        case 1: return $i % 2 === 0;
        case 2: return $j % 3 === 0;
        case 3: return ($i + $j) % 3 === 0;
        case 4: return (intdiv($i, 2) + intdiv($j, 3)) % 2 === 0;
        case 5: return ($i * $j) % 2 + ($i * $j) % 3 === 0;
        case 6: return (($i * $j) % 2 + ($i * $j) % 3) % 2 === 0;
        default: return (($i * $j) % 3 + ($i + $j) % 2) % 2 === 0;
    }
}

function qr_codewords($bytes, $version, $level){
    $blocks = qr_rs_blocks($version, $level);
    $totalData = 0; foreach ($blocks as $b) $totalData += $b[1];
    $bits = []; $put = function($num, $len) use (&$bits){ for ($i = $len - 1; $i >= 0; $i--) $bits[] = ($num >> $i) & 1; };
    $put(4, 4); $put(count($bytes), $version < 10 ? 8 : 16);
    foreach ($bytes as $b) $put($b, 8);
    if (count($bits) > $totalData * 8) return null;
    for ($i = 0; $i < 4 && count($bits) < $totalData * 8; $i++) $bits[] = 0;
    while (count($bits) % 8 !== 0) $bits[] = 0;
    $cw = [];
    for ($i = 0; $i < count($bits); $i += 8){ $v = 0; for ($k = 0; $k < 8; $k++) $v = ($v << 1) | $bits[$i + $k]; $cw[] = $v; }
    for ($pad = 0; count($cw) < $totalData; $pad++) $cw[] = ($pad % 2 === 0) ? 0xEC : 0x11;

    $dc = []; $ec = []; $off = 0; $maxDc = 0; $maxEc = 0;
    foreach ($blocks as $r => $b){
        $dc[$r] = array_slice($cw, $off, $b[1]); $off += $b[1];
        $ec[$r] = qr_ecc($dc[$r], $b[0] - $b[1]);
        $maxDc = max($maxDc, $b[1]); $maxEc = max($maxEc, $b[0] - $b[1]);
    }
    $out = [];
    for ($i = 0; $i < $maxDc; $i++) foreach ($dc as $d) if ($i < count($d)) $out[] = $d[$i];
    for ($i = 0; $i < $maxEc; $i++) foreach ($ec as $e) if ($i < count($e)) $out[] = $e[$i];
    return $out;
}

function qr_build($data, $version, $levelBits, $mask, $test){
    $n = $version * 4 + 17;
    $m = array_fill(0, $n, array_fill(0, $n, null));
    foreach ([[0, 0], [$n - 7, 0], [0, $n - 7]] as $p){
        for ($r = -1; $r <= 7; $r++){
            if ($p[0] + $r <= -1 || $n <= $p[0] + $r) continue;
            for ($c = -1; $c <= 7; $c++){
                if ($p[1] + $c <= -1 || $n <= $p[1] + $c) continue;
                $m[$p[0] + $r][$p[1] + $c] = ($r >= 0 && $r <= 6 && ($c === 0 || $c === 6)) || ($c >= 0 && $c <= 6 && ($r === 0 || $r === 6)) || ($r >= 2 && $r <= 4 && $c >= 2 && $c <= 4);
            }
        }
    }
    $pos = QR_ALIGN[$version];
    foreach ($pos as $row) foreach ($pos as $col){
        if ($m[$row][$col] !== null) continue;
        for ($r = -2; $r <= 2; $r++) for ($c = -2; $c <= 2; $c++) $m[$row + $r][$col + $c] = (abs($r) === 2 || abs($c) === 2 || ($r === 0 && $c === 0));
    }
    for ($i = 8; $i < $n - 8; $i++){
        if ($m[$i][6] === null) $m[$i][6] = ($i % 2 === 0);
        if ($m[6][$i] === null) $m[6][$i] = ($i % 2 === 0);
    }
    $bits = qr_bch_info(($levelBits << 3) | $mask);
    for ($i = 0; $i < 15; $i++){
        $mod = !$test && ((($bits >> $i) & 1) === 1);
        if ($i < 6) $m[$i][8] = $mod; elseif ($i < 8) $m[$i + 1][8] = $mod; else $m[$n - 15 + $i][8] = $mod;
        if ($i < 8) $m[8][$n - $i - 1] = $mod; elseif ($i < 9) $m[8][15 - $i - 1 + 1] = $mod; else $m[8][15 - $i - 1] = $mod;
    }
    $m[$n - 8][8] = !$test;
    if ($version >= 7){
        $bits = qr_bch_version($version);
        for ($i = 0; $i < 18; $i++){
            $mod = !$test && ((($bits >> $i) & 1) === 1);
            $m[intdiv($i, 3)][$i % 3 + $n - 8 - 3] = $mod;
            $m[$i % 3 + $n - 8 - 3][intdiv($i, 3)] = $mod;
        }
    }
    $inc = -1; $row = $n - 1; $bitIndex = 7; $byteIndex = 0; $len = count($data);
    for ($col = $n - 1; $col > 0; $col -= 2){
        if ($col === 6) $col--;
        while (true){
            for ($c = 0; $c < 2; $c++){
                if ($m[$row][$col - $c] === null){
                    $dark = false;
                    if ($byteIndex < $len) $dark = ((($data[$byteIndex] >> $bitIndex) & 1) === 1);
                    if (qr_mask($mask, $row, $col - $c)) $dark = !$dark;
                    $m[$row][$col - $c] = $dark;
                    $bitIndex--;
                    if ($bitIndex === -1){ $byteIndex++; $bitIndex = 7; }
                }
            }
            $row += $inc;
            if ($row < 0 || $n <= $row){ $row -= $inc; $inc = -$inc; break; }
        }
    }
    return $m;
}

function qr_penalty($m){
    $n = count($m); $pen = 0; $dark = 0;
    for ($i = 0; $i < $n; $i++){
        foreach ([0, 1] as $dir){
            $run = 1;
            for ($j = 1; $j < $n; $j++){
                $a = $dir ? $m[$j][$i] : $m[$i][$j]; $b = $dir ? $m[$j - 1][$i] : $m[$i][$j - 1];
                if ($a === $b){ $run++; if ($run === 5) $pen += 3; elseif ($run > 5) $pen++; } else $run = 1;
            }
        }
        for ($j = 0; $j < $n; $j++){
            if ($m[$i][$j]) $dark++;
            if ($i < $n - 1 && $j < $n - 1 && $m[$i][$j] === $m[$i][$j + 1] && $m[$i][$j] === $m[$i + 1][$j] && $m[$i][$j] === $m[$i + 1][$j + 1]) $pen += 3;
        }
    }
    $pen += (int) (abs($dark * 100 / ($n * $n) - 50) / 5) * 10;
    return $pen;
}

// Matriks QR (array 2D boolean) dari teks. null kalau teks terlalu panjang.
function qr_matrix($text){
    $bytes = array_values(unpack('C*', $text));
    foreach (['M' => 0, 'L' => 1] as $level => $levelBits){
        for ($v = 1; $v <= 15; $v++){
            $cw = qr_codewords($bytes, $v, $level);
            if ($cw === null) continue;
            $best = null; $bestPen = PHP_INT_MAX;
            for ($mask = 0; $mask < 8; $mask++){
                $m = qr_build($cw, $v, $levelBits, $mask, false);
                $p = qr_penalty($m);
                if ($p < $bestPen){ $bestPen = $p; $best = $m; }
            }
            return $best;
        }
    }
    return null;
}

// SVG siap tampil (zona tenang 4 modul)
function qr_svg($text, $size = 280){
    $m = qr_matrix($text);
    if ($m === null) return '';
    $n = count($m); $q = 4; $d = '';
    for ($r = 0; $r < $n; $r++){
        for ($c = 0; $c < $n; $c++){
            if (!$m[$r][$c]) continue;
            $len = 1; while ($c + $len < $n && $m[$r][$c + $len]) $len++;
            $d .= 'M' . ($c + $q) . ' ' . ($r + $q) . 'h' . $len . 'v1h-' . $len . 'z';
            $c += $len - 1;
        }
    }
    $t = $n + 2 * $q;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $t . ' ' . $t . '" width="' . (int) $size . '" height="' . (int) $size . '" shape-rendering="crispEdges" role="img" aria-label="QRIS"><rect width="' . $t . '" height="' . $t . '" fill="#fff"/><path d="' . $d . '" fill="#000"/></svg>';
}
