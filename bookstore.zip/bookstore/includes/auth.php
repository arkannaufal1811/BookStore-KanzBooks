<?php
session_start();
require_once __DIR__ . '/../config/db.php';

function is_logged_in(){
    return isset($_SESSION['user_id']);
}

function current_user(){
    if (!is_logged_in()) return null;
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'role' => $_SESSION['user_role'],
    ];
}

function is_admin(){
    return is_logged_in() && $_SESSION['user_role'] === 'admin';
}

function require_login($redirect = '/user/login.php'){
    if (!is_logged_in()){
        header("Location: " . BASE_URL . $redirect);
        exit;
    }
}

function require_admin(){
    if (!is_logged_in() || $_SESSION['user_role'] !== 'admin'){
        header("Location: " . BASE_URL . (is_logged_in() ? "/user/index.php" : "/user/login.php"));   // bukan admin: ke toko; belum login: ke halaman login
        exit;
    }
}

function rupiah($num){
    return "Rp " . number_format($num, 0, ',', '.');
}

// Jumlah buku terjual per buku (semua pesanan kecuali Dibatalkan dan Dikembalikan, sama seperti laporan admin)
function sold_counts($pdo){
    static $map = null;
    if ($map !== null) return $map;
    $map = [];
    try {
        $paidOnly = db_has_column($pdo, 'orders', 'pay_status') ? " AND (o.pay_status IS NULL OR o.pay_status = 'dibayar')" : '';   // QRIS yang belum dibayar belum dihitung terjual
        $rows = $pdo->query("SELECT oi.book_id, SUM(oi.qty) AS n FROM order_items oi JOIN orders o ON o.id = oi.order_id AND o.status NOT IN ('Dibatalkan','Dikembalikan')$paidOnly GROUP BY oi.book_id")->fetchAll();
        foreach ($rows as $r){ $map[(int)$r['book_id']] = (int)$r['n']; }
    } catch (Throwable $e) {}
    return $map;
}
function sold_label($pdo, $bookId){
    $n = sold_counts($pdo)[(int)$bookId] ?? 0;
    return ' · <span class="sold">Terjual ' . number_format($n, 0, ',', '.') . '</span>';
}

function cart_count($pdo){
    if (!is_logged_in()) return 0;
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(qty),0) AS c FROM cart_items WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return (int) $stmt->fetch()['c'];
}

function wishlist_count($pdo){
    if (!is_logged_in()) return 0;
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM wishlists WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return (int) $stmt->fetch()['c'];
}

function is_wishlisted($pdo, $bookId){
    if (!is_logged_in()) return false;
    $stmt = $pdo->prepare("SELECT id FROM wishlists WHERE user_id = ? AND book_id = ?");
    $stmt->execute([$_SESSION['user_id'], $bookId]);
    return (bool) $stmt->fetch();
}

function active_membership($pdo){
    if (!is_logged_in()) return null;
    try {
        $stmt = $pdo->prepare("SELECT * FROM memberships WHERE user_id = ? AND status = 'active' AND expires_at > NOW() ORDER BY expires_at DESC LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch() ?: null;
    } catch (PDOException $e) {
        return null; // tabel memberships belum ada (migration_v5 belum dijalankan)
    }
}

function pending_membership($pdo){
    if (!is_logged_in()) return null;
    try {
        $stmt = $pdo->prepare("SELECT * FROM memberships WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch() ?: null;
    } catch (PDOException $e) {
        return null; // tabel memberships belum ada (migration_v5 belum dijalankan)
    }
}

function is_member_user($pdo){
    return active_membership($pdo) !== null;
}

// ---------------------------------------------------------------
// BENEFIT TIAP PAKET - ubah angka di sini, semua halaman ikut berubah
//   discount    = diskon member (%) untuk buku harga normal
//   ship_min    = minimal belanja (setelah diskon) biar gratis ongkir; 0 = tanpa minimal
//   points_mult = pengali poin (dasar: 1 poin tiap Rp10.000 yang dibayar)
//   early_menit = akses early sale: masuk War Buku sekian menit sebelum dibuka umum; 0 = tidak dapat
// ---------------------------------------------------------------
function membership_plans(){
    return [
        'mingguan' => ['label' => 'Mingguan', 'price' => 15000,  'days' => 7,   'desc' => 'Cocok buat nyoba dulu',
                       'discount' => 15, 'ship_min' => 50000, 'points_mult' => 1,   'early_menit' => 0],
        'bulanan'  => ['label' => 'Bulanan',  'price' => 49000,  'days' => 30,  'desc' => 'Paling populer', 'popular' => true,
                       'discount' => 30, 'ship_min' => 0,     'points_mult' => 1.5, 'early_menit' => 30],
        'tahunan'  => ['label' => 'Tahunan',  'price' => 499000, 'days' => 365, 'desc' => 'Hemat sampai 15%',
                       'discount' => 50, 'ship_min' => 0,     'points_mult' => 2,   'early_menit' => 120],
    ];
}

// Benefit paket member yang lagi aktif (null kalau bukan member)
function member_perks($pdo){
    $m = active_membership($pdo);
    if (!$m) return null;
    $plans = membership_plans();
    return $plans[$m['plan']] ?? $plans['mingguan'];
}

// Ongkir sesuai paket: member gratis kalau belanja >= ship_min paket, non-member gratis kalau >= 150.000
function shipping_cost($perks, $amount){
    if ($amount >= 150000) return 0;
    if ($perks && $amount >= $perks['ship_min']) return 0;
    return 15000;
}

function points_for_total($perks, $total){
    if (!$perks) return 0;
    return (int) floor(($total / 10000) * $perks['points_mult']);
}

// Daftar benefit satu paket untuk ditampilkan: [teks, aktif?]
function plan_perk_lines($p){
    $ship = $p['ship_min'] > 0 ? 'Gratis ongkir min. belanja ' . rupiah($p['ship_min']) : 'Gratis ongkir tanpa minimal belanja';
    $pts  = 'Poin reward ' . rtrim(rtrim(number_format($p['points_mult'], 1, ',', ''), '0'), ',') . 'x';
    $early = $p['early_menit'] > 0
        ? 'Early sale War Buku ' . ($p['early_menit'] >= 60 ? ($p['early_menit'] / 60) . ' jam' : $p['early_menit'] . ' menit') . ' lebih awal'
        : 'Akses early sale';
    return [
        ['Diskon ' . $p['discount'] . '% semua buku', true],
        [$ship, true],
        [$pts, true],
        [$early, $p['early_menit'] > 0],
    ];
}

function user_points($pdo){
    if (!is_logged_in()) return 0;
    $stmt = $pdo->prepare("SELECT points FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $row = $stmt->fetch();
    return $row ? (int) $row['points'] : 0;
}

function book_rating($pdo, $book){
    // Pakai rata-rata dari review asli kalau ada, kalau belum ada review fallback ke rating statis buku
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c, COALESCE(AVG(rating),0) AS avg_r FROM reviews WHERE book_id = ?");
    $stmt->execute([$book['id']]);
    $r = $stmt->fetch();
    if ($r['c'] > 0){
        return ['rating' => round($r['avg_r'], 1), 'count' => (int)$r['c']];
    }
    return ['rating' => $book['rating'], 'count' => 0];
}

function h($str){
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// ===================================================
// "Ingatkan Saya" (Remember Me) - login otomatis 30 hari
// Token disimpan di tabel remember_tokens (jalankan database/migration_v7.sql).
// Kalau tabel belum ada, fitur ini dilewati dan login biasa tetap jalan.
// ===================================================
define('REMEMBER_COOKIE', 'remember_me');
define('REMEMBER_DAYS', 30);

function remember_cookie_set($value, $expires){
    setcookie(REMEMBER_COOKIE, $value, [
        'expires'  => $expires,
        'path'     => (BASE_URL === '' ? '/' : BASE_URL . '/'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function remember_issue($pdo, $userId){
    try {
        $selector  = bin2hex(random_bytes(9));
        $validator = bin2hex(random_bytes(32));
        $expires   = time() + 60 * 60 * 24 * REMEMBER_DAYS;
        $pdo->prepare("INSERT INTO remember_tokens (user_id, selector, token_hash, expires_at) VALUES (?, ?, ?, ?)")
            ->execute([$userId, $selector, hash('sha256', $validator), date('Y-m-d H:i:s', $expires)]);
        remember_cookie_set($selector . ':' . $validator, $expires);
    } catch (Throwable $e) {
        // tabel belum ada / error lain -> abaikan, login tetap berhasil
    }
}

function remember_forget($pdo){
    if (empty($_COOKIE[REMEMBER_COOKIE])) return;
    $parts = explode(':', $_COOKIE[REMEMBER_COOKIE], 2);
    try {
        $pdo->prepare("DELETE FROM remember_tokens WHERE selector = ?")->execute([$parts[0]]);
    } catch (Throwable $e) {}
    remember_cookie_set('', time() - 3600);
}

function remember_autologin($pdo){
    $parts = explode(':', $_COOKIE[REMEMBER_COOKIE] ?? '', 2);
    if (count($parts) !== 2) return;
    try {
        $stmt = $pdo->prepare("SELECT rt.*, u.name, u.email, u.role FROM remember_tokens rt JOIN users u ON u.id = rt.user_id WHERE rt.selector = ? AND rt.expires_at > NOW() LIMIT 1");
        $stmt->execute([$parts[0]]);
        $row = $stmt->fetch();
        if ($row && hash_equals($row['token_hash'], hash('sha256', $parts[1]))){
            session_regenerate_id(true);
            $_SESSION['user_id']    = $row['user_id'];
            $_SESSION['user_name']  = $row['name'];
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['user_role']  = $row['role'];
            // ganti token lama dengan yang baru (rotasi)
            $pdo->prepare("DELETE FROM remember_tokens WHERE id = ?")->execute([$row['id']]);
            remember_issue($pdo, $row['user_id']);
        } else {
            remember_cookie_set('', time() - 3600);
        }
    } catch (Throwable $e) {}
}

if (!is_logged_in() && !empty($_COOKIE[REMEMBER_COOKIE])){
    remember_autologin($pdo);
}

// ===================================================
// Cadangan gambar bukti transfer di DATABASE (anti hilang)
// Setiap bukti yang diupload disalin ke tabel upload_backups.
// Kalau file di folder uploads/ hilang (misal folder tertimpa saat update project),
// file otomatis dipulihkan dari database saat halaman dibuka.
// Butuh tabel dari database/migration_v8.sql (kalau belum ada, fitur dilewati).
// ===================================================
function upload_backup_save($pdo, $name){
    $name = basename((string) $name);
    $path = UPLOAD_DIR . $name;
    if ($name === '' || !is_file($path) || filesize($path) > 8 * 1024 * 1024) return false;
    try {
        $mime = function_exists('mime_content_type') ? (mime_content_type($path) ?: 'application/octet-stream') : 'application/octet-stream';
        $stmt = $pdo->prepare("REPLACE INTO upload_backups (filename, mime, data) VALUES (?, ?, ?)");
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $mime);
        $stmt->bindValue(3, file_get_contents($path), PDO::PARAM_LOB);
        $stmt->execute();
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

// Pastikan file ada: kalau ada -> pastikan sudah dicadangkan; kalau hilang -> pulihkan dari database.
function upload_ensure($pdo, $name){
    if (!$name) return false;
    $name = basename((string) $name);
    $path = UPLOAD_DIR . $name;
    static $saved = null;

    if (is_file($path)){
        if ($saved === null){
            try {
                $saved = array_flip($pdo->query("SELECT filename FROM upload_backups")->fetchAll(PDO::FETCH_COLUMN));
            } catch (Throwable $e) {
                $saved = false; // tabel belum ada
            }
        }
        if ($saved !== false && !isset($saved[$name]) && upload_backup_save($pdo, $name)){
            $saved[$name] = 1;
        }
        return true;
    }

    try {
        $stmt = $pdo->prepare("SELECT data FROM upload_backups WHERE filename = ?");
        $stmt->execute([$name]);
        $row = $stmt->fetch();
        if ($row){
            if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0777, true);
            return @file_put_contents($path, $row['data']) !== false;
        }
    } catch (Throwable $e) {}
    return false;
}

// ===================================================
// Penghitung waktu membership (hitung mundur langsung)
// $m = hasil active_membership(); $dark = true kalau tampil di atas latar ungu
// ===================================================
function membership_countdown($m, $dark = false){
    if (!$m || empty($m['expires_at'])) return '';
    $remaining = strtotime($m['expires_at']) - time();
    static $scriptPrinted = false;
    $box = $dark
        ? 'background:rgba(255,255,255,.18); color:#fff; border:1px solid rgba(255,255,255,.35);'
        : 'background:#fff; color:#333; border:1.5px solid var(--primary);';
    $html  = '<div class="mcd" data-remaining="' . max(0, (int) $remaining) . '" style="' . $box . ' border-radius:12px; padding:12px 16px; margin:0 0 16px; display:inline-block; min-width:260px;">';
    $html .= '<div style="font-size:12.5px; opacity:.9;">⏳ Sisa waktu membership</div>';
    $html .= '<div class="mcd-time" style="font-size:20px; font-weight:800; letter-spacing:.3px; margin:2px 0;">--</div>';
    $html .= '<div style="font-size:12px; opacity:.9;">Berakhir: ' . date('d M Y, H:i', strtotime($m['expires_at'])) . '</div>';
    $html .= '<div class="mcd-warn" style="font-size:12px; font-weight:700; margin-top:4px; display:none;">⚠️ Segera perpanjang supaya benefit member tidak hilang</div>';
    $html .= '</div>';
    if (!$scriptPrinted){
        $scriptPrinted = true;
        $html .= '<script>
        (function(){
          var boxes = document.querySelectorAll(".mcd");
          var start = Date.now();
          function pad(n){ return n < 10 ? "0" + n : n; }
          function tick(){
            boxes.forEach(function(b){
              var left = parseInt(b.getAttribute("data-remaining"), 10) - Math.floor((Date.now() - start) / 1000);
              var t = b.querySelector(".mcd-time"), w = b.querySelector(".mcd-warn");
              if (left <= 0){ t.textContent = "Membership sudah berakhir"; w.style.display = "none"; return; }
              var d = Math.floor(left / 86400), h = Math.floor(left % 86400 / 3600), m = Math.floor(left % 3600 / 60), s = left % 60;
              t.textContent = (d > 0 ? d + " hari " : "") + pad(h) + " : " + pad(m) + " : " + pad(s);
              w.style.display = left < 3 * 86400 ? "block" : "none";
            });
          }
          tick(); setInterval(tick, 1000);
        })();
        </script>';
    }
    return $html;
}

// ===================================================
// Helper nomor HP & cek kolom (supaya aman walau migration_v9 belum dijalankan)
// ===================================================
function db_has_column($pdo, $table, $column){
    static $cache = [];
    $key = $table . '.' . $column;
    if (!isset($cache[$key])){
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
            $stmt->execute([$table, $column]);
            $cache[$key] = ((int) $stmt->fetchColumn()) > 0;
        } catch (Throwable $e) {
            $cache[$key] = false;
        }
    }
    return $cache[$key];
}

// Normalisasi nomor HP Indonesia -> 08xxxxxxxxxx ; return false kalau tidak valid
function normalize_phone($raw){
    $d = preg_replace('/\D+/', '', (string) $raw);
    if (strpos($d, '62') === 0) $d = '0' . substr($d, 2);
    elseif (strpos($d, '8') === 0) $d = '0' . $d;
    return preg_match('/^08[0-9]{8,12}$/', $d) ? $d : false;
}

// ===================================================
// Generator nomor resi otomatis (contoh) - format berbeda tiap kurir
// CATATAN: nomor ini dibuat sistem, BUKAN resi asli dari kurir (tidak bisa dilacak di kurir).
// ===================================================
function generate_resi($pdo, $courier, $orderId){
    $digits = function($n){ $s = ''; for ($i = 0; $i < $n; $i++) $s .= random_int(0, 9); return $s; };
    $r = '';
    for ($try = 0; $try < 10; $try++){
        switch ($courier){
            case 'JNE':                  $r = $digits(16); break;
            case 'J&T Express':          $r = 'JP' . $digits(10); break;
            case 'SiCepat':              $r = '00' . $digits(10); break;
            case 'AnterAja':             $r = '10' . $digits(10); break;
            case 'Pos Indonesia':        $r = 'P' . $digits(12); break;
            case 'Ninja Xpress':         $r = 'NLIDAP' . $digits(10); break;
            case 'Gojek / Grab Instant': $r = 'INS' . date('ymd') . $digits(4); break;
            case 'Kurir Toko':           return 'KT-' . date('Ymd') . '-' . str_pad((int) $orderId, 5, '0', STR_PAD_LEFT);
            default: return '';
        }
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE tracking_no = ? AND id <> ?");
            $stmt->execute([$r, (int) $orderId]);
            if ((int) $stmt->fetchColumn() === 0) return $r;
        } catch (Throwable $e) { return $r; }
    }
    return $r;
}

// ===================================================
// Pembatalan pesanan (butuh database/migration_v10.sql)
// cancel_status: NULL | diajukan (user minta) | disetujui | ditolak | admin (dibatalkan langsung admin)
// ===================================================
function cancel_ready($pdo){
    return db_has_column($pdo, 'orders', 'cancel_status');
}

// Batalkan pesanan: status -> Dibatalkan, stok buku dikembalikan, poin member ditarik lagi.
// Hanya bisa saat status Baru / Diproses. Aman dipanggil dua kali (yang kedua ditolak, stok tidak dobel).
function cancel_order($pdo, $orderId, $cancelStatus, $reason, $note = ''){
    $own = !$pdo->inTransaction();
    try {
        if ($own) $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? FOR UPDATE");
        $stmt->execute([(int) $orderId]);
        $o = $stmt->fetch();
        if (!$o) throw new Exception('Pesanan tidak ditemukan.');
        if (!in_array($o['status'], ['Baru', 'Diproses'], true)){
            throw new Exception($o['status'] === 'Dibatalkan' ? 'Pesanan ini sudah dibatalkan.' : 'Pesanan berstatus ' . $o['status'] . ' tidak bisa dibatalkan lagi.');
        }
        $items = $pdo->prepare("SELECT book_id, qty, price FROM order_items WHERE order_id = ?");
        $items->execute([(int) $orderId]);
        $subtotal = 0;
        foreach ($items->fetchAll() as $it){
            restock_item($pdo, $o, $it['book_id'], $it['qty']);
            $subtotal += $it['price'] * $it['qty'];
        }
        // Tarik lagi poin yang didapat pesanan ini (pakai catatan poin pesanan; pesanan lama tanpa catatan dihitung dari total)
        $total = (float) $o['total'];
        $pts = refund_points_for_order($o, $subtotal);
        if ($pts > 0) $pdo->prepare("UPDATE users SET points = GREATEST(points - ?, 0) WHERE id = ?")->execute([$pts, $o['user_id']]);
        $pdo->prepare("UPDATE orders SET status = 'Dibatalkan', cancel_status = ?, cancel_reason = ?, cancel_note = ?, cancelled_at = NOW() WHERE id = ?")
            ->execute([$cancelStatus, mb_substr_safe($reason, 255), $note !== '' ? mb_substr_safe($note, 255) : null, (int) $orderId]);
        if ($own) $pdo->commit();
        chat_auto($pdo, $o['user_id'], $orderId, 'dibatalkan', $note !== '' ? $note : $reason);
        return [true, 'ok'];
    } catch (Throwable $e) {
        if ($own && $pdo->inTransaction()) $pdo->rollBack();
        return [false, $e->getMessage()];
    }
}

// Poin yang harus ditarik lagi saat pesanan dibatalkan / diretur.
// Pesanan baru menyimpan poin yang didapat di kolom points_earned (migration_v15).
// Pesanan lama (kolom kosong): dihitung dari total seperti aturan lama (member = bukan harga normal / harga normal + ongkir).
function refund_points_for_order($o, $subtotal){
    if (array_key_exists('points_earned', $o) && $o['points_earned'] !== null) return (int) $o['points_earned'];
    $total = (float) $o['total'];
    $nonMember = abs($total - ($subtotal + 15000)) < 0.5 || abs($total - $subtotal) < 0.5;
    return $nonMember ? 0 : (int) floor($total / 10000);
}

function mb_substr_safe($s, $len){
    $s = (string) $s;
    if (strlen($s) <= $len) return $s;
    return preg_match('/^.{1,' . $len . '}/us', $s, $m) ? $m[0] : substr($s, 0, $len);
}

// ===================================================
// CSRF token sederhana (dipakai form aksi admin: membership, dll)
// ===================================================
function csrf_token(){
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(){
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}
function csrf_valid(){
    return !empty($_SESSION['csrf']) && isset($_POST['csrf']) && hash_equals($_SESSION['csrf'], (string) $_POST['csrf']);
}

// ===================================================
// Membership: status efektif, label, dan sinkron flag is_member (butuh migration_v11.sql untuk catatan & batal)
// ===================================================
function membership_ready($pdo){
    return db_has_column($pdo, 'memberships', 'admin_note') && db_has_column($pdo, 'memberships', 'cancelled_at');
}

// 'active' yang tanggalnya sudah lewat dianggap 'expired' (kolom status di DB tidak otomatis berubah)
function membership_effective_status($m){
    if (($m['status'] ?? '') === 'active' && !empty($m['expires_at']) && strtotime($m['expires_at']) <= time()) return 'expired';
    return $m['status'] ?? '';
}

function membership_status_label($status){
    return ['pending' => 'Menunggu', 'active' => 'Aktif', 'expired' => 'Kedaluwarsa', 'rejected' => 'Ditolak', 'cancelled' => 'Dibatalkan'][$status] ?? ucfirst((string) $status);
}

function membership_badge_class($status){
    return match($status){
        'pending' => 'badge-minta',
        'active' => 'badge-selesai',
        'expired' => 'badge-dikirim',
        'rejected', 'cancelled' => 'badge-batal',
        default => ''
    };
}

// Samakan users.is_member dengan ada/tidaknya membership yang masih berlaku
function membership_sync_flag($pdo, $userId){
    $st = $pdo->prepare("SELECT COUNT(*) FROM memberships WHERE user_id = ? AND status = 'active' AND expires_at > NOW()");
    $st->execute([$userId]);
    $pdo->prepare("UPDATE users SET is_member = ? WHERE id = ?")->execute([((int) $st->fetchColumn() > 0) ? 1 : 0, $userId]);
}

// ===================================================
// Alur pesanan, "Pesanan Diterima", dan pengembalian barang (butuh database/migration_v12.sql)
// Status maju SATU ARAH: Baru > Diproses > Dikirim > Selesai. Selesai / Dibatalkan / Dikembalikan = final.
// return_status: NULL | diajukan (user minta) | disetujui (status jadi Dikembalikan) | ditolak
// Batas memilih "Selesai" atau "Pengembalian" = RETURN_WINDOW_DAYS hari sejak barang DITERIMA (received_at, config/db.php).
// Setelah pembeli menekan Selesai (atau 7 hari lewat = otomatis Selesai) pesanan ditutup, tidak bisa dikembalikan lagi.
// ===================================================
function return_ready($pdo){
    return db_has_column($pdo, 'orders', 'return_status') && db_has_column($pdo, 'orders', 'completed_at')
        && db_has_column($pdo, 'orders', 'received_at') && db_has_column($pdo, 'orders', 'return_proof_resi');   // butuh migration_v17.sql
}

// Langkah berikutnya yang boleh diambil admin (null = status sudah final)
function order_next_status($status){
    return ['Baru' => 'Diproses', 'Diproses' => 'Dikirim', 'Dikirim' => 'Selesai'][$status] ?? null;
}

// Admin memajukan status ke langkah berikutnya. Mundur / loncat ditolak. Return [ok, pesan]
function advance_order_status($pdo, $orderId, $newStatus){
    $st = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $st->execute([(int) $orderId]);
    $o = $st->fetch();
    if (!$o) return [false, 'Pesanan tidak ditemukan.'];
    $next = order_next_status($o['status']);
    if ($next === null) return [false, 'Status ' . $o['status'] . ' sudah final dan tidak bisa diubah lagi.'];
    if ($newStatus !== $next) return [false, 'Status hanya bisa maju ke langkah berikutnya, yaitu ' . $next . '.'];
    if ($next === 'Diproses' && ($o['pay_status'] ?? '') === 'menunggu'){
        return [false, 'Pembayaran QRIS belum dikonfirmasi. Cek dana masuk, lalu tekan "Pembayaran Diterima" dulu.'];
    }
    if (($o['cancel_status'] ?? '') === 'diajukan' && in_array($next, ['Dikirim', 'Selesai'], true)){
        return [false, 'Ada pengajuan pembatalan dari pembeli. Setujui atau tolak dulu sebelum pesanan dikirim.'];
    }
    if ($next === 'Selesai' && ($o['return_status'] ?? '') === 'diajukan'){
        return [false, 'Pembeli sedang mengajukan retur. Setujui atau tolak dulu di panel Pengembalian Barang.'];
    }
    if ($next === 'Dikirim' && db_has_column($pdo, 'orders', 'courier') && (empty($o['courier']) || empty($o['tracking_no']))){
        return [false, 'Isi kurir dan nomor resi dulu (kotak Info Pengiriman) sebelum status Dikirim.'];
    }
    // Admin menandai barang sudah diterima: sama seperti pembeli menekan "Pesanan Diterima".
    // Status tetap Dikirim; pembeli yang memilih Selesai atau Pengembalian Dana dan Barang.
    if ($next === 'Selesai'){
        if (!empty($o['received_at'])) return [false, 'Pesanan sudah ditandai diterima. Tinggal menunggu pembeli memilih Selesai atau Pengembalian.'];
        $rcv = $pdo->prepare("UPDATE orders SET received_at = NOW() WHERE id = ? AND status = 'Dikirim' AND received_at IS NULL");
        $rcv->execute([(int) $orderId]);
        if ($rcv->rowCount() > 0){
            chat_auto($pdo, $o['user_id'], $orderId, 'diterima');
            return [true, 'ok'];
        }
        return [false, 'Status pesanan sudah berubah, muat ulang halaman.'];
    }
    $extra = '';
    if ($next === 'Dikirim' && db_has_column($pdo, 'orders', 'shipped_at'))   $extra = ', shipped_at = NOW()';
    if ($next === 'Selesai' && db_has_column($pdo, 'orders', 'completed_at')) $extra = ', completed_at = NOW()';
    $upd = $pdo->prepare("UPDATE orders SET status = ?$extra WHERE id = ? AND status = ?");   // bersyarat: tidak bisa dobel
    $upd->execute([$next, (int) $orderId, $o['status']]);
    if ($upd->rowCount() > 0){
        chat_auto($pdo, $o['user_id'], $orderId, strtolower($next));   // pesan otomatis dari penjual ke chat pembeli
        return [true, 'ok'];
    }
    return [false, 'Status pesanan sudah berubah, muat ulang halaman.'];
}

// Pembeli menekan "Pesanan Diterima": status tetap Dikirim, tapi received_at dicatat.
// Setelah itu pembeli memilih: "Selesai" (finish_order) atau "Retur" (return_order.php).
function confirm_received($pdo, $orderId, $userId){
    $upd = $pdo->prepare("UPDATE orders SET received_at = NOW() WHERE id = ? AND user_id = ? AND status = 'Dikirim' AND received_at IS NULL");
    $upd->execute([(int) $orderId, (int) $userId]);
    return $upd->rowCount() > 0;
}

// Pembeli menekan "Selesai": Dikirim (sudah diterima) -> Selesai. Final: setelah ini tidak ada pengembalian lagi.
// Tidak bisa kalau retur sedang diajukan / sudah disetujui.
function finish_order($pdo, $orderId, $userId){
    $upd = $pdo->prepare("UPDATE orders SET status = 'Selesai', completed_at = NOW()
                          WHERE id = ? AND user_id = ? AND status = 'Dikirim' AND received_at IS NOT NULL
                          AND (return_status IS NULL OR return_status = 'ditolak')");
    $upd->execute([(int) $orderId, (int) $userId]);
    return $upd->rowCount() > 0;
}

// Batas akhir pengajuan retur (timestamp) / sisa hari. null = belum bisa dihitung (belum Selesai)
function return_deadline($o){
    if (empty($o['received_at'])) return null;
    return strtotime($o['received_at']) + RETURN_WINDOW_DAYS * 86400;
}
function return_days_left($o){
    $d = return_deadline($o);
    if ($d === null) return null;
    $left = $d - time();
    return $left > 0 ? (int) ceil($left / 86400) : 0;   // 0 = batas sudah lewat
}
// Boleh ajukan pengembalian: sudah diterima, belum Selesai, belum pernah diajukan, masih dalam batas hari
function return_eligible($o){
    return ($o['status'] ?? '') === 'Dikirim' && !empty($o['received_at']) && empty($o['return_status']) && (return_days_left($o) ?? 0) > 0;
}

// Lewat RETURN_WINDOW_DAYS hari sejak diterima tanpa memilih -> otomatis Selesai (dipanggil saat halaman dibuka)
function auto_finish_received($pdo){
    if (!return_ready($pdo)) return;
    $limit = date('Y-m-d H:i:s', time() - RETURN_WINDOW_DAYS * 86400);
    $pdo->prepare("UPDATE orders SET status = 'Selesai', completed_at = NOW()
                   WHERE status = 'Dikirim' AND received_at IS NOT NULL AND received_at < ?
                   AND (return_status IS NULL OR return_status = 'ditolak')")->execute([$limit]);
}

// Simpan bukti pengembalian (1-3 file foto/video dari input name="proof[]").
// Return [true, [namaFile, ...]] atau [false, pesanError]
function return_save_proofs($pdo, $field = 'proof', $max = 3, $imagesOnly = false, $need = 'Bukti foto atau video wajib dilampirkan.'){
    $imgExt = ['jpg', 'jpeg', 'png', 'webp'];
    $vidExt = ['mp4', 'webm', 'mov'];
    $maxImg = 5 * 1024 * 1024;     // foto maks 5 MB
    $maxVid = 20 * 1024 * 1024;    // video maks 20 MB
    if (empty($_FILES[$field]['name']) || !is_array($_FILES[$field]['name'])) return [false, $need];
    $idx = [];
    foreach ($_FILES[$field]['name'] as $i => $n) if ($n !== '') $idx[] = $i;
    if (!$idx) return [false, $need];
    if (count($idx) > $max) return [false, 'Maksimal ' . $max . ' file untuk bagian ini.'];
    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0777, true);

    $saved = [];
    $fail = function($msg) use (&$saved){
        foreach ($saved as $f) @unlink(UPLOAD_DIR . $f);
        return [false, $msg];
    };
    foreach ($idx as $i){
        $orig = $_FILES[$field]['name'][$i];
        $err  = $_FILES[$field]['error'][$i];
        $tmp  = $_FILES[$field]['tmp_name'][$i];
        $size = (int) $_FILES[$field]['size'][$i];
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) return $fail('File "' . $orig . '" terlalu besar untuk server (batas upload_max_filesize di php.ini).');
        if ($err !== UPLOAD_ERR_OK) return $fail('File "' . $orig . '" gagal diunggah, coba lagi.');
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $isImg = in_array($ext, $imgExt, true);
        $isVid = !$imagesOnly && in_array($ext, $vidExt, true);
        if (!$isImg && !$isVid) return $fail('Format "' . $orig . '" tidak didukung. Pakai ' . ($imagesOnly ? 'foto (JPG, PNG, WEBP).' : 'foto (JPG, PNG, WEBP) atau video (MP4, WEBM, MOV).'));
        if ($isImg && $size > $maxImg) return $fail('Foto "' . $orig . '" lebih dari 5 MB.');
        if ($isVid && $size > $maxVid) return $fail('Video "' . $orig . '" lebih dari 20 MB.');
        // isi file harus benar-benar foto / video (bukan sekadar ganti nama)
        if ($isImg && @getimagesize($tmp) === false) return $fail('File "' . $orig . '" bukan gambar yang valid.');
        if ($isVid && function_exists('mime_content_type')){
            $mime = (string) @mime_content_type($tmp);
            if (strpos($mime, 'video/') !== 0) return $fail('File "' . $orig . '" bukan video yang valid.');
        }
        $name = 'retur_' . uniqid() . '.' . $ext;
        if (!move_uploaded_file($tmp, UPLOAD_DIR . $name)) return $fail('Gagal menyimpan file. Cek izin folder uploads.');
        $saved[] = $name;
        upload_backup_save($pdo, $name);   // foto (dan video kecil) ikut dicadangkan di database
    }
    return [true, $saved];
}

// Pembeli mengajukan pengembalian. Syarat (dicek di SQL): milik user ini, status Selesai, belum pernah diajukan, masih dalam batas hari.
function request_return($pdo, $orderId, $userId, $reason, array $proofNames, $resiProof = ''){
    if (!return_ready($pdo)) return [false, 'Fitur pengembalian belum aktif (jalankan migration_v17.sql).'];
    if (!$proofNames) return [false, 'Foto kondisi barang wajib dilampirkan.'];
    if ($resiProof === '') return [false, 'Foto bukti nomor resi wajib dilampirkan.'];
    $limit = date('Y-m-d H:i:s', time() - RETURN_WINDOW_DAYS * 86400);
    // boleh dari: Dikirim yang sudah ditekan Diterima, atau Selesai selama masih dalam batas hari
    $upd = $pdo->prepare("UPDATE orders SET return_status = 'diajukan', return_reason = ?, return_proof = ?, return_proof_resi = ?, return_requested_at = NOW(), return_note = NULL, return_resolved_at = NULL
                          WHERE id = ? AND user_id = ? AND return_status IS NULL
                          AND status = 'Dikirim' AND received_at IS NOT NULL AND received_at >= ?");
    $upd->execute([mb_substr_safe($reason, 255), implode(',', $proofNames), $resiProof, (int) $orderId, (int) $userId, $limit]);
    return $upd->rowCount() > 0
        ? [true, 'ok']
        : [false, 'Pengajuan gagal. Pesanan harus sudah kamu tandai Diterima, belum Selesai, belum pernah diajukan, dan masih dalam batas ' . RETURN_WINDOW_DAYS . ' hari sejak diterima.'];
}

// Admin menyetujui retur: status -> Dikembalikan, poin member ditarik lagi, stok dikembalikan HANYA kalau $restock = true
// (barang retur yang rusak tidak boleh masuk stok). Dana dikembalikan manual oleh admin.
function approve_return($pdo, $orderId, $note, $restock){
    $own = !$pdo->inTransaction();
    try {
        if ($own) $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? FOR UPDATE");
        $stmt->execute([(int) $orderId]);
        $o = $stmt->fetch();
        if (!$o) throw new Exception('Pesanan tidak ditemukan.');
        if (!in_array($o['status'], ['Selesai', 'Dikirim'], true) || ($o['return_status'] ?? '') !== 'diajukan') throw new Exception('Tidak ada pengajuan pengembalian yang menunggu untuk pesanan ini.');
        $items = $pdo->prepare("SELECT book_id, qty, price FROM order_items WHERE order_id = ?");
        $items->execute([(int) $orderId]);
        $subtotal = 0;
        foreach ($items->fetchAll() as $it){
            if ($restock) restock_item($pdo, $o, $it['book_id'], $it['qty']);
            $subtotal += $it['price'] * $it['qty'];
        }
        // sama seperti pembatalan: tarik lagi poin yang didapat pesanan ini
        $total = (float) $o['total'];
        $pts = refund_points_for_order($o, $subtotal);
        if ($pts > 0) $pdo->prepare("UPDATE users SET points = GREATEST(points - ?, 0) WHERE id = ?")->execute([$pts, $o['user_id']]);
        $pdo->prepare("UPDATE orders SET status = 'Dikembalikan', return_status = 'disetujui', return_note = ?, return_resolved_at = NOW() WHERE id = ?")
            ->execute([$note !== '' ? mb_substr_safe($note, 255) : null, (int) $orderId]);
        if ($own) $pdo->commit();
        chat_auto($pdo, $o['user_id'], $orderId, 'retur_disetujui', $note);
        return [true, 'ok'];
    } catch (Throwable $e) {
        if ($own && $pdo->inTransaction()) $pdo->rollBack();
        return [false, $e->getMessage()];
    }
}

// Admin menolak pengajuan retur (alasan wajib, tampil ke pembeli). Status pesanan tidak berubah (pembeli masih bisa menekan Selesai).
function reject_return($pdo, $orderId, $note){
    $upd = $pdo->prepare("UPDATE orders SET return_status = 'ditolak', return_note = ?, return_resolved_at = NOW() WHERE id = ? AND status IN ('Selesai','Dikirim') AND return_status = 'diajukan'");
    $upd->execute([mb_substr_safe($note, 255), (int) $orderId]);
    if ($upd->rowCount() > 0){
        $u = $pdo->prepare("SELECT user_id FROM orders WHERE id = ?");
        $u->execute([(int) $orderId]);
        chat_auto($pdo, (int) $u->fetchColumn(), $orderId, 'retur_ditolak', $note);
        return [true, 'ok'];
    }
    return [false, 'Tidak ada pengajuan pengembalian yang menunggu untuk pesanan ini.'];
}

// ----- tampilan bukti foto / video -----
function proof_files($csv){
    $out = [];
    foreach (explode(',', (string) $csv) as $f){ $f = basename(trim($f)); if ($f !== '') $out[] = $f; }
    return $out;
}
function proof_is_video($name){
    return in_array(strtolower(pathinfo($name, PATHINFO_EXTENSION)), ['mp4', 'webm', 'mov'], true);
}
function proof_media_html($pdo, $csv){
    $html = '<div class="proof-grid">';
    foreach (proof_files($csv) as $f){
        if (!upload_ensure($pdo, $f)){ $html .= '<span class="badge badge-diproses">File hilang: ' . h($f) . '</span>'; continue; }
        $url = h(UPLOAD_URL . $f);
        if (proof_is_video($f)) $html .= '<video class="proof-vid" src="' . $url . '" controls preload="metadata"></video>';
        else $html .= '<a href="' . $url . '" target="_blank" title="Klik untuk lihat ukuran penuh"><img class="proof-img" src="' . $url . '" alt="Bukti"></a>';
    }
    return $html . '</div>';
}

// ===================================================
// WAR BUKU (rilis limited edition) - butuh database/migration_v14.sql
// Admin mengatur buku, harga war, stok terbatas, jadwal buka/tutup, dan batas beli per akun.
// Stok war TERPISAH dari stok toko biasa (books.stock tidak berubah saat war).
// ===================================================
function war_ready($pdo){
    static $ok = null;
    if ($ok === null){
        try {
            $ok = ((int) $pdo->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'book_wars'")->fetchColumn()) > 0
                && db_has_column($pdo, 'orders', 'war_id');
        } catch (Throwable $e) { $ok = false; }
    }
    return $ok;
}

// Kembalikan stok satu item pesanan: pesanan war -> stok war (tidak melebihi total_stock), pesanan biasa -> stok buku
function restock_item($pdo, $order, $bookId, $qty){
    if (!empty($order['war_id'])){
        $pdo->prepare("UPDATE book_wars SET stock = LEAST(total_stock, stock + ?) WHERE id = ?")->execute([(int) $qty, (int) $order['war_id']]);
    } else {
        $pdo->prepare("UPDATE books SET stock = stock + ? WHERE id = ?")->execute([(int) $qty, (int) $bookId]);
    }
}

// Fase war: upcoming (belum buka) | live (sedang berlangsung) | soldout (stok habis) | ended (waktu habis) | cancelled
// $early = detik akses lebih awal (benefit early sale member), lihat war_early_seconds()
function war_phase($w, $now = null, $early = 0){
    $now = $now ?? time();
    if (($w['status'] ?? 'active') === 'cancelled') return 'cancelled';
    $start = strtotime($w['start_at']) - (int) $early;
    $end = strtotime($w['end_at']);
    if ($now < $start) return 'upcoming';
    if ($now >= $end) return 'ended';
    if ((int) $w['stock'] <= 0) return 'soldout';
    return 'live';
}

// Berapa detik member boleh masuk war lebih awal (0 kalau bukan member / paket tanpa early sale)
function war_early_seconds($pdo){
    $perks = member_perks($pdo);
    return $perks ? (int) $perks['early_menit'] * 60 : 0;
}

function war_phase_label($phase){
    return ['upcoming' => 'Akan datang', 'live' => 'Sedang berlangsung', 'soldout' => 'Habis terjual', 'ended' => 'Sudah berakhir', 'cancelled' => 'Dibatalkan'][$phase] ?? $phase;
}

function war_badge_class($phase){
    return ['upcoming' => 'badge-baru', 'live' => 'badge-selesai', 'soldout' => 'badge-retur', 'ended' => 'badge-diproses', 'cancelled' => 'badge-batal'][$phase] ?? '';
}

// Ambil satu war beserta data bukunya
function war_get($pdo, $id){
    $stmt = $pdo->prepare("SELECT w.*, b.title AS book_title, b.author, b.price AS normal_price, b.cover_image AS book_cover FROM book_wars w JOIN books b ON b.id = w.book_id WHERE w.id = ?");
    $stmt->execute([(int) $id]);
    return $stmt->fetch() ?: null;
}

function war_cover_url($w){
    $img = $w['cover_image'] ?: ($w['book_cover'] ?? '');
    return $img ? UPLOAD_URL . $img : 'https://placehold.co/280x380?text=' . urlencode($w['title']);
}

// Jumlah yang sudah dibeli user pada war ini (pesanan batal / retur tidak dihitung)
function war_user_bought($pdo, $warId, $userId){
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(oi.qty),0) FROM orders o JOIN order_items oi ON oi.order_id = o.id WHERE o.war_id = ? AND o.user_id = ? AND o.status NOT IN ('Dibatalkan','Dikembalikan')");
    $stmt->execute([(int) $warId, (int) $userId]);
    return (int) $stmt->fetchColumn();
}

// Jumlah terjual untuk war (pesanan batal / retur tidak dihitung)
function war_sold($pdo, $warId){
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(oi.qty),0) FROM orders o JOIN order_items oi ON oi.order_id = o.id WHERE o.war_id = ? AND o.status NOT IN ('Dibatalkan','Dikembalikan')");
    $stmt->execute([(int) $warId]);
    return (int) $stmt->fetchColumn();
}

// Simpan cover war (hanya gambar). Return nama file, atau null kalau tidak ada upload. Throw Exception kalau format salah.
function war_save_cover($field = 'cover'){
    if (empty($_FILES[$field]['name'])) return null;
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) throw new Exception('Format cover harus JPG, PNG, atau WEBP.');
    if (!is_uploaded_file($_FILES[$field]['tmp_name'])) throw new Exception('Upload cover gagal.');
    $name = uniqid('war_') . '.' . $ext;
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0777, true);
    if (!move_uploaded_file($_FILES[$field]['tmp_name'], UPLOAD_DIR . $name)) throw new Exception('Upload cover gagal.');
    return $name;
}

// Beli di war. SEMUA pengecekan (waktu, status, stok, batas per akun) dilakukan di dalam transaksi
// setelah baris war dikunci (FOR UPDATE), jadi kalau 100 orang klik bersamaan, stok tidak bisa oversell
// dan batas per akun tidak bisa dilewati. Waktu buka/tutup memakai jam server database (NOW()).
// Return [true, orderId] atau [false, pesanError].
function war_purchase($pdo, $warId, $userId, $qty, $address, $phone, $paymentLabel, $proofName, array $extra = []){
    $qty = (int) $qty;
    if ($qty < 1) return [false, 'Jumlah minimal 1.'];
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT *, (NOW() >= DATE_SUB(start_at, INTERVAL ? SECOND)) AS started, (NOW() < end_at) AS not_ended FROM book_wars WHERE id = ? FOR UPDATE");
        $stmt->execute([war_early_seconds($pdo), (int) $warId]);
        $w = $stmt->fetch();
        if (!$w || $w['status'] !== 'active') throw new Exception('War ini tidak tersedia.');
        if (!$w['started']) throw new Exception('War belum dibuka. Tunggu hitungan mundurnya selesai ya.');
        if (!$w['not_ended']) throw new Exception('War sudah berakhir.');
        if ((int) $w['stock'] <= 0) throw new Exception('Yah, kehabisan! Semua stok war ini sudah diambil.');
        if ($qty > (int) $w['stock']) throw new Exception('Stok war tinggal ' . (int) $w['stock'] . '. Kurangi jumlahnya ya.');

        $bought = war_user_bought($pdo, $warId, $userId);
        $left = (int) $w['max_per_user'] - $bought;
        if ($left <= 0) throw new Exception('Kamu sudah mencapai batas beli war ini (maks. ' . (int) $w['max_per_user'] . ' per akun).');
        if ($qty > $left) throw new Exception('Batas beli per akun tinggal ' . $left . ' lagi.');

        $subtotal = (float) $w['price'] * $qty;
        $ongkir = shipping_cost(member_perks($pdo), $subtotal);
        $total = $subtotal + $ongkir;

        $cols = ['user_id', 'total', 'payment_method', 'payment_proof', 'shipping_address', 'status', 'war_id'];
        $vals = [$userId, $total, $paymentLabel, $proofName, $address, 'Baru', (int) $warId];
        if (db_has_column($pdo, 'orders', 'shipping_phone')){ $cols[] = 'shipping_phone'; $vals[] = $phone; }
        foreach ($extra as $col => $val){   // shipping_name, pay_status, pay_expires_at (QRIS)
            if (db_has_column($pdo, 'orders', $col)){ $cols[] = $col; $vals[] = $val; }
        }
        $pdo->prepare("INSERT INTO orders (" . implode(',', $cols) . ") VALUES (" . implode(',', array_fill(0, count($cols), '?')) . ")")->execute($vals);
        $orderId = (int) $pdo->lastInsertId();

        $pdo->prepare("INSERT INTO order_items (order_id, book_id, qty, price) VALUES (?, ?, ?, ?)")->execute([$orderId, $w['book_id'], $qty, $w['price']]);
        $pdo->prepare("UPDATE book_wars SET stock = stock - ? WHERE id = ?")->execute([$qty, (int) $warId]);

        if (db_has_column($pdo, 'users', 'phone')){
            $pdo->prepare("UPDATE users SET phone = ? WHERE id = ? AND (phone IS NULL OR phone = '')")->execute([$phone, $userId]);
        }
        $pdo->commit();
        return [true, $orderId];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return [false, ($e instanceof PDOException) ? 'Database error: ' . $e->getMessage() : $e->getMessage()];
    }
}

// War untuk banner/menu: yang sedang live dan yang akan datang (terdekat dulu)
function war_highlights($pdo, $limit = 3){
    if (!war_ready($pdo)) return [];
    try {
        $rows = $pdo->query("SELECT w.*, b.title AS book_title, b.author, b.price AS normal_price, b.cover_image AS book_cover FROM book_wars w JOIN books b ON b.id = w.book_id WHERE w.status = 'active' AND w.end_at > NOW() AND (w.stock > 0 OR w.start_at > NOW()) ORDER BY (w.start_at <= NOW()) DESC, w.start_at ASC LIMIT " . (int) $limit)->fetchAll();
        return $rows;
    } catch (Throwable $e) { return []; }
}

function war_live_count($pdo){
    if (!war_ready($pdo)) return 0;
    try { return (int) $pdo->query("SELECT COUNT(*) FROM book_wars WHERE status = 'active' AND start_at <= NOW() AND end_at > NOW() AND stock > 0")->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}

// Fungsi chat pembeli <-> admin (butuh migration_v13.sql)
require_once __DIR__ . '/chat.php';

// Buku alamat + pembayaran QRIS dinamis (butuh migration_v16.sql)
require_once __DIR__ . '/payment.php';
