<?php
// ===================================================
// Buku alamat pembeli + pembayaran QRIS dinamis (butuh database/migration_v16.sql)
// ===================================================
require_once __DIR__ . '/qris.php';

const ADDR_MAX = 10;

// ---------- Buku alamat ----------
function addr_ready($pdo){ return db_has_column($pdo, 'user_addresses', 'id'); }

function addr_list($pdo, $userId){
    $st = $pdo->prepare("SELECT * FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC");
    $st->execute([(int) $userId]);
    return $st->fetchAll();
}

function addr_get($pdo, $userId, $id){
    $st = $pdo->prepare("SELECT * FROM user_addresses WHERE id = ? AND user_id = ?");
    $st->execute([(int) $id, (int) $userId]);
    return $st->fetch() ?: null;
}

// Validasi input form alamat. Return [data|null, error]
function addr_validate(array $in){
    $label = trim((string) ($in['label'] ?? ''));
    $recipient = trim((string) ($in['recipient'] ?? ''));
    $address = trim((string) ($in['address'] ?? ''));
    $phone = normalize_phone($in['phone'] ?? '');
    if ($label === '') $label = 'Rumah';
    if (mb_strlen($recipient) < 2) return [null, 'Nama penerima wajib diisi.'];
    if ($phone === false) return [null, 'Nomor HP tidak valid. Contoh: 081234567890'];
    if (mb_strlen($address) < 10) return [null, 'Alamat terlalu pendek. Tulis lengkap: jalan, nomor, RT/RW, kelurahan, kota, kode pos.'];
    return [[
        'label' => mb_substr_safe($label, 40), 'recipient' => mb_substr_safe($recipient, 100),
        'phone' => $phone, 'address' => mb_substr_safe($address, 500),
    ], ''];
}

// Simpan alamat baru (atau $id untuk edit). Alamat pertama otomatis jadi utama. Return [id|null, error]
function addr_save($pdo, $userId, array $d, $makeDefault = false, $id = null){
    $userId = (int) $userId;
    try {
        $pdo->beginTransaction();
        if ($id){
            if (!addr_get($pdo, $userId, $id)) throw new Exception('Alamat tidak ditemukan.');
            $pdo->prepare("UPDATE user_addresses SET label = ?, recipient = ?, phone = ?, address = ? WHERE id = ? AND user_id = ?")
                ->execute([$d['label'], $d['recipient'], $d['phone'], $d['address'], (int) $id, $userId]);
        } else {
            $cnt = $pdo->prepare("SELECT COUNT(*) FROM user_addresses WHERE user_id = ?");
            $cnt->execute([$userId]);
            $n = (int) $cnt->fetchColumn();
            if ($n >= ADDR_MAX) throw new Exception('Maksimal ' . ADDR_MAX . ' alamat tersimpan. Hapus alamat lama dulu.');
            if ($n === 0) $makeDefault = true;
            $pdo->prepare("INSERT INTO user_addresses (user_id, label, recipient, phone, address, is_default) VALUES (?, ?, ?, ?, ?, 0)")
                ->execute([$userId, $d['label'], $d['recipient'], $d['phone'], $d['address']]);
            $id = (int) $pdo->lastInsertId();
        }
        if ($makeDefault) addr_set_default($pdo, $userId, $id);
        $pdo->commit();
        return [(int) $id, ''];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return [null, $e->getMessage()];
    }
}

function addr_set_default($pdo, $userId, $id){
    $pdo->prepare("UPDATE user_addresses SET is_default = 0 WHERE user_id = ?")->execute([(int) $userId]);
    $pdo->prepare("UPDATE user_addresses SET is_default = 1 WHERE id = ? AND user_id = ?")->execute([(int) $id, (int) $userId]);
}

function addr_delete($pdo, $userId, $id){
    $a = addr_get($pdo, $userId, $id);
    if (!$a) return false;
    $pdo->prepare("DELETE FROM user_addresses WHERE id = ? AND user_id = ?")->execute([(int) $id, (int) $userId]);
    if ($a['is_default']){   // alamat utama dihapus: alamat terbaru yang tersisa jadi utama
        $next = $pdo->prepare("SELECT id FROM user_addresses WHERE user_id = ? ORDER BY id DESC LIMIT 1");
        $next->execute([(int) $userId]);
        $nid = $next->fetchColumn();
        if ($nid) addr_set_default($pdo, $userId, $nid);
    }
    return true;
}

// ---------- Pembayaran QRIS ----------
// pay_status: NULL (pesanan lama / non-QRIS) | menunggu | dibayar | kedaluwarsa
function pay_ready($pdo){
    return db_has_column($pdo, 'orders', 'pay_status') && db_has_column($pdo, 'orders', 'pay_expires_at') && db_has_column($pdo, 'orders', 'paid_at');
}

// Waktu batas bayar (format DATETIME, zona WIB)
function pay_deadline(){ return date('Y-m-d H:i:s', time() + qris_expire_minutes() * 60); }

// Pesanan QRIS yang lewat batas bayar -> dibatalkan otomatis, stok & poin dikembalikan.
// Aman dipanggil sering & bersamaan: status "menunggu" direbut dulu secara atomik (UPDATE bersyarat).
function pay_expire_unpaid($pdo){
    if (!pay_ready($pdo)) return 0;
    $done = 0;
    try {
        $ids = $pdo->query("SELECT id FROM orders WHERE pay_status = 'menunggu' AND status = 'Baru' AND pay_expires_at IS NOT NULL AND pay_expires_at < NOW()")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ids as $oid){
            $claim = $pdo->prepare("UPDATE orders SET pay_status = 'kedaluwarsa' WHERE id = ? AND pay_status = 'menunggu' AND pay_expires_at < NOW()");
            $claim->execute([(int) $oid]);
            if ($claim->rowCount() < 1) continue;   // keburu dikonfirmasi admin / diproses proses lain
            list($ok) = cancel_order($pdo, $oid, 'sistem', 'Pembayaran QRIS belum diterima dalam ' . qris_expire_minutes() . ' menit.', '');
            if ($ok) $done++;
        }
    } catch (Throwable $e) { /* diabaikan */ }
    return $done;
}

// Admin menekan "Pembayaran Diterima". Return [ok, pesan]
function pay_confirm($pdo, $orderId){
    pay_expire_unpaid($pdo);
    $upd = $pdo->prepare("UPDATE orders SET pay_status = 'dibayar', paid_at = NOW() WHERE id = ? AND pay_status = 'menunggu' AND status = 'Baru'");
    $upd->execute([(int) $orderId]);
    if ($upd->rowCount() > 0){
        $st = $pdo->prepare("SELECT user_id FROM orders WHERE id = ?");
        $st->execute([(int) $orderId]);
        chat_auto($pdo, $st->fetchColumn(), $orderId, 'dibayar');
        return [true, 'ok'];
    }
    return [false, 'Pesanan ini tidak lagi menunggu pembayaran (sudah dikonfirmasi, kedaluwarsa, atau dibatalkan).'];
}

function pay_is_qris($order){ return stripos((string) ($order['payment_method'] ?? ''), 'qris') !== false; }

// Kolom form alamat (dipakai di checkout & halaman Alamat Saya). $p = awalan nama field, $v = nilai awal
function addr_fields($p, array $v = []){
    $in = 'width:100%; padding:11px 12px; border:1.5px solid #ccc; border-radius:8px;';
    ob_start(); ?>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
      <div class="form-group" style="margin:0;"><label>Nama Penerima</label>
        <input type="text" name="<?= $p ?>recipient" maxlength="100" value="<?= h($v['recipient'] ?? '') ?>" placeholder="Nama lengkap penerima" style="<?= $in ?>"></div>
      <div class="form-group" style="margin:0;"><label>Nomor HP</label>
        <input type="tel" name="<?= $p ?>phone" value="<?= h($v['phone'] ?? '') ?>" placeholder="081234567890" style="<?= $in ?>"></div>
    </div>
    <div class="form-group" style="margin:12px 0 0;"><label>Alamat Lengkap</label>
      <textarea name="<?= $p ?>address" rows="3" maxlength="500" placeholder="Jalan, nomor rumah, RT/RW, kelurahan, kecamatan, kota, kode pos" style="<?= $in ?>"><?= h($v['address'] ?? '') ?></textarea></div>
    <div class="form-group" style="margin:12px 0 0;"><label>Label Alamat</label>
      <input type="text" name="<?= $p ?>label" maxlength="40" value="<?= h($v['label'] ?? '') ?>" placeholder="Rumah / Kantor / Kos" style="<?= $in ?> max-width:260px;"></div>
    <?php
    return ob_get_clean();
}
