<?php
// ===================================================
// QRIS DINAMIS - nominal terkunci per pesanan
// QRIS statis toko (QRIS_STATIC di config/db.php) diubah jadi QRIS dinamis sesuai standar EMV:
//   tag 01 = 12 (dinamis), tag 54 = nominal, tag 63 = CRC16 dihitung ulang.
// Aplikasi e-wallet / m-banking membaca nominal dari QR dan TIDAK mengizinkan pembeli mengubahnya,
// jadi pembayaran harus pas, tidak bisa kurang maupun lebih.
// ===================================================
require_once __DIR__ . '/qrcode.php';

function qris_crc16($s){
    $crc = 0xFFFF;
    for ($i = 0, $n = strlen($s); $i < $n; $i++){
        $crc ^= ord($s[$i]) << 8;
        for ($k = 0; $k < 8; $k++) $crc = ($crc & 0x8000) ? (($crc << 1) ^ 0x1021) & 0xFFFF : ($crc << 1) & 0xFFFF;
    }
    return strtoupper(sprintf('%04X', $crc));
}

function qris_parse($s){
    $out = []; $i = 0; $n = strlen($s);
    while ($i + 4 <= $n){
        $tag = substr($s, $i, 2); $len = (int) substr($s, $i + 2, 2);
        if (!ctype_digit($tag) || $i + 4 + $len > $n) return null;
        $out[] = [$tag, substr($s, $i + 4, $len)];
        $i += 4 + $len;
    }
    return $i === $n ? $out : null;
}

// Return string QRIS dinamis, atau null kalau QRIS statis tidak valid
function qris_dynamic($static, $amount){
    $tlv = qris_parse(trim((string) $static));
    $amount = (int) round($amount);
    if (!$tlv || $amount < 1) return null;
    $res = ''; $has54 = false;
    foreach ($tlv as $t){
        list($tag, $val) = $t;
        if ($tag === '63' || $tag === '54') continue;
        if ($tag === '01') $val = '12';
        $res .= $tag . sprintf('%02d', strlen($val)) . $val;
        if ($tag === '53'){ $a = (string) $amount; $res .= '54' . sprintf('%02d', strlen($a)) . $a; $has54 = true; }
    }
    if (!$has54) return null;
    $res .= '6304';
    return $res . qris_crc16($res);
}

function qris_expire_minutes(){ return defined('QRIS_EXPIRE_MINUTES') ? (int) QRIS_EXPIRE_MINUTES : 30; }
