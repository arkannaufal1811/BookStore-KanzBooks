<?php
// ===================================================
// Chat pembeli <-> admin penjual (butuh database/migration_v13.sql)
// Satu percakapan per pembeli (chat_messages.user_id). sender: 'user' | 'admin'.
// kind: 'text' (obrolan biasa) | 'system' (pesan otomatis penjual) | 'logistik' (kartu informasi logistik).
// Pesan boleh dikaitkan ke satu pesanan (order_id) dan boleh berisi satu foto.
// File ini dimuat dari bagian bawah includes/auth.php, jadi fungsinya tersedia di semua halaman.
// ===================================================

function chat_ready($pdo){
    return db_has_column($pdo, 'chat_messages', 'kind');
}

// ----- label waktu -----
function chat_day_label($ts){
    $days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $d = date('Y-m-d', $ts);
    if ($d === date('Y-m-d')) return 'Hari ini';
    if ($d === date('Y-m-d', strtotime('-1 day'))) return 'Kemarin';
    if ($ts > strtotime('-6 days')) return $days[(int) date('w', $ts)];
    return date('d M Y', $ts);
}
function time_ago($ts){
    $s = time() - $ts;
    if ($s < 60) return 'baru saja';
    if ($s < 3600) return floor($s / 60) . ' mnt';
    if ($s < 86400) return floor($s / 3600) . ' j';
    if ($s < 7 * 86400) return floor($s / 86400) . ' h';
    return date('d M', $ts);
}

// ----- hitungan pesan belum dibaca (untuk badge angka) -----
function chat_unread_user($pdo, $userId){
    if (!chat_ready($pdo)) return 0;
    $st = $pdo->prepare("SELECT COUNT(*) FROM chat_messages WHERE user_id = ? AND sender = 'admin' AND read_at IS NULL");
    $st->execute([(int) $userId]);
    return (int) $st->fetchColumn();
}
function chat_unread_admin($pdo){
    if (!chat_ready($pdo)) return 0;
    return (int) $pdo->query("SELECT COUNT(*) FROM chat_messages WHERE sender = 'user' AND read_at IS NULL")->fetchColumn();
}
// $reader = siapa yang membuka percakapan; pesan LAWAN bicara ditandai sudah dibaca
function chat_mark_read($pdo, $userId, $reader){
    $other = $reader === 'admin' ? 'user' : 'admin';
    $pdo->prepare("UPDATE chat_messages SET read_at = NOW() WHERE user_id = ? AND sender = ? AND read_at IS NULL")->execute([(int) $userId, $other]);
}
// id pesan milik $me yang sudah dibaca lawan bicara (untuk centang dua)
function chat_read_ids($pdo, $userId, $me){
    $st = $pdo->prepare("SELECT id FROM chat_messages WHERE user_id = ? AND sender = ? AND read_at IS NOT NULL ORDER BY id DESC LIMIT 40");
    $st->execute([(int) $userId, $me]);
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

// ----- ambil pesan -----
function chat_base_select($pdo){
    $cols = '';
    foreach (['courier', 'tracking_no', 'shipped_at'] as $c){
        $cols .= db_has_column($pdo, 'orders', $c) ? ", o.$c AS order_$c" : ", NULL AS order_$c";
    }
    return "SELECT m.*, o.status AS order_status, o.total AS order_total$cols,
        (SELECT b.title FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = m.order_id ORDER BY oi.id LIMIT 1) AS order_title,
        (SELECT b.cover_image FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = m.order_id ORDER BY oi.id LIMIT 1) AS order_cover,
        (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = m.order_id) AS order_items_count
        FROM chat_messages m LEFT JOIN orders o ON o.id = m.order_id ";
}
// $afterId = 0: 300 pesan terakhir. $afterId > 0: hanya pesan yang lebih baru dari id itu (dipakai polling)
function chat_fetch($pdo, $userId, $afterId = 0, $limit = 300){
    $base = chat_base_select($pdo);
    if ($afterId > 0){
        $st = $pdo->prepare($base . "WHERE m.user_id = ? AND m.id > ? ORDER BY m.id ASC LIMIT " . (int) $limit);
        $st->execute([(int) $userId, (int) $afterId]);
        return $st->fetchAll();
    }
    $st = $pdo->prepare($base . "WHERE m.user_id = ? ORDER BY m.id DESC LIMIT " . (int) $limit);
    $st->execute([(int) $userId]);
    return array_reverse($st->fetchAll());
}

function chat_cover_url($cover){
    return $cover ? UPLOAD_URL . basename($cover) : BASE_URL . '/assets/images/no-cover.png';
}

// Ubah baris database jadi array siap tampil (dipakai PHP dan dikirim sebagai JSON ke chat.js)
function chat_format($m, $viewer){
    $order = null; $lg = null;
    if (!empty($m['order_id']) && !empty($m['order_status'])){
        $title = (string) ($m['order_title'] ?? '');
        $n = (int) ($m['order_items_count'] ?? 0);
        if ($n > 1) $title .= ' +' . ($n - 1) . ' buku lain';
        $order = [
            'id'     => (int) $m['order_id'],
            'label'  => '#' . str_pad($m['order_id'], 5, '0', STR_PAD_LEFT),
            'status' => $m['order_status'],
            'total'  => rupiah($m['order_total'] ?? 0),
            'title'  => $title,
            'cover'  => chat_cover_url($m['order_cover'] ?? ''),
            'url'    => BASE_URL . ($viewer === 'admin' ? '/admin/order_detail.php?id=' : '/struk.php?id=') . (int) $m['order_id'],
        ];
        if (($m['kind'] ?? '') === 'logistik'){
            $info = [
                'Baru' => 'Pesanan menunggu diverifikasi admin.', 'Diproses' => 'Pesanan sedang disiapkan penjual.',
                'Dikirim' => 'Paket telah dikirim dan sedang dalam perjalanan.', 'Selesai' => 'Paket telah diterima.',
                'Dibatalkan' => 'Pesanan dibatalkan.', 'Dikembalikan' => 'Pesanan dikembalikan.',
            ][$m['order_status']] ?? $m['order_status'];
            $lg = [
                'courier'  => (string) ($m['order_courier'] ?? ''),
                'tracking' => (string) ($m['order_tracking_no'] ?? ''),
                'info'     => $info,
                'when'     => !empty($m['order_shipped_at']) ? date('d M Y H:i', strtotime($m['order_shipped_at'])) : '',
            ];
        }
    }
    $ts = strtotime($m['created_at']);
    return [
        'id' => (int) $m['id'], 'sender' => $m['sender'], 'mine' => $m['sender'] === $viewer,
        'kind' => $m['kind'] ?? 'text', 'text' => (string) $m['message'],
        'image' => !empty($m['image']) ? UPLOAD_URL . basename($m['image']) : null,
        'order' => $order, 'logistic' => $lg,
        'ts' => $ts, 'date' => date('Y-m-d', $ts), 'time' => date('H:i', $ts), 'daylabel' => chat_day_label($ts),
        'read' => !empty($m['read_at']),
    ];
}

// ----- tampilan (versi PHP; chat.js membuat DOM yang sama untuk pesan baru) -----
function chat_render_one($m, $themAvatarHtml){
    $h = '<div class="msg-row ' . ($m['mine'] ? 'me' : 'them') . '" data-id="' . (int) $m['id'] . '">';
    if (!$m['mine']) $h .= $themAvatarHtml;
    $h .= '<div class="msg' . ($m['kind'] === 'logistik' ? ' wide' : '') . '">';
    if ($m['kind'] === 'logistik' && $m['order'] && $m['logistic']){
        $o = $m['order']; $lg = $m['logistic'];
        $h .= '<div class="lg-title">Informasi logistik</div>'
            . '<a class="lg-prod" href="' . h($o['url']) . '" target="_blank"><img src="' . h($o['cover']) . '" alt=""><span>' . h($o['title']) . '</span></a>';
        if ($lg['courier'] !== '') $h .= '<div class="lg-courier">' . h($lg['courier']) . '</div>';
        if ($lg['tracking'] !== '') $h .= '<div class="lg-resi">' . h($lg['tracking']) . '</div>';
        $h .= '<div class="lg-label">Info terbaru seputar logistik</div><div class="lg-info">' . h($lg['info']) . ($lg['when'] !== '' ? '<br>' . h($lg['when']) : '') . '</div>'
            . '<a class="lg-btn" href="' . h($o['url']) . '" target="_blank">Lihat pesanan</a>';
    } else {
        if ($m['order']){
            $o = $m['order'];
            $h .= '<a class="msg-order" href="' . h($o['url']) . '" target="_blank"><img src="' . h($o['cover']) . '" alt="">'
                . '<span><b>Pesanan ' . h($o['label']) . '</b><em>' . h($o['title']) . '</em><small>' . h($o['status']) . ' &middot; ' . h($o['total']) . '</small></span></a>';
        }
        if ($m['image']) $h .= '<a href="' . h($m['image']) . '" target="_blank"><img class="msg-img" src="' . h($m['image']) . '" alt="Foto"></a>';
        if ($m['text'] !== '') $h .= '<div class="msg-text">' . h($m['text']) . '</div>';
    }
    $h .= '<div class="msg-meta">' . h($m['time']) . ($m['mine'] ? ' <span class="msg-read">' . ($m['read'] ? '✓✓' : '✓') . '</span>' : '') . '</div>';
    return $h . '</div></div>';
}
// Pemisah waktu seperti TikTok Shop: "Sabtu, 17:21" saat ganti hari, "06:44" kalau hanya jeda lebih dari 3 jam
function chat_render_list(array $msgs, $themAvatarHtml){
    $html = ''; $lastTs = 0; $lastDate = '';
    foreach ($msgs as $m){
        if (!$lastTs || $m['date'] !== $lastDate || $m['ts'] - $lastTs > 10800){
            $label = (!$lastTs || $m['date'] !== $lastDate) ? $m['daylabel'] . ', ' . $m['time'] : $m['time'];
            $html .= '<div class="chat-sep">' . h($label) . '</div>';
        }
        $lastTs = $m['ts']; $lastDate = $m['date'];
        $html .= chat_render_one($m, $themAvatarHtml);
    }
    return $html;
}

// ----- kirim pesan -----
function chat_insert($pdo, $userId, $sender, $text, $orderId, $image, $kind){
    $pdo->prepare("INSERT INTO chat_messages (user_id, sender, message, image, order_id, kind) VALUES (?, ?, ?, ?, ?, ?)")
        ->execute([(int) $userId, $sender === 'admin' ? 'admin' : 'user', $text, $image, $orderId ?: null, $kind]);
    return (int) $pdo->lastInsertId();
}
// Pesan buatan manusia: dicek panjang, anti banjir, dan pesanan harus milik pembeli. Return [ok, id | pesanError]
function chat_send($pdo, $userId, $sender, $text, $orderId = null, $image = null){
    $text = trim((string) $text);
    if ($text === '' && !$image && !$orderId) return [false, 'Tulis pesan atau lampirkan foto dulu.'];
    if (strlen($text) > 1000) return [false, 'Pesan terlalu panjang (maksimal 1000 karakter).'];
    $st = $pdo->prepare("SELECT COUNT(*) FROM chat_messages WHERE user_id = ? AND sender = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 10 SECOND)");
    $st->execute([(int) $userId, $sender]);
    if ((int) $st->fetchColumn() >= 6) return [false, 'Terlalu cepat, tunggu sebentar ya.'];
    if ($orderId){
        $oc = $pdo->prepare("SELECT id FROM orders WHERE id = ? AND user_id = ?");
        $oc->execute([(int) $orderId, (int) $userId]);
        if (!$oc->fetch()) $orderId = null;   // pesanan bukan milik pembeli ini: abaikan
    }
    if ($text === '' && !$image && !$orderId) return [false, 'Tulis pesan atau lampirkan foto dulu.'];
    return [true, chat_insert($pdo, $userId, $sender, $text, $orderId, $image, 'text')];
}
// Simpan satu foto dari input name="image". Return [true, namaFile|null] atau [false, pesanError]
function chat_save_image($pdo, $field = 'image'){
    if (empty($_FILES[$field]['name'])) return [true, null];
    $f = $_FILES[$field];
    if ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE) return [false, 'Foto terlalu besar untuk server (batas upload_max_filesize di php.ini).'];
    if ($f['error'] !== UPLOAD_ERR_OK) return [false, 'Foto gagal diunggah, coba lagi.'];
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) return [false, 'Format foto harus JPG, PNG, atau WEBP.'];
    if ($f['size'] > 5 * 1024 * 1024) return [false, 'Foto lebih dari 5 MB.'];
    if (@getimagesize($f['tmp_name']) === false) return [false, 'File itu bukan gambar yang valid.'];
    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0777, true);
    $name = 'chat_' . uniqid() . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $name)) return [false, 'Gagal menyimpan foto. Cek izin folder uploads.'];
    upload_backup_save($pdo, $name);
    return [true, $name];
}

// ----- pesan otomatis dari penjual saat status pesanan berubah (seperti TikTok Shop) -----
// Dipanggil dari auth.php. Kalau chat bermasalah, proses pesanan TIDAK boleh ikut gagal, jadi semua error ditelan.
function chat_auto($pdo, $userId, $orderId, $event, $note = ''){
    try {
        if (!chat_ready($pdo) || !$userId) return;
        $no = '#' . str_pad((int) $orderId, 5, '0', STR_PAD_LEFT);
        $ask = "\n\nAda pertanyaan? Jangan sungkan untuk menghubungi kami lewat pesan.";
        $note = trim((string) $note);
        switch ($event){
            case 'dibayar':
                chat_insert($pdo, $userId, 'admin', "Pembayaran QRIS untuk pesanan $no sudah kami terima. Pesanan segera kami proses.", $orderId, null, 'system');
                break;
            case 'diproses':
                chat_insert($pdo, $userId, 'admin', "Pesanan $no sudah kami verifikasi dan sedang kami siapkan." . $ask, $orderId, null, 'system');
                break;
            case 'dikirim':
                chat_insert($pdo, $userId, 'admin', "Pesanan $no sudah kami kirimkan. Anda kini bisa memantau progresnya." . $ask, null, null, 'system');
                chat_insert($pdo, $userId, 'admin', '', $orderId, null, 'logistik');
                break;
            case 'diterima':
                chat_insert($pdo, $userId, 'admin', "Pesanan $no sudah tercatat diterima. Silakan pilih Selesai kalau barangnya aman, atau ajukan Pengembalian Dana dan Barang kalau ada masalah (wajib foto kondisi barang dan bukti resi). Kamu punya " . RETURN_WINDOW_DAYS . " hari untuk memilih; setelah Selesai pesanan tidak bisa dikembalikan.", $orderId, null, 'system');
                break;
            case 'selesai':
                chat_insert($pdo, $userId, 'admin', "Pesanan $no telah selesai. Terima kasih sudah berbelanja di " . STORE_NAME . "!", $orderId, null, 'system');
                break;
            case 'dibatalkan':
                chat_insert($pdo, $userId, 'admin', "Pesanan $no dibatalkan." . ($note !== '' ? " Alasan: $note." : ''), $orderId, null, 'system');
                break;
            case 'retur_disetujui':
                chat_insert($pdo, $userId, 'admin', "Pengajuan pengembalian untuk pesanan $no kami setujui." . ($note !== '' ? " Catatan: $note." : '') . " Kami akan menghubungi kamu untuk langkah pengembalian dananya.", $orderId, null, 'system');
                break;
            case 'retur_ditolak':
                chat_insert($pdo, $userId, 'admin', "Pengajuan pengembalian untuk pesanan $no belum dapat kami setujui." . ($note !== '' ? " Alasan: $note." : '') . $ask, $orderId, null, 'system');
                break;
        }
    } catch (Throwable $e) {
        // sengaja diabaikan
    }
}

// ----- daftar percakapan untuk admin -----
function chat_threads($pdo){
    return $pdo->query("
        SELECT u.id, u.name, u.email,
          (SELECT m.message FROM chat_messages m WHERE m.user_id = u.id ORDER BY m.id DESC LIMIT 1) AS last_msg,
          (SELECT m.kind FROM chat_messages m WHERE m.user_id = u.id ORDER BY m.id DESC LIMIT 1) AS last_kind,
          (SELECT m.image FROM chat_messages m WHERE m.user_id = u.id ORDER BY m.id DESC LIMIT 1) AS last_image,
          (SELECT m.created_at FROM chat_messages m WHERE m.user_id = u.id ORDER BY m.id DESC LIMIT 1) AS last_at,
          (SELECT COUNT(*) FROM chat_messages m WHERE m.user_id = u.id AND m.sender = 'user' AND m.read_at IS NULL) AS unread
        FROM users u
        WHERE EXISTS (SELECT 1 FROM chat_messages m WHERE m.user_id = u.id)
        ORDER BY (SELECT MAX(m.id) FROM chat_messages m WHERE m.user_id = u.id) DESC
    ")->fetchAll();
}
// teks ringkas pesan terakhir untuk daftar percakapan
function chat_snippet($row){
    if (($row['last_kind'] ?? '') === 'logistik') return '📦 Informasi logistik';
    if (($row['last_msg'] ?? '') === '' && !empty($row['last_image'])) return '📷 Foto';
    if (($row['last_msg'] ?? '') === '') return '🧾 Pesanan';
    return $row['last_msg'];
}
// pesan terakhir + jumlah belum dibaca untuk satu pembeli (halaman Pesan)
function chat_last_for_user($pdo, $userId){
    if (!chat_ready($pdo)) return null;
    $st = $pdo->prepare("SELECT message AS last_msg, kind AS last_kind, image AS last_image, created_at AS last_at, sender FROM chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT 1");
    $st->execute([(int) $userId]);
    $r = $st->fetch();
    return $r ?: null;
}

// ----- "Peringatan belanja": notifikasi status pesanan di halaman Pesan -----
function inbox_notifications($pdo, $userId, $limit = 5){
    $st = $pdo->prepare("SELECT o.*,
        (SELECT b.cover_image FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = o.id ORDER BY oi.id LIMIT 1) AS cover
        FROM orders o WHERE o.user_id = ? ORDER BY o.id DESC LIMIT " . (int) $limit);
    $st->execute([(int) $userId]);
    $items = [];
    foreach ($st->fetchAll() as $o){
        $no = '#' . str_pad($o['id'], 5, '0', STR_PAD_LEFT);
        $ts = $o['order_date'];
        $title = 'Pesanan ' . $o['status']; $text = "Pesanan $no berstatus " . $o['status'] . '.';
        switch ($o['status']){
            case 'Baru':
                $title = 'Menunggu verifikasi'; $text = "Pesanan $no menunggu diverifikasi admin."; break;
            case 'Diproses':
                $title = 'Pesanan diproses'; $text = "Pesanan $no sedang disiapkan oleh penjual."; break;
            case 'Dikirim':
                $title = 'Paket sedang dikirim';
                $text = !empty($o['tracking_no'])
                    ? 'Paket dengan nomor resi ' . $o['tracking_no'] . (!empty($o['courier']) ? ' yang dikirim oleh ' . $o['courier'] : '') . ' akan segera Anda terima.'
                    : "Pesanan $no sedang dalam pengiriman.";
                $ts = $o['shipped_at'] ?? $ts; break;
            case 'Selesai':
                $title = 'Pesanan selesai'; $text = "Pesanan $no telah selesai. Terima kasih sudah berbelanja!";
                $ts = $o['completed_at'] ?? $ts; break;
            case 'Dibatalkan':
                $title = 'Pesanan dibatalkan'; $text = "Pesanan $no dibatalkan."; $ts = $o['cancelled_at'] ?? $ts; break;
            case 'Dikembalikan':
                $title = 'Pengembalian disetujui'; $text = "Pengembalian pesanan $no disetujui admin."; $ts = $o['return_resolved_at'] ?? $ts; break;
        }
        if (($o['return_status'] ?? '') === 'diajukan'){ $title = 'Pengembalian menunggu admin'; $text = "Pengajuan pengembalian pesanan $no sedang diperiksa admin."; $ts = $o['return_requested_at'] ?? $ts; }
        $items[] = ['title' => $title, 'text' => $text, 'ts' => strtotime($ts ?: $o['order_date']), 'cover' => chat_cover_url($o['cover'] ?? '')];
    }
    return $items;
}
