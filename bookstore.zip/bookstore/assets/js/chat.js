// Chat pembeli <-> admin (dipakai user/chat.php dan admin/chat.php).
// - polling tiap 3 detik ke chat_api.php, pesan baru muncul tanpa refresh
// - kirim pesan lewat fetch (kalau gagal, form tetap bisa dikirim biasa)
// - tombol "Lihat yang paling baru", emoji, lampiran foto, kartu pesanan / informasi logistik
// Semua teks dari server dimasukkan lewat textContent (bukan innerHTML) supaya aman dari XSS.
(function () {
  var box = document.getElementById('chat-box');
  var form = document.getElementById('chat-form');
  if (!box || !form) return;

  var api = box.getAttribute('data-api');
  var me = box.getAttribute('data-me');
  var thread = box.getAttribute('data-thread');
  var avatar = box.getAttribute('data-avatar') || '';
  var initial = box.getAttribute('data-initial') || '?';
  var lastId = parseInt(box.getAttribute('data-after') || '0', 10);
  var lastTs = parseInt(box.getAttribute('data-last-ts') || '0', 10);
  var lastDate = box.getAttribute('data-last-date') || '';
  var busy = false;

  var elEmpty = document.getElementById('chat-empty');
  var elLatest = document.getElementById('chat-latest');
  var elError = document.getElementById('chat-error');
  var elText = document.getElementById('chat-text');
  var elFile = document.getElementById('chat-file');
  var elOrderId = document.getElementById('chat-order-id');
  var elOrderSel = document.getElementById('order-select');
  var elOrderPick = document.getElementById('order-pick');
  var elAttach = document.getElementById('chat-attach');
  var elEmojiPop = document.getElementById('emoji-pop');

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }
  function link(cls, href) {
    var a = el('a', cls);
    a.href = href;
    a.target = '_blank';
    return a;
  }
  function nearBottom() { return box.scrollHeight - box.scrollTop - box.clientHeight < 90; }
  function toBottom() { box.scrollTop = box.scrollHeight; if (elLatest) elLatest.hidden = true; }
  function showError(msg) { if (!elError) return; elError.textContent = msg; elError.hidden = false; }
  function clearError() { if (elError) { elError.hidden = true; elError.textContent = ''; } }

  function avatarNode() {
    if (avatar) { var im = el('img', 'msg-av'); im.src = avatar; im.alt = ''; return im; }
    return el('span', 'msg-av init', initial);
  }

  // ----- membuat satu pesan (struktur sama dengan chat_render_one di includes/chat.php) -----
  function renderMessage(m) {
    var row = el('div', 'msg-row ' + (m.mine ? 'me' : 'them'));
    row.setAttribute('data-id', m.id);
    if (!m.mine) row.appendChild(avatarNode());
    var bubble = el('div', 'msg' + (m.kind === 'logistik' ? ' wide' : ''));

    if (m.kind === 'logistik' && m.order && m.logistic) {
      bubble.appendChild(el('div', 'lg-title', 'Informasi logistik'));
      var prod = link('lg-prod', m.order.url);
      var pi = el('img'); pi.src = m.order.cover; pi.alt = '';
      prod.appendChild(pi);
      prod.appendChild(el('span', null, m.order.title));
      bubble.appendChild(prod);
      if (m.logistic.courier) bubble.appendChild(el('div', 'lg-courier', m.logistic.courier));
      if (m.logistic.tracking) bubble.appendChild(el('div', 'lg-resi', m.logistic.tracking));
      bubble.appendChild(el('div', 'lg-label', 'Info terbaru seputar logistik'));
      var info = el('div', 'lg-info', m.logistic.info);
      if (m.logistic.when) { info.appendChild(document.createElement('br')); info.appendChild(document.createTextNode(m.logistic.when)); }
      bubble.appendChild(info);
      bubble.appendChild(link('lg-btn', m.order.url)).textContent = 'Lihat pesanan';
    } else {
      if (m.order) {
        var oc = link('msg-order', m.order.url);
        var oi = el('img'); oi.src = m.order.cover; oi.alt = '';
        oc.appendChild(oi);
        var body = el('span');
        body.appendChild(el('b', null, 'Pesanan ' + m.order.label));
        body.appendChild(el('em', null, m.order.title));
        body.appendChild(el('small', null, m.order.status + ' \u00b7 ' + m.order.total));
        oc.appendChild(body);
        bubble.appendChild(oc);
      }
      if (m.image) {
        var la = link('', m.image);
        var im = el('img', 'msg-img'); im.src = m.image; im.alt = 'Foto';
        la.appendChild(im);
        bubble.appendChild(la);
      }
      if (m.text) bubble.appendChild(el('div', 'msg-text', m.text));
    }
    var meta = el('div', 'msg-meta', m.time);
    if (m.mine) { meta.appendChild(document.createTextNode(' ')); meta.appendChild(el('span', 'msg-read', m.read ? '\u2713\u2713' : '\u2713')); }
    bubble.appendChild(meta);
    row.appendChild(bubble);
    return row;
  }

  // pemisah waktu: "Sabtu, 17:21" saat ganti hari, "06:44" kalau hanya jeda lebih dari 3 jam
  function separator(m) {
    if (!lastTs || m.date !== lastDate || m.ts - lastTs > 10800) {
      var label = (!lastTs || m.date !== lastDate) ? m.daylabel + ', ' + m.time : m.time;
      box.appendChild(el('div', 'chat-sep', label));
    }
    lastTs = m.ts; lastDate = m.date;
  }

  function append(list) {
    if (!list || !list.length) return;
    var stick = nearBottom();
    var added = 0, incoming = 0;
    list.forEach(function (m) {
      if (box.querySelector('.msg-row[data-id="' + m.id + '"]')) return;
      separator(m);
      box.appendChild(renderMessage(m));
      if (m.id > lastId) lastId = m.id;
      added++;
      if (!m.mine) incoming++;
    });
    if (!added) return;
    if (elEmpty) elEmpty.hidden = true;
    if (stick) toBottom();
    else if (incoming && elLatest) elLatest.hidden = false;   // sedang membaca pesan lama: tawarkan lompat ke yang terbaru
  }

  function markRead(ids) {
    (ids || []).forEach(function (id) {
      var n = box.querySelector('.msg-row.me[data-id="' + id + '"] .msg-read');
      if (n) n.textContent = '\u2713\u2713';
    });
  }
  function updateBadges(n) {
    if (typeof n !== 'number') return;
    var list = document.querySelectorAll('.js-chat-badge');
    for (var i = 0; i < list.length; i++) { list[i].textContent = n; list[i].style.display = n > 0 ? '' : 'none'; }
  }

  function url(action) { return api + '?action=' + action + (me === 'admin' ? '&user=' + encodeURIComponent(thread) : ''); }

  // ----- polling -----
  function poll() {
    if (busy || document.hidden) return;
    busy = true;
    fetch(url('poll') + '&after=' + lastId, { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.ok) { append(d.messages); markRead(d.read_ids); updateBadges(d.unread); } })
      .catch(function () {})
      .then(function () { busy = false; });
  }
  setInterval(poll, 3000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(); });

  // ----- lampiran: pesanan & foto -----
  function renderAttach() {
    if (!elAttach) return;
    elAttach.textContent = '';
    if (elOrderId && elOrderId.value && elOrderSel) {
      var opt = elOrderSel.querySelector('option[value="' + elOrderId.value + '"]');
      var c1 = el('span', 'attach-chip', '\uD83E\uDDFE Pesanan ' + (opt ? opt.getAttribute('data-label') : '#' + elOrderId.value) + ' ');
      var x1 = el('button', null, '\u2715'); x1.type = 'button';
      x1.addEventListener('click', function () { elOrderId.value = ''; if (elOrderSel) elOrderSel.value = ''; renderAttach(); });
      c1.appendChild(x1); elAttach.appendChild(c1);
    }
    if (elFile && elFile.files && elFile.files.length) {
      var c2 = el('span', 'attach-chip', '\uD83D\uDCF7 ' + elFile.files[0].name + ' ');
      var x2 = el('button', null, '\u2715'); x2.type = 'button';
      x2.addEventListener('click', function () { elFile.value = ''; renderAttach(); });
      c2.appendChild(x2); elAttach.appendChild(c2);
    }
  }
  var chipOrder = document.getElementById('chip-order');
  if (chipOrder && elOrderPick) chipOrder.addEventListener('click', function () { elOrderPick.hidden = !elOrderPick.hidden; });
  if (elOrderSel && elOrderId) elOrderSel.addEventListener('change', function () { elOrderId.value = elOrderSel.value; renderAttach(); });
  var btnPlus = document.getElementById('btn-plus');
  if (btnPlus && elFile) btnPlus.addEventListener('click', function () { elFile.click(); });
  if (elFile) elFile.addEventListener('change', renderAttach);
  renderAttach();

  // ----- emoji & balasan cepat -----
  var btnEmoji = document.getElementById('btn-emoji');
  if (btnEmoji && elEmojiPop) btnEmoji.addEventListener('click', function () { elEmojiPop.hidden = !elEmojiPop.hidden; });
  if (elEmojiPop && elText) elEmojiPop.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button[data-emoji]') : null;
    if (!b) return;
    var s = elText.selectionStart, t = elText.selectionEnd, v = elText.value, em = b.getAttribute('data-emoji');
    elText.value = v.slice(0, s) + em + v.slice(t);
    elText.focus();
    elText.selectionStart = elText.selectionEnd = s + em.length;
  });
  var quick = document.querySelectorAll('.chip.qr');
  for (var qi = 0; qi < quick.length; qi++) {
    quick[qi].addEventListener('click', function () { elText.value = this.getAttribute('data-text'); elText.focus(); });
  }

  // ----- tombol "Lihat yang paling baru" -----
  if (elLatest) elLatest.addEventListener('click', toBottom);
  box.addEventListener('scroll', function () { if (elLatest && nearBottom()) elLatest.hidden = true; });

  // ----- kirim pesan -----
  function autosize() { if (!elText) return; elText.style.height = 'auto'; elText.style.height = Math.min(elText.scrollHeight, 110) + 'px'; }
  if (elText) {
    elText.addEventListener('input', autosize);
    elText.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) {   // Enter = kirim, Shift+Enter = baris baru
        e.preventDefault();
        if (form.requestSubmit) form.requestSubmit(); else form.dispatchEvent(new Event('submit', { cancelable: true }));
      }
    });
  }
  form.addEventListener('submit', function (e) {
    if (!window.fetch || !window.FormData) return;   // tanpa fetch: kirim form biasa
    e.preventDefault();
    var hasText = elText && elText.value.trim() !== '';
    var hasFile = elFile && elFile.files && elFile.files.length;
    var hasOrder = elOrderId && elOrderId.value;
    if (!hasText && !hasFile && !hasOrder) return;
    clearError();
    var btn = form.querySelector('button[type=submit]');
    if (btn) btn.disabled = true;
    fetch(url('send'), { method: 'POST', body: new FormData(form), credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Server tidak merespons dengan benar.' }; }); })
      .then(function (d) {
        if (d && d.ok) {
          if (elText) { elText.value = ''; autosize(); }
          if (elFile) elFile.value = '';
          if (elOrderId) elOrderId.value = '';
          if (elOrderSel) elOrderSel.value = '';
          if (elOrderPick) elOrderPick.hidden = true;
          if (elEmojiPop) elEmojiPop.hidden = true;
          renderAttach();
          if (d.message) append([d.message]);
          toBottom();
          updateBadges(d.unread);
        } else {
          showError((d && d.error) || 'Gagal mengirim pesan.');
        }
      })
      .catch(function () { showError('Koneksi bermasalah, coba lagi.'); })
      .then(function () { if (btn) btn.disabled = false; if (elText) elText.focus(); });
  });

  toBottom();
})();
