// Hitung mundur war. Waktu dihitung dari jam server (bukan jam perangkat) supaya adil.
(function(){
  var offset = 0;   // serverNow - clientNow (ms)
  var el = document.querySelector('[data-server-now]');
  if (el) offset = parseInt(el.getAttribute('data-server-now'), 10) - Date.now();

  function fmt(ms){
    if (ms < 0) ms = 0;
    var s = Math.floor(ms / 1000), d = Math.floor(s / 86400); s -= d * 86400;
    var h = Math.floor(s / 3600); s -= h * 3600;
    var m = Math.floor(s / 60); s -= m * 60;
    var p = function(n){ return (n < 10 ? '0' : '') + n; };
    return (d > 0 ? d + ' hari ' : '') + p(h) + ':' + p(m) + ':' + p(s);
  }

  var timers = [].slice.call(document.querySelectorAll('.js-countdown'));
  var reloaded = false;
  function tick(){
    var now = Date.now() + offset;
    timers.forEach(function(t){
      var target = parseInt(t.getAttribute('data-target'), 10);
      var left = target - now;
      t.textContent = fmt(left);
      if (left <= 0 && !reloaded && t.getAttribute('data-reload') === '1'){
        reloaded = true;
        setTimeout(function(){ location.reload(); }, 600);
      }
    });
  }
  if (timers.length){ tick(); setInterval(tick, 1000); }

  // Update sisa stok & status secara live di halaman detail
  var box = document.getElementById('warLive');
  if (box){
    var url = box.getAttribute('data-status-url');
    var phase = box.getAttribute('data-phase');
    setInterval(function(){
      fetch(url, {cache: 'no-store'}).then(function(r){ return r.json(); }).then(function(d){
        if (!d || d.error) return;
        var st = document.getElementById('warStock'); if (st) st.textContent = d.stock;
        var bar = document.getElementById('warBar');
        if (bar && d.total > 0) bar.style.width = Math.round((d.total - d.stock) / d.total * 100) + '%';
        if (d.phase !== phase && !reloaded){ reloaded = true; location.reload(); }
      }).catch(function(){});
    }, 4000);
  }
})();
