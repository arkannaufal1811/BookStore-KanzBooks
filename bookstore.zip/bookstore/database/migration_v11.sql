-- ===================================================
-- MIGRATION V11 - KanzBooks
-- Membership: status "Dibatalkan" + catatan admin (alasan tolak / batal) yang tampil ke user
-- Aman dijalankan berulang kali. Jalankan di HeidiSQL / phpMyAdmin pada database "bookstore"
-- (butuh migration_v5.sql yang membuat tabel memberships)
-- ===================================================
USE bookstore;

ALTER TABLE memberships MODIFY status ENUM('pending','active','rejected','expired','cancelled') NOT NULL DEFAULT 'pending';

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'memberships' AND COLUMN_NAME = 'admin_note') = 0,
  'ALTER TABLE memberships ADD COLUMN admin_note VARCHAR(255) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'memberships' AND COLUMN_NAME = 'cancelled_at') = 0,
  'ALTER TABLE memberships ADD COLUMN cancelled_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
