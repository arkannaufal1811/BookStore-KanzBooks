-- ===================================================
-- MIGRATION V15 - KanzBooks
-- Benefit KanzBooks Club dibedakan per paket (Mingguan / Bulanan / Tahunan)
-- Menyimpan poin yang didapat tiap pesanan, supaya saat pesanan dibatalkan / diretur
-- poin yang ditarik pas (pengali poin beda tiap paket).
-- Jalankan lewat tab SQL (HeidiSQL / phpMyAdmin) dengan database "bookstore" aktif.
-- Pesanan lama dibiarkan NULL (tetap dihitung pakai aturan lama).
-- ===================================================
USE bookstore;

ALTER TABLE orders ADD COLUMN points_earned INT NULL DEFAULT NULL;
