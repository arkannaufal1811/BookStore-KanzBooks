-- ===================================================
-- MIGRATION V13 - KanzBooks
-- Chat pembeli <-> admin penjual (seperti chat TikTok Shop)
--   * satu percakapan per pembeli (user_id), pesan dari 'user' atau 'admin'
--   * pesan boleh dikaitkan ke satu pesanan (order_id) dan boleh berisi foto
--   * kind: text (obrolan biasa) | system (pesan otomatis penjual) | logistik (kartu informasi logistik)
--   * read_at menandai pesan sudah dibaca lawan bicara (dipakai untuk badge angka & centang)
-- Aman dijalankan berulang kali. Jalankan di HeidiSQL / phpMyAdmin pada database "bookstore"
-- ===================================================
USE bookstore;

CREATE TABLE IF NOT EXISTS chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    sender VARCHAR(5) NOT NULL,
    message VARCHAR(1000) NOT NULL DEFAULT '',
    image VARCHAR(255) DEFAULT NULL,
    order_id INT DEFAULT NULL,
    kind VARCHAR(10) NOT NULL DEFAULT 'text',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME DEFAULT NULL,
    INDEX idx_chat_thread (user_id, id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
);
