-- ===================================================
-- MIGRATION V16 - KanzBooks
-- 1) Buku alamat: pembeli simpan alamat sekali, bisa tambah alamat lain, tinggal pilih saat checkout (seperti Shopee)
-- 2) QRIS dinamis: nominal terkunci per pesanan, tanpa upload bukti. Pesanan baru diproses setelah admin
--    menekan "Pembayaran Diterima". Belum dibayar dalam batas waktu = pesanan batal otomatis & stok kembali.
-- Aman dijalankan berulang kali. Jalankan di HeidiSQL / phpMyAdmin pada database "bookstore"
-- ===================================================
USE bookstore;

CREATE TABLE IF NOT EXISTS user_addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    label VARCHAR(40) NOT NULL DEFAULT 'Rumah',
    recipient VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_addr_user (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Nama penerima disalin ke pesanan (supaya invoice/label tidak berubah walau alamat diedit nanti)
SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'shipping_name') = 0,
  'ALTER TABLE orders ADD COLUMN shipping_name VARCHAR(100) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- Status pembayaran QRIS: NULL (pesanan lama / non-QRIS) | menunggu | dibayar | kedaluwarsa
SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'pay_status') = 0,
  'ALTER TABLE orders ADD COLUMN pay_status VARCHAR(12) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'pay_expires_at') = 0,
  'ALTER TABLE orders ADD COLUMN pay_expires_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'paid_at') = 0,
  'ALTER TABLE orders ADD COLUMN paid_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
