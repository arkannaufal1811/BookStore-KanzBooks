-- ===================================================
-- MIGRATION V12 - KanzBooks
-- Alur pesanan ala marketplace:
--   * status maju satu arah (Baru > Diproses > Dikirim > Selesai), dicatat waktunya (shipped_at, completed_at)
--   * pembeli konfirmasi "Pesanan Diterima" -> Selesai
--   * pengajuan pengembalian barang setelah Selesai (batas hari: RETURN_WINDOW_DAYS di config/db.php), wajib bukti foto/video
--   * status baru "Dikembalikan" kalau pengajuan disetujui admin
-- Aman dijalankan berulang kali. Jalankan di HeidiSQL / phpMyAdmin pada database "bookstore"
-- ===================================================
USE bookstore;

ALTER TABLE orders MODIFY status ENUM('Baru','Diproses','Dikirim','Selesai','Dibatalkan','Dikembalikan') NOT NULL DEFAULT 'Baru';

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'shipped_at') = 0,
  'ALTER TABLE orders ADD COLUMN shipped_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'completed_at') = 0,
  'ALTER TABLE orders ADD COLUMN completed_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'return_status') = 0,
  'ALTER TABLE orders ADD COLUMN return_status VARCHAR(12) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'return_reason') = 0,
  'ALTER TABLE orders ADD COLUMN return_reason VARCHAR(255) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'return_proof') = 0,
  'ALTER TABLE orders ADD COLUMN return_proof VARCHAR(600) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'return_requested_at') = 0,
  'ALTER TABLE orders ADD COLUMN return_requested_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'return_note') = 0,
  'ALTER TABLE orders ADD COLUMN return_note VARCHAR(255) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'return_resolved_at') = 0,
  'ALTER TABLE orders ADD COLUMN return_resolved_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- Pesanan lama: isi tanggal kirim / selesai dengan tanggal pesanan supaya tidak kosong
-- (karena itu pesanan lama otomatis sudah lewat batas pengembalian)
UPDATE orders SET shipped_at = order_date WHERE status IN ('Dikirim','Selesai') AND shipped_at IS NULL;
UPDATE orders SET completed_at = order_date WHERE status = 'Selesai' AND completed_at IS NULL;
