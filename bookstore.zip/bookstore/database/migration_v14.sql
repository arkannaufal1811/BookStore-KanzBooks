-- ===================================================
-- Migration v14: War Buku (rilis buku limited edition)
-- Admin mengatur: buku, harga war, stok terbatas, jadwal buka & tutup,
-- dan batas beli per akun. Stok war terpisah dari stok toko biasa.
-- (kalau muncul error "Duplicate column", berarti sudah pernah dijalankan, abaikan saja)
-- ===================================================
CREATE TABLE IF NOT EXISTS book_wars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,                 -- nama edisi, contoh: "Edisi Tanda Tangan Penulis"
    description TEXT,
    cover_image VARCHAR(255) DEFAULT NULL,       -- opsional, kosong = pakai cover buku
    price DECIMAL(12,2) NOT NULL DEFAULT 0,      -- harga war
    total_stock INT NOT NULL DEFAULT 0,          -- jumlah awal yang dirilis
    stock INT NOT NULL DEFAULT 0,                -- sisa stok war
    max_per_user INT NOT NULL DEFAULT 1,         -- batas beli per akun
    start_at DATETIME NOT NULL,
    end_at DATETIME NOT NULL,
    status ENUM('active','cancelled') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_war_time (start_at, end_at),
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

-- Pesanan hasil war ditandai lewat war_id (dipakai untuk batas per akun & pengembalian stok war)
ALTER TABLE orders ADD COLUMN war_id INT DEFAULT NULL;
