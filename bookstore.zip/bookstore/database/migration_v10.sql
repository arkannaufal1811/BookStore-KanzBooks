-- ===================================================
-- MIGRATION V10 - KanzBooks
-- Pembatalan pesanan: oleh admin, atau pengajuan user yang diverifikasi admin
-- Aman dijalankan berulang kali. Jalankan di HeidiSQL / phpMyAdmin pada database "bookstore"
-- ===================================================
USE bookstore;

ALTER TABLE orders MODIFY status ENUM('Baru','Diproses','Dikirim','Selesai','Dibatalkan') NOT NULL DEFAULT 'Baru';

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'cancel_status') = 0,
  'ALTER TABLE orders ADD COLUMN cancel_status VARCHAR(12) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'cancel_reason') = 0,
  'ALTER TABLE orders ADD COLUMN cancel_reason VARCHAR(255) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'cancel_note') = 0,
  'ALTER TABLE orders ADD COLUMN cancel_note VARCHAR(255) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'cancelled_at') = 0,
  'ALTER TABLE orders ADD COLUMN cancelled_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
