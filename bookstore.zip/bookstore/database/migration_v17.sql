-- ===================================================
-- MIGRATION V17 - KanzBooks
-- Alur penerimaan: Dikirim -> pembeli tekan "Pesanan Diterima" -> pilih "Selesai" atau "Retur".
-- Retur wajib 2 bukti: foto kondisi barang + foto bukti nomor resi pengembalian.
-- Aman dijalankan berulang kali. Jalankan di HeidiSQL / phpMyAdmin pada database "bookstore".
-- ===================================================
USE bookstore;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'received_at') = 0,
  'ALTER TABLE orders ADD COLUMN received_at DATETIME DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'return_proof_resi') = 0,
  'ALTER TABLE orders ADD COLUMN return_proof_resi VARCHAR(255) DEFAULT NULL', 'SELECT 1'));
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- Pesanan lama yang sudah Selesai dianggap sudah diterima
UPDATE orders SET received_at = completed_at WHERE status = 'Selesai' AND received_at IS NULL AND completed_at IS NOT NULL;
