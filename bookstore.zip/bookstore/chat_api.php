<?php
// Endpoint JSON untuk chat: ?action=poll (ambil pesan baru) dan ?action=send (kirim pesan, POST).
// Dipakai chat.js di user/chat.php dan admin/chat.php. Pembeli hanya bisa mengakses percakapannya sendiri;
// admin memilih percakapan lewat parameter &user=ID.
require_once __DIR__ . '/includes/auth.php';
header('Content-Type: application/json; charset=utf-8');

function chat_out($data, $code = 200){
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!is_logged_in()) chat_out(['ok' => false, 'error' => 'Sesi login habis, silakan login lagi.'], 401);
if (!chat_ready($pdo)) chat_out(['ok' => false, 'error' => 'Fitur chat belum aktif (jalankan database/migration_v13.sql).'], 503);

$viewer = is_admin() ? 'admin' : 'user';
$threadUser = $viewer === 'admin' ? (int) ($_REQUEST['user'] ?? 0) : (int) $_SESSION['user_id'];
$csrfOk = csrf_valid();   // dibaca sebelum sesi dilepas
session_write_close();    // lepas kunci sesi supaya polling tidak menghambat halaman lain

if ($threadUser <= 0) chat_out(['ok' => false, 'error' => 'Percakapan tidak ditemukan.'], 400);
if ($viewer === 'admin'){
    $chk = $pdo->prepare("SELECT id FROM users WHERE id = ? AND role <> 'admin'");
    $chk->execute([$threadUser]);
    if (!$chk->fetch()) chat_out(['ok' => false, 'error' => 'Pembeli tidak ditemukan.'], 404);
}
$unread = function() use ($pdo, $viewer, $threadUser){
    return $viewer === 'admin' ? chat_unread_admin($pdo) : chat_unread_user($pdo, $threadUser);
};

$action = $_GET['action'] ?? '';

if ($action === 'poll' && $_SERVER['REQUEST_METHOD'] === 'GET'){
    $after = max(0, (int) ($_GET['after'] ?? 0));
    $rows = chat_fetch($pdo, $threadUser, $after);   // after = 0 (percakapan masih kosong saat dibuka): ambil semuanya
    chat_mark_read($pdo, $threadUser, $viewer);
    chat_out([
        'ok' => true,
        'messages' => array_map(function($r) use ($viewer){ return chat_format($r, $viewer); }, $rows),
        'read_ids' => chat_read_ids($pdo, $threadUser, $viewer),
        'unread' => $unread(),
    ]);
}

if ($action === 'send' && $_SERVER['REQUEST_METHOD'] === 'POST'){
    if (($_SERVER['CONTENT_LENGTH'] ?? 0) > 0 && empty($_POST) && empty($_FILES)){
        chat_out(['ok' => false, 'error' => 'Foto terlalu besar untuk server (post_max_size di php.ini).'], 413);
    }
    if (!$csrfOk) chat_out(['ok' => false, 'error' => 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.'], 403);
    list($okImg, $img) = chat_save_image($pdo, 'image');
    if (!$okImg) chat_out(['ok' => false, 'error' => $img], 422);
    $orderId = (int) ($_POST['order_id'] ?? 0) ?: null;
    list($ok, $res) = chat_send($pdo, $threadUser, $viewer, $_POST['message'] ?? '', $orderId, $img);
    if (!$ok){
        if ($img) @unlink(UPLOAD_DIR . $img);
        chat_out(['ok' => false, 'error' => $res], 422);
    }
    chat_mark_read($pdo, $threadUser, $viewer);
    $rows = chat_fetch($pdo, $threadUser, $res - 1, 1);   // pesan yang baru dibuat
    chat_out(['ok' => true, 'message' => $rows ? chat_format($rows[0], $viewer) : null, 'unread' => $unread()]);
}

chat_out(['ok' => false, 'error' => 'Permintaan tidak dikenal.'], 400);
