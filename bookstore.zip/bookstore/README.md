# KanzBooks - Sistem Penjualan Buku Online

Website toko buku dengan panel Admin & sisi User, dibuat dengan PHP native + MySQL (PDO), HTML, CSS, JavaScript.

## Fitur

**Admin**
- Login admin
- Dashboard (statistik, **stok menipis**, pesanan terbaru)
- CRUD Kategori Buku
- CRUD Data Buku (dengan upload cover, **pagination**)
- List & edit Data User (role admin/user)
- List Pesanan + ubah status (**Baru Dibuat** → Diproses → Dikirim → Selesai), badge notifikasi pesanan baru
- **Pesan Masuk** (lihat & kelola pesan dari Contact Us)
- **Laporan Penjualan** (grafik pendapatan 6 bulan, top 5 buku terlaris)
- Lihat & cetak Struk/Invoice pesanan
- **Alur pesanan ala marketplace**: status admin maju satu arah (Baru > Diproses > Dikirim > Selesai) dan tidak bisa dimundurkan; pembeli menekan "Pesanan Diterima"; **pengembalian barang** bisa diajukan pembeli dalam 7 hari sejak Selesai (`RETURN_WINDOW_DAYS` di `config/db.php`), wajib bukti foto/video, disetujui atau ditolak admin
- **Chat pembeli <-> admin** (ala TikTok Shop): halaman Pesan (peringatan belanja + chat), pesan masuk otomatis tanpa refresh, kirim foto, kirim kartu pesanan, pesan otomatis dari penjual saat pesanan diproses / dikirim (kartu informasi logistik) / selesai / dibatalkan / retur, pemisah waktu, centang dibaca
- **War Buku (limited edition)**: admin merilis buku edisi terbatas dengan harga war, stok terbatas, jadwal buka/tutup, dan batas beli per akun; bisa diakhiri / dibatalkan / diedit kapan saja
- **Membership KanzBooks Club**: laporan ringkas (pendapatan, member aktif, per paket), halaman detail + bukti pembayaran, setujui / tolak / **batalkan** membership dengan alasan yang tampil ke user

**User**
- Registrasi & Login
- **Lupa Password** (reset password)
- Home dengan Kategori Populer, Buku Terbaru, Rekomendasi
- Pencarian & filter buku (judul, penulis, kategori, harga, rating) + **pagination**
- Detail buku dengan **ulasan & rating pembeli** dan **buku terkait**
- **Wishlist** (simpan buku favorit)
- Halaman About Us
- Contact to Admin (kirim pesan)
- Add to Cart & kelola keranjang
- Checkout dengan 2 metode: **Transfer Bank** (Bank BSI 7370615769 a.n. Arkan Naufal; bukti transfer dikirim ke admin lewat WhatsApp) atau **QRIS / E-Wallet**
- Jumlah buku bisa diubah (+/-) langsung di keranjang & checkout, **dibatasi sesuai stok**
- **Ingatkan Saya** di halaman login (admin & user, login otomatis 30 hari)
- **Beli Langsung** (skip keranjang, langsung checkout) atau **+ Keranjang** (kumpulin dulu) — gaya TikTok Shop
- **War Buku**: halaman daftar war (live / akan datang / berakhir), hitung mundur berbasis jam server, sisa stok live, checkout khusus dengan anti-rebutan stok (row locking) dan batas per akun
- Info stok real-time di tiap kartu buku, badge "🔥 Stok Terbatas" kalau sisa ≤5
- Sistem anti-rebutan stok (row locking) — kalau 2 orang checkout stok terakhir bersamaan, cuma 1 yang berhasil, gak ada oversell
- **Riwayat pesanan dengan filter status** + detail item + lihat/cetak Struk

> Catatan: Admin dan User disimpan dalam satu tabel `users`, dibedakan lewat kolom `role`.
> Fitur **KanzBooks Club** aktif beneran: member dapat diskon 50% + gratis ongkir otomatis pas checkout, dan poin reward (1 poin/Rp10.000 belanja).

> Fitur "Lupa Password" menampilkan link reset langsung di layar (bukan dikirim email), karena server lokal (XAMPP) biasanya belum aktif layanan SMTP/email.

## Instalasi (Fresh Install / Baru Pertama Kali)

1. Copy folder `bookstore` ke `C:\xampp\htdocs\bookstore\`
2. Buat database baru `bookstore` di phpMyAdmin (collation `utf8mb4_unicode_ci`)
3. Import `database/bookstore.sql` (sudah termasuk semua tabel terbaru: wishlists, reviews, password_resets)
4. Jalankan: `http://localhost/bookstore/database/seed.php`
5. Login (admin dan user memakai halaman yang sama): `http://localhost/bookstore/user/login.php` (akun admin otomatis masuk ke dashboard admin)

## Update dari Instalasi Lama (sudah pernah pakai versi sebelumnya)

Kalau database `bookstore` kamu **sudah ada isinya** (buku, user, pesanan yang sudah kamu buat), JANGAN import ulang `bookstore.sql` (nanti data lama hilang / bentrok). Cukup jalankan migrasi tambahan ini:

1. Timpa semua file project dengan yang baru dari paket ini
2. Buka phpMyAdmin → pilih database `bookstore` → tab **SQL**
3. Copy-paste isi file `database/migration_v2.sql`, klik **Go**
4. Copy-paste isi file `database/migration_v2_messages_column.sql`, klik **Go**
5. Copy-paste isi file `database/migration_v3.sql`, klik **Go**
6. Copy-paste isi file `database/migration_v4.sql`, klik **Go**
7. Copy-paste isi file `database/migration_v5.sql`, klik **Go**
8. Copy-paste isi file `database/migration_v6.sql`, klik **Go**
9. Copy-paste isi file `database/migration_v7.sql`, klik **Go** (fitur "Ingatkan Saya")
10. Copy-paste isi file `database/migration_v8.sql`, klik **Go** (cadangan gambar bukti transfer di database)
11. Copy-paste isi file `database/migration_v9.sql`, klik **Go** (nomor HP, kurir & nomor resi)
12. Copy-paste isi file `database/migration_v10.sql`, klik **Go** (pembatalan pesanan)
13. Copy-paste isi file `database/migration_v11.sql`, klik **Go** (status Dibatalkan + catatan admin untuk membership)
14. Copy-paste isi file `database/migration_v12.sql`, klik **Go** (alur status satu arah, "Pesanan Diterima", pengembalian barang dengan bukti foto/video)
15. Copy-paste isi file `database/migration_v13.sql`, klik **Go** (chat pembeli dan admin)
16. Copy-paste isi file `database/migration_v14.sql`, klik **Go** (fitur War Buku)
17. Copy-paste isi file `database/migration_v15.sql`, klik **Go** (benefit KanzBooks Club beda per paket: pencatatan poin per pesanan)
18. Copy-paste isi file `database/migration_v16.sql`, klik **Go** (buku alamat + QRIS dinamis)
   (kalau muncul error "Duplicate column", berarti sudah pernah dijalankan, abaikan saja)

## Struktur Folder

```
bookstore/
├── admin/          -> semua halaman admin panel (+ messages.php, reports.php)
├── user/           -> semua halaman sisi toko/user (+ wishlist.php, forgot/reset_password.php)
├── config/db.php   -> koneksi database
├── includes/       -> header/footer & fungsi auth
├── database/       -> file SQL (bookstore.sql + migration_v2*.sql) + seed.php
├── assets/         -> css, js, images (logo, hero background)
├── uploads/        -> cover buku
├── struk.php       -> halaman struk/invoice (bisa dicetak)
└── index.php       -> redirect ke halaman home toko
```

## Kredensial Login

| Role  | Email                          | Password    |
|-------|----------------------------------|-------------|
| Admin | arknxyzz60@gmail.com            | naufal1811  |
| User  | malik2009@gmail.com             | password123 |
| User  | siti_nur08@gmail.com            | password123 |
| User  | anto_weni01@gmail.com           | password123 |
| User  | maulrani36@gmail.com            | password123 |

## Troubleshooting

- **Halaman Not Found**: pastikan folder `bookstore` ada langsung di `htdocs` (bukan `htdocs/bookstore/bookstore`)
- **Table 'users' already exists**: database `bookstore` masih ada isi lama, kosongkan dulu (drop semua tabel) sebelum import ulang
- **Fitur baru (wishlist/review/dsb) error "Table doesn't exist"**: berarti belum jalanin migration_v2.sql, lihat bagian "Update dari Instalasi Lama" di atas
- **Gambar bukti transfer lama hilang di admin**: file gambarnya ada di folder `uploads/` (nama `bukti_*.png`). Saat menimpa project, JANGAN hapus/ganti folder `uploads/` — gabungkan saja isinya. Admin sekarang menampilkan tulisan "File hilang" kalau file-nya tidak ada
- **Cover buku tidak muncul**: pastikan folder `uploads/` ke-copy semua isinya
- **Menu War Buku bilang belum aktif**: jalankan `database/migration_v14.sql`
- **Perubahan tampilan tidak muncul**: hard refresh browser (Ctrl+Shift+R)

## Buku Alamat & QRIS Dinamis (v16)

- **Alamat Saya** (`user/addresses.php`): pembeli isi alamat sekali, bisa tambah alamat lain, ganti alamat utama, ubah, hapus. Di checkout tinggal pilih. Alamat disalin ke pesanan, jadi invoice lama tidak berubah kalau alamat diedit.
- **QRIS dinamis**: QRIS statis toko (`QRIS_STATIC` di `config/db.php`) diubah otomatis jadi QRIS dengan nominal terkunci tiap pesanan (`includes/qris.php`). Nominal tidak bisa diubah pembeli di e-wallet. Tidak ada upload bukti untuk QRIS.
- **Alur QRIS**: pesanan dibuat berstatus "Menunggu pembayaran" -> pembeli scan QR di `user/pay_qris.php` -> admin cek dana masuk lalu tekan **Pembayaran Diterima** di detail pesanan -> baru bisa Diproses. Belum dikonfirmasi = tidak bisa diproses.
- **Batas bayar**: `QRIS_EXPIRE_MINUTES` (default 30 menit). Lewat batas, pesanan batal otomatis, stok & poin dikembalikan. Pembeli juga bisa membatalkan sendiri selama belum membayar.
- Kalau QRIS toko diganti: decode gambar QRIS barunya (isi teks QR) lalu tempel ke `QRIS_STATIC`.
