<?php
require_once __DIR__ . '/../includes/auth.php';

$id = (int) ($_GET['id'] ?? 0);
$w = (war_ready($pdo) && $id) ? war_get($pdo, $id) : null;
if (!$w){ header("Location: " . BASE_URL . "/user/wars.php"); exit; }

$early = war_early_seconds($pdo);   // member paket Bulanan/Tahunan boleh masuk lebih awal
$phase = war_phase($w, null, $early);
$pct = $w['total_stock'] > 0 ? round(((int) $w['total_stock'] - (int) $w['stock']) / $w['total_stock'] * 100) : 0;
$bought = is_logged_in() ? war_user_bought($pdo, $id, $_SESSION['user_id']) : 0;
$leftForUser = max(0, (int) $w['max_per_user'] - $bought);

$pageTitle = $w['title'];
$active = 'wars';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="section" style="display:flex; gap:40px; flex-wrap:wrap;" id="warLive" data-status-url="<?= BASE_URL ?>/user/war_status.php?id=<?= $id ?>" data-phase="<?= h($phase) ?>">
  <div style="width:280px; flex-shrink:0;">
    <div class="book-card" style="border-radius:10px;">
      <div class="cover">
        <span class="war-tag war-tag-<?= $phase ?>"><?= h(war_phase_label($phase)) ?></span>
        <img src="<?= h(war_cover_url($w)) ?>" alt="<?= h($w['title']) ?>">
      </div>
    </div>
  </div>
  <div style="flex:1; min-width:280px;">
    <div class="war-edition" style="font-size:13px;">⚡ LIMITED EDITION</div>
    <h1 style="font-size:28px; font-weight:800; margin:4px 0 6px;"><?= h($w['title']) ?></h1>
    <p style="color:var(--gray); margin-bottom:14px;"><?= h($w['book_title']) ?> &middot; oleh <?= h($w['author']) ?></p>
    <p style="font-size:26px; font-weight:800; color:var(--primary); margin-bottom:6px;"><?= rupiah($w['price']) ?> <s style="font-size:16px; color:var(--gray); font-weight:500;"><?= rupiah($w['normal_price']) ?></s></p>
    <?php if ($w['description']): ?><p style="color:#444; line-height:1.7; margin:14px 0;"><?= nl2br(h($w['description'])) ?></p><?php endif; ?>

    <div class="war-box">
      <div class="war-bar"><i id="warBar" style="width:<?= $pct ?>%"></i></div>
      <div style="display:flex; justify-content:space-between; font-size:14px; margin-top:8px;">
        <span>Sisa stok: <b id="warStock"><?= (int) $w['stock'] ?></b> dari <?= (int) $w['total_stock'] ?></span>
        <span>Maks. <?= (int) $w['max_per_user'] ?> per akun</span>
      </div>
      <div style="font-size:13px; color:var(--gray); margin-top:10px;">
        Buka: <?= date('d M Y H:i', strtotime($w['start_at'])) ?> WIB<?php if ($early > 0): ?> <b style="color:var(--primary);">(member: <?= date('H:i', strtotime($w['start_at']) - $early) ?> WIB 👑)</b><?php endif; ?><br>
        Tutup: <?= date('d M Y H:i', strtotime($w['end_at'])) ?> WIB
      </div>
    </div>

    <?php if ($phase === 'upcoming'): ?>
      <div class="war-count">
        <div>War dibuka dalam</div>
        <div class="war-count-num js-countdown" data-target="<?= (strtotime($w['start_at']) - $early) * 1000 ?>" data-reload="1"></div>
      </div>
      <button class="btn btn-primary" disabled style="width:100%; opacity:.5; cursor:not-allowed;">Belum dibuka</button>
    <?php elseif ($phase === 'live'): ?>
      <div class="war-count war-count-live">
        <div>War ditutup dalam</div>
        <div class="war-count-num js-countdown" data-target="<?= strtotime($w['end_at']) * 1000 ?>" data-reload="1"></div>
      </div>
      <?php if (!is_logged_in()): ?>
        <a href="<?= BASE_URL ?>/user/login.php" class="btn btn-primary" style="display:block; text-align:center;">Login dulu untuk ikut war</a>
      <?php elseif ($leftForUser <= 0): ?>
        <div class="alert alert-success">Kamu sudah mengamankan jatah war ini (<?= $bought ?> buku). Cek di riwayat pesanan.</div>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/user/war_checkout.php?id=<?= $id ?>" class="buy-now-btn" style="display:block; text-align:center; padding:16px; font-size:16px; border-radius:8px; text-decoration:none;">⚡ Ambil Sekarang</a>
        <p style="font-size:12.5px; color:var(--gray); margin-top:8px;">Stok baru dipastikan milikmu setelah pesanan dibuat di halaman berikutnya.</p>
      <?php endif; ?>
    <?php elseif ($phase === 'soldout'): ?>
      <div class="alert alert-error">Semua stok war ini sudah habis diambil.</div>
    <?php elseif ($phase === 'ended'): ?>
      <div class="alert alert-error">War ini sudah berakhir.</div>
    <?php else: ?>
      <div class="alert alert-error">War ini dibatalkan.</div>
    <?php endif; ?>
    <p style="margin-top:16px;"><a href="<?= BASE_URL ?>/user/wars.php" style="color:var(--primary); font-weight:700;">&larr; Semua war</a></p>
  </div>
</div>
<div data-server-now="<?= time() * 1000 ?>" hidden></div>
<script src="<?= BASE_URL ?>/assets/js/war.js"></script>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
