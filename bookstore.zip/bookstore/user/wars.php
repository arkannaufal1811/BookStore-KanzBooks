<?php
require_once __DIR__ . '/../includes/auth.php';

$ready = war_ready($pdo);
$live = $upcoming = $past = [];
if ($ready){
    $rows = $pdo->query("
        SELECT w.*, b.title AS book_title, b.author, b.price AS normal_price, b.cover_image AS book_cover
        FROM book_wars w JOIN books b ON b.id = w.book_id
        ORDER BY w.start_at ASC
    ")->fetchAll();
    foreach ($rows as $w){
        $ph = war_phase($w);
        if ($ph === 'live') $live[] = $w;
        elseif ($ph === 'upcoming') $upcoming[] = $w;
        elseif ($ph !== 'cancelled') $past[] = $w;
    }
    $past = array_slice(array_reverse($past), 0, 8);
}

function war_card($w){
    $ph = war_phase($w);
    $pct = $w['total_stock'] > 0 ? round(((int) $w['total_stock'] - (int) $w['stock']) / $w['total_stock'] * 100) : 0;
    ?>
    <a class="war-card" href="<?= BASE_URL ?>/user/war_detail.php?id=<?= $w['id'] ?>">
      <div class="war-card-cover">
        <span class="war-tag war-tag-<?= $ph ?>"><?= h(war_phase_label($ph)) ?></span>
        <img src="<?= h(war_cover_url($w)) ?>" alt="<?= h($w['title']) ?>">
      </div>
      <div class="war-card-body">
        <div class="war-edition"><?= h($w['title']) ?></div>
        <h3><?= h($w['book_title']) ?></h3>
        <div class="war-price"><?= rupiah($w['price']) ?> <s><?= rupiah($w['normal_price']) ?></s></div>
        <?php if ($ph === 'upcoming'): ?>
          <div class="war-meta">Buka <span class="js-countdown" data-target="<?= strtotime($w['start_at']) * 1000 ?>"></span></div>
        <?php elseif ($ph === 'live'): ?>
          <div class="war-bar"><i style="width:<?= $pct ?>%"></i></div>
          <div class="war-meta">Sisa <b><?= (int) $w['stock'] ?></b> dari <?= (int) $w['total_stock'] ?> &middot; tutup <span class="js-countdown" data-target="<?= strtotime($w['end_at']) * 1000 ?>"></span></div>
        <?php else: ?>
          <div class="war-meta"><?= date('d M Y', strtotime($w['start_at'])) ?></div>
        <?php endif; ?>
      </div>
    </a>
    <?php
}

$pageTitle = 'War Buku';
$active = 'wars';
require __DIR__ . '/../includes/store_header.php';
?>
<section class="section">
  <div class="sec-head"><h2>⚡ War Buku</h2></div>
  <p class="sec-sub">Rilis buku limited edition dengan stok terbatas dan waktu yang ditentukan. Siapa cepat dia dapat.</p>

  <?php if (!$ready): ?>
    <p style="color:#999;">Belum ada war saat ini.</p>
  <?php else: ?>
    <h3 class="war-h">Sedang berlangsung</h3>
    <div class="war-grid">
      <?php foreach ($live as $w) war_card($w); ?>
      <?php if (!$live): ?><p style="color:#999;">Tidak ada war yang sedang berlangsung.</p><?php endif; ?>
    </div>

    <h3 class="war-h">Akan datang</h3>
    <div class="war-grid">
      <?php foreach ($upcoming as $w) war_card($w); ?>
      <?php if (!$upcoming): ?><p style="color:#999;">Belum ada jadwal war berikutnya.</p><?php endif; ?>
    </div>

    <?php if ($past): ?>
    <h3 class="war-h">Sudah berakhir</h3>
    <div class="war-grid war-past">
      <?php foreach ($past as $w) war_card($w); ?>
    </div>
    <?php endif; ?>
  <?php endif; ?>
</section>
<div data-server-now="<?= time() * 1000 ?>" hidden></div>
<script src="<?= BASE_URL ?>/assets/js/war.js"></script>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
