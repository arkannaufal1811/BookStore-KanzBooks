<?php
require_once __DIR__ . '/../includes/auth.php';
require_login('/user/login.php');

$user = current_user();
pay_expire_unpaid($pdo);   // QRIS lewat batas bayar dibatalkan otomatis
auto_finish_received($pdo);   // diterima > batas hari tanpa memilih = otomatis Selesai

// Pembeli menekan "Pesanan Diterima": Dikirim -> Selesai (mulai menghitung batas pengembalian)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_received'])){
    $okRecv = csrf_valid() && confirm_received($pdo, (int) $_POST['confirm_received'], $user['id']);
    header("Location: " . BASE_URL . "/user/profile.php?msg=" . ($okRecv ? 'received' : 'received_fail'));
    exit;
}
// Pembeli menekan "Selesai" setelah barang diterima: Dikirim -> Selesai
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finish_order'])){
    $okFin = csrf_valid() && finish_order($pdo, (int) $_POST['finish_order'], $user['id']);
    header("Location: " . BASE_URL . "/user/profile.php?msg=" . ($okFin ? 'finished' : 'finish_fail'));
    exit;
}
$retReady = return_ready($pdo);
$statusFilter = $_GET['status'] ?? '';

$sql = "SELECT o.*, 
        (SELECT GROUP_CONCAT(b.title, ' x', oi.qty SEPARATOR ' | ') FROM order_items oi JOIN books b ON b.id=oi.book_id WHERE oi.order_id = o.id) AS item_summary
        FROM orders o WHERE o.user_id = ?";
$params = [$user['id']];
if ($statusFilter !== ''){
    $sql .= " AND o.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY o.order_date DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

$summary = $pdo->prepare("SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM orders WHERE user_id = ? AND status NOT IN ('Dibatalkan','Dikembalikan')");
$summary->execute([$user['id']]);
$summary = $summary->fetch();

function badgeClass($status){
    return match($status){
        'Baru' => 'badge-baru',
        'Diproses' => 'badge-diproses',
        'Dikirim' => 'badge-dikirim',
        'Selesai' => 'badge-selesai',
        'Dibatalkan' => 'badge-batal',
        'Dikembalikan' => 'badge-retur',
        default => ''
    };
}

$pageTitle = 'Profil Saya';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="cart-page">
  <h1 style="font-size:26px; font-weight:800; margin-bottom:6px;">👤 <?= h($user['name']) ?></h1>
  <p style="color:var(--gray); margin-bottom:20px;"><?= h($user['email']) ?></p>

  <?php if (is_member_user($pdo)): ?>
    <div class="member-badge" style="background:var(--primary); color:#fff; margin-bottom:20px;">
      👑 Member KanzBooks Club &middot; <?= user_points($pdo) ?> Poin
    </div>
    <div><?= membership_countdown(active_membership($pdo), false) ?></div>
  <?php else: ?>
    <div class="panel" style="padding:16px 20px; margin-bottom:20px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
      <span>Belum jadi member KanzBooks Club — gabung buat dapetin diskon sampai 50%, gratis ongkir, dan poin reward!</span>
      <a href="<?= BASE_URL ?>/user/join_club.php" class="btn btn-primary btn-sm">Gabung Sekarang</a>
    </div>
  <?php endif; ?>

  <?php if (addr_ready($pdo)): ?>
    <div class="panel" style="padding:14px 20px; margin-bottom:20px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
      <span>📍 <strong>Alamat Saya</strong> &mdash; simpan alamat sekali, tinggal pilih saat checkout.</span>
      <a href="<?= BASE_URL ?>/user/addresses.php" class="btn btn-outline btn-sm">Kelola Alamat</a>
    </div>
  <?php endif; ?>

  <div class="stat-cards" style="grid-template-columns:repeat(2,1fr); margin-bottom:26px;">
    <div class="stat-card pesanan"><div class="lbl">Total Pesanan</div><div class="val"><?= $summary['c'] ?></div></div>
    <div class="stat-card pendapatan"><div class="lbl">Total Belanja</div><div class="val" style="font-size:20px;"><?= rupiah($summary['t']) ?></div></div>
  </div>

  <?php if (($_GET['msg'] ?? '') === 'cancel_requested'): ?><div class="alert alert-success">Pengajuan pembatalan terkirim. Admin akan memeriksa pesananmu.</div><?php endif; ?>
  <?php if (($_GET['msg'] ?? '') === 'received'): ?><div class="alert alert-success">Barang ditandai sudah diterima. Sekarang pilih <strong>Selesai</strong> kalau barangnya aman, atau <strong>Pengembalian Dana dan Barang</strong> kalau ada masalah (wajib bukti kondisi barang dan bukti resi).</div><?php endif; ?>
  <?php if (($_GET['msg'] ?? '') === 'finished'): ?><div class="alert alert-success">Terima kasih! Pesanan ditandai Selesai dan sudah ditutup.</div><?php endif; ?>
  <?php if (($_GET['msg'] ?? '') === 'finish_fail'): ?><div class="alert alert-error">Pesanan tidak bisa diselesaikan. Mungkin ada pengajuan retur atau statusnya sudah berubah.</div><?php endif; ?>
  <?php if (($_GET['msg'] ?? '') === 'received_fail'): ?><div class="alert alert-error">Pesanan tidak bisa dikonfirmasi. Mungkin statusnya sudah berubah, muat ulang halaman.</div><?php endif; ?>
  <?php if (($_GET['msg'] ?? '') === 'return_requested'): ?><div class="alert alert-success">Pengajuan pengembalian terkirim beserta buktinya. Admin akan memeriksanya.</div><?php endif; ?>
    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:14px;">
    <h2 style="font-size:20px; font-weight:800;">Riwayat Pesanan</h2>
    <form method="get" style="display:flex; gap:8px; align-items:center;">
      <label style="font-weight:700; font-size:14px;">Filter Status:</label>
      <select name="status" onchange="this.form.submit()" style="padding:8px 12px; border:1.5px solid var(--border); border-radius:8px;">
        <option value="" <?= $statusFilter===''?'selected':'' ?>>Semua</option>
        <option value="Baru" <?= $statusFilter==='Baru'?'selected':'' ?>>Baru Dibuat</option>
        <option value="Diproses" <?= $statusFilter==='Diproses'?'selected':'' ?>>Diproses</option>
        <option value="Dikirim" <?= $statusFilter==='Dikirim'?'selected':'' ?>>Dikirim</option>
        <option value="Selesai" <?= $statusFilter==='Selesai'?'selected':'' ?>>Selesai</option>
        <option value="Dibatalkan" <?= $statusFilter==='Dibatalkan'?'selected':'' ?>>Dibatalkan</option>
        <option value="Dikembalikan" <?= $statusFilter==='Dikembalikan'?'selected':'' ?>>Dikembalikan</option>
      </select>
    </form>
  </div>

  <div class="panel">
    <table class="data-table">
      <thead><tr><th>No. Pesanan</th><th>Tanggal</th><th>Item</th><th>Total</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
        <tr>
          <td>#<?= str_pad($o['id'],5,'0',STR_PAD_LEFT) ?></td>
          <td><?= date('d F Y', strtotime($o['order_date'])) ?></td>
          <td style="max-width:260px;">
            <details>
              <summary style="cursor:pointer; color:var(--primary); font-weight:700; font-size:13px;">Lihat item<?= !empty($o['war_id']) ? ' &middot; ⚡ War' : '' ?></summary>
              <div style="font-size:13px; color:#555; margin-top:6px;"><?= nl2br(h(str_replace(' | ', "\n", $o['item_summary'] ?? '-'))) ?></div>
            </details>
          </td>
          <td><?= rupiah($o['total']) ?></td>
          <td>
            <span class="badge <?= badgeClass($o['status']) ?>"><?= h($o['status']) ?></span>
            <?php $cs = $o['cancel_status'] ?? ''; ?>
            <?php if ($cs === 'diajukan'): ?><br><span class="badge badge-minta" style="margin-top:4px;">Menunggu verifikasi pembatalan</span>
            <?php elseif ($cs === 'ditolak'): ?><br><span style="font-size:12px; color:#a51c1c;">Pengajuan batal ditolak<?= !empty($o['cancel_note']) ? ': ' . h($o['cancel_note']) : '' ?></span>
            <?php elseif ($o['status'] === 'Dibatalkan' && !empty($o['cancel_reason'])): ?><br><span style="font-size:12px; color:#777;">Alasan: <?= h($o['cancel_reason']) ?></span>
            <?php endif; ?>
            <?php // petunjuk: kapan boleh batal / terima / ajukan retur
              $rs = $o['return_status'] ?? ''; $daysLeft = $retReady ? return_days_left($o) : null; ?>
            <?php if (($o['pay_status'] ?? '') === 'menunggu' && $o['status'] === 'Baru'): ?>
              <br><span class="badge badge-minta" style="margin-top:4px;">Menunggu pembayaran QRIS</span>
              <span class="order-hint warn">Bayar sebelum <?= date('H:i', strtotime($o['pay_expires_at'])) ?> WIB, kalau lewat pesanan batal otomatis.</span>
            <?php elseif (in_array($o['status'], ['Baru','Diproses'], true) && empty($cs)): ?>
              <span class="order-hint">Masih bisa dibatalkan sebelum dikirim.</span>
            <?php elseif ($o['status'] === 'Dikirim' && !empty($o['received_at'])): ?>
              <?php if ($rs === 'diajukan'): ?><br><span class="badge badge-minta" style="margin-top:4px;">Pengembalian menunggu admin</span>
              <?php elseif ($rs === 'ditolak'): ?><span class="order-hint bad">Pengembalian ditolak<?= !empty($o['return_note']) ? ': ' . h($o['return_note']) : '' ?>. Tekan <strong>Selesai</strong> untuk menutup pesanan.</span>
              <?php else: ?><span class="order-hint warn">Barang sudah kamu terima. Pilih <strong>Selesai</strong> kalau aman, atau <strong>Pengembalian Dana dan Barang</strong> kalau ada masalah. Setelah Selesai pesanan tidak bisa dikembalikan.</span>
                <?php if ($daysLeft !== null && $daysLeft > 0): ?><br><span class="chip-days">Sisa <?= $daysLeft ?> hari, lewat itu otomatis Selesai</span><?php endif; ?>
              <?php endif; ?>
            <?php elseif ($o['status'] === 'Dikirim'): ?>
              <span class="order-hint warn">Sudah dikirim, tidak bisa dibatalkan. Tekan <strong>Pesanan Diterima</strong> kalau barang sudah sampai.</span>
            <?php elseif ($o['status'] === 'Selesai' && $retReady): ?>
              <?php if ($rs === 'diajukan'): ?><br><span class="badge badge-minta" style="margin-top:4px;">Pengembalian menunggu admin</span>
              <?php elseif ($rs === 'ditolak'): ?><span class="order-hint bad">Pengembalian ditolak<?= !empty($o['return_note']) ? ': ' . h($o['return_note']) : '' ?></span>
              <?php endif; ?>
            <?php elseif ($o['status'] === 'Dikembalikan'): ?>
              <span class="order-hint">Pengembalian disetujui<?= !empty($o['return_note']) ? ': ' . h($o['return_note']) : '' ?></span>
            <?php endif; ?>
          </td>
          <td>
            <div class="order-actions">
              <?php if (($o['pay_status'] ?? '') === 'menunggu' && $o['status'] === 'Baru'): ?>
                <a href="<?= BASE_URL ?>/user/pay_qris.php?id=<?= (int) $o['id'] ?>" class="btn btn-primary btn-sm">📱 Bayar Sekarang</a>
              <?php endif; ?>
              <a href="<?= BASE_URL ?>/struk.php?id=<?= $o['id'] ?>" target="_blank" class="btn btn-outline btn-sm">🧾 Invoice</a>
              <a href="<?= BASE_URL ?>/user/chat.php?order=<?= $o['id'] ?>" class="btn btn-outline btn-sm">💬 Chat Penjual</a>
              <?php if (array_key_exists('cancel_status', $o) && in_array($o['status'], ['Baru','Diproses'], true) && empty($o['cancel_status']) && ($o['pay_status'] ?? '') !== 'menunggu'): ?>
                <a href="<?= BASE_URL ?>/user/cancel_order.php?id=<?= $o['id'] ?>" class="btn btn-cancel btn-sm">✖ Ajukan Batal</a>
              <?php endif; ?>
              <?php if ($o['status'] === 'Dikirim' && empty($o['received_at'])): ?>
                <form method="post" onsubmit="return confirm('Barang sudah kamu terima? Setelah ini kamu punya <?= RETURN_WINDOW_DAYS ?> hari untuk memilih Selesai atau Pengembalian Dana dan Barang.');">
                  <?= csrf_field() ?><input type="hidden" name="confirm_received" value="<?= (int) $o['id'] ?>">
                  <button type="submit" class="btn btn-ok btn-sm">✔ Pesanan Diterima</button>
                </form>
              <?php elseif ($o['status'] === 'Dikirim' && !empty($o['received_at']) && $rs !== 'diajukan'): ?>
                <form method="post" onsubmit="return confirm('Tandai pesanan Selesai? Setelah ini pesanan ditutup dan tidak bisa dikembalikan lagi.');">
                  <?= csrf_field() ?><input type="hidden" name="finish_order" value="<?= (int) $o['id'] ?>">
                  <button type="submit" class="btn btn-ok btn-sm">✔ Selesai</button>
                </form>
              <?php endif; ?>
              <?php if ($retReady && return_eligible($o)): ?>
                <a href="<?= BASE_URL ?>/user/return_order.php?id=<?= $o['id'] ?>" class="btn btn-cancel btn-sm">↩ Pengembalian Dana dan Barang</a>
              <?php elseif ($retReady && in_array($rs, ['diajukan', 'disetujui', 'ditolak'], true)): ?>
                <a href="<?= BASE_URL ?>/user/return_order.php?id=<?= $o['id'] ?>" class="btn btn-outline btn-sm">Lihat Retur</a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$orders): ?>
        <tr><td colspan="6" style="text-align:center; color:#999;">Belum ada pesanan<?= $statusFilter ? ' dengan status ini' : '' ?></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
