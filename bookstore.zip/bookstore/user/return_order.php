<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();
$user = current_user();
$id = (int) ($_GET['id'] ?? 0);

if (!return_ready($pdo)){ header("Location: " . BASE_URL . "/user/profile.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");   // hanya pemilik pesanan
$stmt->execute([$id, $user['id']]);
$order = $stmt->fetch();
if (!$order){ header("Location: " . BASE_URL . "/user/profile.php"); exit; }

$reasons = ['Barang rusak atau cacat', 'Barang tidak sesuai pesanan (salah kirim)', 'Jumlah barang kurang / tidak lengkap', 'Barang tidak sesuai deskripsi', 'Lainnya'];
$error = '';
$canRequest = return_eligible($order);

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    if (($_SERVER['CONTENT_LENGTH'] ?? 0) > 0 && empty($_POST) && empty($_FILES)){
        // file terlalu besar: PHP membuang seluruh isi form
        $error = 'Total ukuran file melebihi batas server (post_max_size di php.ini). Kurangi ukuran atau jumlah file.';
    } elseif (!csrf_valid()){
        $error = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } elseif (!$canRequest){
        $error = 'Pesanan ini tidak bisa diajukan pengembalian.';
    } else {
        $pick = $_POST['reason_pick'] ?? '';
        $detail = trim($_POST['reason_detail'] ?? '');
        if (!in_array($pick, $reasons, true)){
            $error = 'Pilih alasan pengembalian.';
        } elseif (strlen($detail) < 10){
            $error = 'Jelaskan masalahnya dengan singkat (minimal 10 huruf).';
        } else {
            {
                // Bukti 1: kondisi barang (foto/video). Bukti 2: foto nomor resi pengembalian.
                list($ok, $res) = return_save_proofs($pdo, 'proof_item', 3, false, 'Foto kondisi barang wajib dilampirkan.');
                if (!$ok){
                    $error = $res;
                } else {
                    list($ok3, $res3) = return_save_proofs($pdo, 'proof_resi', 1, true, 'Foto bukti nomor resi wajib dilampirkan.');
                    if (!$ok3){
                        foreach ($res as $f) @unlink(UPLOAD_DIR . $f);
                        $error = $res3;
                    } else {
                        list($ok2, $msg2) = request_return($pdo, $id, $user['id'], $pick . ': ' . $detail, $res, $res3[0]);
                        if ($ok2){
                            header("Location: " . BASE_URL . "/user/profile.php?msg=return_requested");
                            exit;
                        }
                        foreach (array_merge($res, $res3) as $f) @unlink(UPLOAD_DIR . $f);   // pengajuan gagal: buang file yang barusan diunggah
                        $error = $msg2;
                    }
                }
            }
        }
    }
}

$items = $pdo->prepare("SELECT b.title, oi.qty FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = ?");
$items->execute([$id]);
$items = $items->fetchAll();

$rs = $order['return_status'] ?? '';
$daysLeft = return_days_left($order);
$deadline = return_deadline($order);

$pageTitle = 'Ajukan Pengembalian Dana dan Barang';
$active = 'profile';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="section" style="max-width:640px;">
  <div class="sec-head"><h2>Ajukan pengembalian dana dan barang</h2></div>

  <div style="border:1.5px solid #222; border-radius:12px; padding:16px 18px; margin-bottom:18px; font-size:14px;">
    <strong>Pesanan #<?= str_pad($order['id'], 5, '0', STR_PAD_LEFT) ?></strong> &middot; <?= date('d F Y', strtotime($order['order_date'])) ?><br>
    <?php foreach ($items as $it): ?><?= h($it['title']) ?> &times; <?= (int) $it['qty'] ?><br><?php endforeach; ?>
    <strong>Total: <?= rupiah($order['total']) ?></strong> &middot; Status: <?= h($order['status']) ?>
    <?php if ($order['status'] === 'Dikirim' && !empty($order['received_at'])): ?>
      <br>Diterima pada <?= date('d F Y H:i', strtotime($order['received_at'])) ?> &middot; batas pengajuan <strong><?= date('d F Y H:i', $deadline) ?></strong>
      <?php if ($daysLeft > 0 && $rs === ''): ?><br><span class="chip-days">Sisa <?= $daysLeft ?> hari</span><?php endif; ?>
    <?php endif; ?>
  </div>

  <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

  <?php if (!$canRequest): ?>
    <div class="alert alert-error">
      <?php if ($rs === 'diajukan'): ?>Pengajuan pengembalian sudah dikirim dan sedang diperiksa admin.
      <?php elseif ($rs === 'disetujui' || $order['status'] === 'Dikembalikan'): ?>Pengembalian pesanan ini <strong>disetujui</strong><?= !empty($order['return_note']) ? ': ' . h($order['return_note']) : '' ?>.
      <?php elseif ($rs === 'ditolak'): ?>Pengajuan pengembalian ditolak admin<?= !empty($order['return_note']) ? ': ' . h($order['return_note']) : '' ?>. Kalau masih ada kendala, hubungi admin lewat halaman Contact.
      <?php elseif (!in_array($order['status'], ['Selesai', 'Dikirim'], true) || ($order['status'] === 'Dikirim' && empty($order['received_at']))): ?>Pengembalian hanya bisa diajukan setelah kamu menekan <strong>Pesanan Diterima</strong>. Pesanan ini berstatus <?= h($order['status']) ?>.
      <?php elseif ($order['status'] === 'Selesai'): ?>Pesanan ini sudah <strong>Selesai</strong> dan ditutup, jadi tidak bisa dikembalikan lagi. Pengembalian hanya bisa diajukan sebelum menekan Selesai.
      <?php else: ?>Batas pengajuan pengembalian (<?= RETURN_WINDOW_DAYS ?> hari sejak barang diterima) sudah lewat. Silakan hubungi admin lewat halaman Contact.
      <?php endif; ?>
    </div>
    <?php if (in_array($rs, ['diajukan', 'disetujui', 'ditolak'], true) && !empty($order['return_proof'])): ?>
      <p style="font-weight:700; margin-top:14px;">Bukti yang kamu kirim</p>
      <p style="font-size:13px; color:#6f5c7a;">Alasan: <?= h($order['return_reason'] ?? '-') ?></p>
      <p style="font-size:13px; font-weight:700;">1. Kondisi barang</p>
      <?= proof_media_html($pdo, $order['return_proof']) ?>
      <?php if (!empty($order['return_proof_resi'])): ?>
      <p style="font-size:13px; font-weight:700;">2. Bukti nomor resi</p>
      <?= proof_media_html($pdo, $order['return_proof_resi']) ?>
      <?php endif; ?>
    <?php endif; ?>
    <a href="<?= BASE_URL ?>/user/profile.php" class="btn btn-outline" style="margin-top:12px;">Kembali</a>
  <?php else: ?>
    <p style="font-size:14px; color:#6f5c7a; margin-bottom:14px;">Pengajuan <strong>wajib disertai 2 bukti</strong>: foto kondisi barang dan foto bukti nomor resi. Pengajuan akan diperiksa admin dan hanya bisa dikirim <strong>satu kali</strong> per pesanan.</p>
    <form method="post" enctype="multipart/form-data" class="return-form">
      <?= csrf_field() ?>
      <div class="form-group" style="margin-top:12px;">
        <label style="font-weight:700; display:block; margin-bottom:6px;">Alasan</label>
        <select name="reason_pick" required style="width:100%; padding:12px; border:1.5px solid #ccc; border-radius:8px;">
          <option value="">-- Pilih alasan --</option>
          <?php foreach ($reasons as $r): ?><option value="<?= h($r) ?>" <?= (($_POST['reason_pick'] ?? '') === $r) ? 'selected' : '' ?>><?= h($r) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin-top:12px;">
        <label style="font-weight:700; display:block; margin-bottom:6px;">Jelaskan masalahnya</label>
        <textarea name="reason_detail" rows="3" required maxlength="200" placeholder="Contoh: sampul buku robek dan halaman 40-60 terlepas" style="width:100%; padding:12px; border:1.5px solid #ccc; border-radius:8px;"><?= h($_POST['reason_detail'] ?? '') ?></textarea>
      </div>
      <div class="form-group" style="margin-top:12px;">
        <label style="font-weight:700; display:block; margin-bottom:6px;">Bukti 1: Foto kondisi barang <span style="color:#a51c1c;">(wajib)</span></label>
        <input type="file" name="proof_item[]" multiple required accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" style="width:100%;">
        <p class="hint">Maksimal 3 file. Foto: JPG, PNG, WEBP (maks 5 MB). Video: MP4, WEBM, MOV (maks 20 MB). Tunjukkan bagian yang rusak / salah / kurang.</p>
      </div>
      <div class="form-group" style="margin-top:12px;">
        <label style="font-weight:700; display:block; margin-bottom:6px;">Bukti 2: Foto bukti nomor resi <span style="color:#a51c1c;">(wajib)</span></label>
        <input type="file" name="proof_resi[]" required accept="image/jpeg,image/png,image/webp" style="width:100%;">
        <p class="hint">1 foto resi pengiriman pengembalian (nomor resi harus terbaca jelas). JPG, PNG, WEBP maks 5 MB.</p>
      </div>
      <div style="display:flex; gap:10px; margin-top:16px;">
        <button type="submit" class="btn btn-primary">Kirim Pengajuan</button>
        <a href="<?= BASE_URL ?>/user/profile.php" class="btn btn-outline">Kembali</a>
      </div>
    </form>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
