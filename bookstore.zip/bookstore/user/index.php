<?php
require_once __DIR__ . '/../includes/auth.php';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name LIMIT 6")->fetchAll();
$books = $pdo->query("
    SELECT b.*, c.name AS category_name FROM books b
    JOIN categories c ON c.id = b.category_id
    ORDER BY b.rating DESC LIMIT 8
")->fetchAll();
// Terlaris: 1 buku dengan penjualan terbanyak (pesanan batal/retur/QRIS belum dibayar tidak dihitung), seri -> rating tertinggi
$best = null;
$soldMap = sold_counts($pdo);
if ($soldMap){
    arsort($soldMap);
    $topIds = array_slice(array_keys(array_filter($soldMap, fn($n) => $n > 0)), 0, 12);
    if ($topIds){
        $in = implode(',', array_map('intval', $topIds));
        $cand = $pdo->query("SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON c.id = b.category_id WHERE b.id IN ($in)")->fetchAll();
        usort($cand, function($a, $b) use ($soldMap){
            return [$soldMap[$b['id']], $b['rating']] <=> [$soldMap[$a['id']], $a['rating']];
        });
        $best = $cand[0] ?? null;
        if ($best){ $best['sold'] = $soldMap[$best['id']]; $best['rv'] = book_rating($pdo, $best); }
    }
}
$newestBooks = $pdo->query("
    SELECT b.*, c.name AS category_name FROM books b
    JOIN categories c ON c.id = b.category_id
    ORDER BY b.created_at DESC, b.id DESC LIMIT 4
")->fetchAll();

$voices = [];
try {
    $voices = $pdo->query("SELECT r.rating, r.comment, u.name AS uname, b.title FROM reviews r JOIN users u ON u.id = r.user_id JOIN books b ON b.id = r.book_id WHERE r.comment IS NOT NULL AND CHAR_LENGTH(TRIM(r.comment)) >= 15 ORDER BY r.rating DESC, r.created_at DESC LIMIT 3")->fetchAll();
} catch (Throwable $e) {}
$catIcons = ['Fiksi'=>'📖','Novel'=>'📖','Pengembangan Diri'=>'💡','Bisnis'=>'💼','Teknologi'=>'💻','Komputer'=>'💻','Sejarah'=>'🌍','Anak-anak'=>'🧒','Filsafat'=>'🦉','Pelajaran'=>'🏫','Sastra Indonesia'=>'✍️'];

function wishlist_btn($pdo, $b){
    $active = is_wishlisted($pdo, $b['id']) ? 'active' : '';
    $redirect = urlencode($_SERVER['REQUEST_URI']);
    if (!is_logged_in()){
        return '<a href="' . BASE_URL . '/user/login.php" class="wishlist-heart" title="Login untuk simpan ke wishlist">♡</a>';
    }
    return '<a href="' . BASE_URL . '/user/wishlist.php?toggle=' . $b['id'] . '&redirect=' . $redirect . '" class="wishlist-heart ' . $active . '" title="Simpan ke wishlist">♥</a>';
}

function render_book_card($b){
    global $pdo;
    $lowStock = $b['stock'] > 0 && $b['stock'] <= 5;
    $soldOut = $b['stock'] <= 0;
    ?>
    <div class="book-card">
      <div class="cover">
        <?php if ($lowStock): ?><span class="ribbon ribbon-hot">Stok terbatas</span><?php endif; ?>
        <?= wishlist_btn($pdo, $b) ?>
        <a href="<?= BASE_URL ?>/user/book_detail.php?id=<?= $b['id'] ?>">
          <img src="<?= $b['cover_image'] ? UPLOAD_URL . h($b['cover_image']) : 'https://placehold.co/200x280?text=' . urlencode($b['title']) ?>" alt="<?= h($b['title']) ?>">
        </a>
      </div>
      <div class="book-info">
        <a href="<?= BASE_URL ?>/user/book_detail.php?id=<?= $b['id'] ?>"><h3><?= h($b['title']) ?></h3></a>
        <div class="author"><?= h($b['author']) ?></div>
        <div class="price-row">
          <span class="price"><?= rupiah($b['price']) ?></span>
          <span class="rating"><?= number_format($b['rating'],1) ?> ★</span>
        </div>
        <div class="stock-info <?= $lowStock?'urgent':'' ?>">
          <?= $soldOut ? 'Stok habis' : ($lowStock ? "Sisa {$b['stock']}, segera habis" : "Stok: {$b['stock']}") ?><?= sold_label($pdo, $b['id']) ?>
        </div>
        <?php if (!$soldOut): ?>
        <div class="card-btn-row">
          <form method="post" action="<?= BASE_URL ?>/user/buy_now.php">
            <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
            <input type="hidden" name="qty" value="1">
            <button type="submit" class="buy-now-btn">Beli Langsung</button>
          </form>
          <form method="post" action="<?= BASE_URL ?>/user/cart.php">
            <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
            <input type="hidden" name="action" value="add">
            <button type="submit" class="add-btn">+ Keranjang</button>
          </form>
        </div>
        <?php else: ?>
          <button type="button" class="add-btn" disabled style="opacity:.5; cursor:not-allowed;">Stok Habis</button>
        <?php endif; ?>
      </div>
    </div>
    <?php
}

$pageTitle = 'Home';
$active = 'home';
require __DIR__ . '/../includes/store_header.php';
?>

<?php $heroCovers = array_slice($books, 0, 3); ?>
<section class="shop-hero">
  <div class="shop-hero-in">
    <div>
      <h1>Temukan buku<br><span class="hl">favoritmu</span> di sini</h1>
      <p>Mood-mu lagi apa hari ini? Pengen tenggelam di dunia fantasi, pengen belajar hal baru, atau lagi butuh bacaan yang bikin pikiran lebih tenang? Dari fiksi sampai filsafat, dari self-improvement sampai bisnis, tinggal pilih. Bayar via COD, transfer, atau QRIS, lalu bukunya meluncur ke rumahmu.</p>
      <div class="cta">
        <a href="<?= BASE_URL ?>/user/books.php" class="cta-main">Lihat semua buku</a>
        <a href="<?= BASE_URL ?>/user/join_club.php" class="cta-alt">Gabung KanzBooks Club</a>
      </div>
    </div>
    <div class="hero-covers">
      <?php foreach ($heroCovers as $hb): ?>
        <a class="hc" href="<?= BASE_URL ?>/user/book_detail.php?id=<?= $hb['id'] ?>" title="<?= h($hb['title']) ?>">
          <?php if ($hb['cover_image']): ?><img src="<?= UPLOAD_URL . h($hb['cover_image']) ?>" alt="<?= h($hb['title']) ?>"><?php else: ?><?= h($hb['title']) ?><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php $warBanner = war_highlights($pdo, 1); if ($warBanner): $wb = $warBanner[0]; $wbLive = war_phase($wb) === 'live'; ?>
<div class="war-banner"><div class="war-banner-in">
  <img src="<?= h(war_cover_url($wb)) ?>" alt="">
  <div class="t">
    <b>⚡ <?= $wbLive ? 'WAR SEDANG BERLANGSUNG' : 'WAR SEGERA DIBUKA' ?>: <?= h($wb['title']) ?></b>
    <div><?= h($wb['book_title']) ?> &middot; <?= rupiah($wb['price']) ?> &middot; stok terbatas <?= (int) $wb['stock'] ?> &middot; <?= $wbLive ? 'tutup' : 'buka' ?> <span class="js-countdown" data-target="<?= strtotime($wbLive ? $wb['end_at'] : $wb['start_at']) * 1000 ?>"></span></div>
  </div>
  <a class="go" href="<?= BASE_URL ?>/user/war_detail.php?id=<?= $wb['id'] ?>"><?= $wbLive ? 'Ikut war' : 'Lihat detail' ?></a>
</div></div>
<div data-server-now="<?= time() * 1000 ?>" hidden></div>
<script src="<?= BASE_URL ?>/assets/js/war.js"></script>
<?php endif; ?>

<?php $totalSold = array_sum(sold_counts($pdo)); ?>
<div class="service-strip">
  <?php if ($totalSold > 0): ?><div><b><?= number_format($totalSold, 0, ',', '.') ?> buku</b> sudah terjual</div><?php endif; ?>
  <div><b>Gratis ongkir</b> min. belanja Rp150.000</div>
  <div><b>Transfer Bank</b> &amp; <b>E-Wallet</b></div>
  <div><b>Original</b> buku baru dari penerbit</div>
</div>

<section class="section">
  <div class="sec-head"><h2>Mau baca apa hari ini?</h2><a href="<?= BASE_URL ?>/user/books.php">Semua kategori</a></div>
  <div class="chips">
    <?php foreach ($categories as $c): ?>
      <a href="<?= BASE_URL ?>/user/books.php?category=<?= $c['id'] ?>"><?= h($c['name']) ?></a>
    <?php endforeach; ?>
  </div>
</section>

<?php if ($best): $bSoldOut = $best['stock'] <= 0; $bDesc = trim((string) $best['description']); if (strlen($bDesc) > 230){ $bDesc = (preg_match('/^.{1,230}/us', $bDesc, $mm) ? $mm[0] : substr($bDesc, 0, 230)) . '...'; } ?>
<section class="section">
  <div class="best-spot">
    <a class="best-cover" href="<?= BASE_URL ?>/user/book_detail.php?id=<?= $best['id'] ?>">
      <img src="<?= $best['cover_image'] ? UPLOAD_URL . h($best['cover_image']) : 'https://placehold.co/260x380?text=' . urlencode($best['title']) ?>" alt="<?= h($best['title']) ?>">
    </a>
    <div class="best-body">
      <span class="best-badge">👑 Buku Terlaris #1 di KanzBooks</span>
      <a href="<?= BASE_URL ?>/user/book_detail.php?id=<?= $best['id'] ?>"><h2><?= h($best['title']) ?></h2></a>
      <div class="best-author">oleh <?= h($best['author']) ?> &middot; <?= h($best['category_name']) ?></div>
      <div class="best-stats">
        <div><b><?= number_format($best['sold'], 0, ',', '.') ?></b><span>eksemplar terjual</span></div>
        <div><b><?= number_format($best['rv']['rating'], 1) ?> ★</b><span><?= $best['rv']['count'] > 0 ? $best['rv']['count'] . ' ulasan' : 'rating pembaca' ?></span></div>
        <div><b><?= $bSoldOut ? 'Habis' : (int) $best['stock'] ?></b><span><?= $bSoldOut ? 'stok kosong' : 'stok tersedia' ?></span></div>
      </div>
      <?php if ($bDesc !== ''): ?><p class="best-desc"><?= h($bDesc) ?></p><?php endif; ?>
      <div class="best-price"><?= rupiah($best['price']) ?></div>
      <div class="best-actions">
        <?php if (!$bSoldOut): ?>
        <form method="post" action="<?= BASE_URL ?>/user/buy_now.php"><input type="hidden" name="book_id" value="<?= $best['id'] ?>"><input type="hidden" name="qty" value="1"><button type="submit" class="best-btn best-btn-main">Beli Langsung</button></form>
        <form method="post" action="<?= BASE_URL ?>/user/cart.php"><input type="hidden" name="book_id" value="<?= $best['id'] ?>"><input type="hidden" name="action" value="add"><button type="submit" class="best-btn">+ Keranjang</button></form>
        <?php endif; ?>
        <a href="<?= BASE_URL ?>/user/book_detail.php?id=<?= $best['id'] ?>" class="best-btn">Lihat detail</a>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section">
  <div class="sec-head"><h2>Baru masuk rak</h2><a href="<?= BASE_URL ?>/user/books.php">Lihat semua</a></div>
  <p class="sec-sub">Judul-judul terbaru di toko kami, stoknya masih banyak.</p>
  <div class="book-grid">
    <?php foreach ($newestBooks as $b): render_book_card($b); endforeach; ?>
    <?php if (!$newestBooks): ?>
      <p style="color:#999;">Belum ada buku.</p>
    <?php endif; ?>
  </div>
</section>

<section class="section">
  <div class="sec-head"><h2>Paling disukai pembaca</h2><a href="<?= BASE_URL ?>/user/books.php">Lihat semua</a></div>
  <p class="sec-sub">Diurutkan dari rating tertinggi.</p>
  <div class="book-grid">
    <?php foreach ($books as $b): render_book_card($b); endforeach; ?>
  </div>
</section>

<section class="section">
  <div class="sec-head"><h2>Belanja buku tanpa ribet</h2></div>
  <div class="why">
    <div><h3>Bayar sesuka kamu</h3><p>Transfer Bank BSI, atau QRIS dan e-wallet. Pilih yang paling nyaman buatmu.</p></div>
    <div><h3>Pantau pesananmu</h3><p>Lihat status dari diproses sampai selesai, lengkap dengan kurir dan nomor resi di invoice.</p></div>
    <div><h3>Lebih hemat jadi member</h3><p>Diskon sampai 50%, gratis ongkir, dan poin reward untuk member KanzBooks Club.</p></div>
  </div>
</section>

<?php if ($voices): ?>
<section class="section">
  <div class="sec-head"><h2>Kata pembaca</h2></div>
  <div class="voices">
    <?php foreach ($voices as $v): ?>
      <div class="voice">
        <div class="stars"><?= str_repeat('★', (int) $v['rating']) ?></div>
        <?php
          $cm = trim($v['comment']);
          if (strlen($cm) > 140){ $cm = (preg_match('/^.{1,140}/us', $cm, $mm) ? $mm[0] : substr($cm, 0, 140)) . '...'; }
        ?>
        <q><?= h($cm) ?></q>
        <div class="who"><b><?= h($v['uname']) ?></b> tentang <?= h($v['title']) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="section">
  <?php $isMember = is_member_user($pdo); ?>
  <div class="club">
    <div>
      <h2>Baca lebih banyak, bayar lebih sedikit</h2>
      <?php if ($isMember): ?>
        <p>Kamu sudah jadi member KanzBooks Club. Benefit paketmu otomatis berlaku di setiap pesanan.</p>
        <?= membership_countdown(active_membership($pdo), true) ?>
        <div><span class="club-cta done">Sudah bergabung</span></div>
      <?php else: ?>
        <p>Jadi member KanzBooks Club dan nikmati diskon sampai 50% untuk semua buku, plus gratis ongkir dan poin reward. Makin panjang paketnya, makin gede benefitnya.</p>
        <a href="<?= BASE_URL ?><?= is_logged_in() ? '/user/join_club.php' : '/user/register.php' ?>" class="club-cta">Gabung sekarang</a>
      <?php endif; ?>
    </div>
    <ul>
      <li><svg viewBox="0 0 24 24"><path d="M5 12.500l4.500 4.500L19 7.500"/></svg> Diskon 15% – 50% di semua buku (tergantung paket)</li>
      <li><svg viewBox="0 0 24 24"><path d="M5 12.500l4.500 4.500L19 7.500"/></svg> Gratis ongkir (paket Mingguan min. belanja Rp50.000)</li>
      <li><svg viewBox="0 0 24 24"><path d="M5 12.500l4.500 4.500L19 7.500"/></svg> Poin reward 1x – 2x dari setiap pembelian</li>
      <li><svg viewBox="0 0 24 24"><path d="M5 12.500l4.500 4.500L19 7.500"/></svg> Early sale War Buku lebih awal (paket Bulanan & Tahunan)</li>
    </ul>
  </div>
</section>

<?php require __DIR__ . '/../includes/store_footer.php'; ?>
