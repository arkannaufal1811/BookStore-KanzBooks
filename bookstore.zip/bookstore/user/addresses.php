<?php
require_once __DIR__ . '/../includes/auth.php';
require_login('/user/login.php');

$userId = (int) $_SESSION['user_id'];
$fromCheckout = (($_GET['from'] ?? $_POST['from'] ?? '') === 'checkout');
$self = BASE_URL . '/user/addresses.php' . ($fromCheckout ? '?from=checkout' : '');
$ready = addr_ready($pdo);
$error = ''; $notice = '';
$editing = null;

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST'){
    if (!csrf_valid()){
        $error = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } else {
        $act = $_POST['act'] ?? '';
        $aid = (int) ($_POST['id'] ?? 0);
        if ($act === 'save'){
            list($d, $err) = addr_validate($_POST);
            if ($d){
                list($newId, $err) = addr_save($pdo, $userId, $d, !empty($_POST['is_default']), $aid ?: null);
                if ($newId){ header("Location: $self" . ($fromCheckout ? '&' : '?') . "msg=saved"); exit; }
            }
            $error = $err;
            $editing = array_merge(['id' => $aid], $_POST);
        } elseif ($act === 'default'){
            if (addr_get($pdo, $userId, $aid)) addr_set_default($pdo, $userId, $aid);
            header("Location: $self" . ($fromCheckout ? '&' : '?') . "msg=default"); exit;
        } elseif ($act === 'delete'){
            addr_delete($pdo, $userId, $aid);
            header("Location: $self" . ($fromCheckout ? '&' : '?') . "msg=deleted"); exit;
        }
    }
}
if ($ready && isset($_GET['edit']) && !$editing) $editing = addr_get($pdo, $userId, (int) $_GET['edit']);
$msg = $_GET['msg'] ?? '';
$addrs = $ready ? addr_list($pdo, $userId) : [];
$showForm = $editing || isset($_GET['new']) || ($ready && !$addrs);

$pageTitle = 'Alamat Saya';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="cart-page">
  <h1 style="font-size:26px; font-weight:800; margin-bottom:6px;">📍 Alamat Saya</h1>
  <p style="color:var(--gray); margin-bottom:20px;">Isi sekali, tersimpan terus. Saat checkout tinggal pilih alamat yang mau dipakai.</p>

  <?php if (!$ready): ?>
    <div class="alert alert-error">Fitur alamat belum aktif. Jalankan <code>database/migration_v16.sql</code> dulu.</div>
  <?php else: ?>
  <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
  <?php if ($msg === 'saved'): ?><div class="alert alert-success">Alamat disimpan.</div>
  <?php elseif ($msg === 'default'): ?><div class="alert alert-success">Alamat utama diganti.</div>
  <?php elseif ($msg === 'deleted'): ?><div class="alert alert-success">Alamat dihapus.</div><?php endif; ?>

  <?php foreach ($addrs as $a): ?>
  <div class="panel" style="padding:16px 20px; margin-bottom:12px; <?= $a['is_default'] ? 'border:1.5px solid var(--primary);' : '' ?>">
    <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
      <div style="min-width:0;">
        <span class="badge badge-baru"><?= h($a['label']) ?></span>
        <?php if ($a['is_default']): ?><span class="badge badge-selesai" style="margin-left:4px;">Utama</span><?php endif; ?>
        <div style="margin-top:8px;"><strong><?= h($a['recipient']) ?></strong> &middot; <?= h($a['phone']) ?></div>
        <div style="font-size:14px; color:#444; margin-top:2px;"><?= nl2br(h($a['address'])) ?></div>
      </div>
      <div style="display:flex; gap:8px; align-items:flex-start; flex-wrap:wrap;">
        <a href="<?= $self . ($fromCheckout ? '&' : '?') ?>edit=<?= (int) $a['id'] ?>" class="btn btn-outline btn-sm">Ubah</a>
        <?php if (!$a['is_default']): ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="from" value="<?= $fromCheckout ? 'checkout' : '' ?>"><input type="hidden" name="act" value="default"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>"><button class="btn btn-outline btn-sm">Jadikan Utama</button></form>
        <?php endif; ?>
        <form method="post" onsubmit="return confirm('Hapus alamat ini?');"><?= csrf_field() ?><input type="hidden" name="from" value="<?= $fromCheckout ? 'checkout' : '' ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>"><button class="btn btn-cancel btn-sm">Hapus</button></form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>

  <?php if ($showForm): ?>
  <div class="panel" style="padding:18px 20px; margin:16px 0;">
    <h3 style="margin-bottom:12px;"><?= $editing && !empty($editing['id']) ? 'Ubah Alamat' : 'Tambah Alamat Baru' ?></h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="act" value="save">
      <input type="hidden" name="from" value="<?= $fromCheckout ? 'checkout' : '' ?>">
      <input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
      <?= addr_fields('', $editing ?? []) ?>
      <?php $isDef = $editing ? (!empty($editing['is_default'])) : !$addrs; ?>
      <label style="display:flex; gap:8px; align-items:center; margin-top:12px; font-size:14px;"><input type="checkbox" name="is_default" value="1" <?= $isDef ? 'checked' : '' ?>> Jadikan alamat utama</label>
      <div style="display:flex; gap:8px; margin-top:14px;">
        <button type="submit" class="btn btn-primary">Simpan Alamat</button>
        <?php if ($addrs): ?><a href="<?= $self ?>" class="btn btn-outline">Batal</a><?php endif; ?>
      </div>
    </form>
  </div>
  <?php elseif (count($addrs) < ADDR_MAX): ?>
    <a href="<?= $self . ($fromCheckout ? '&' : '?') ?>new=1" class="btn btn-outline" style="margin-top:6px;">+ Tambah Alamat Baru</a>
  <?php endif; ?>
  <?php endif; ?>

  <div style="margin-top:22px;">
    <?php if ($fromCheckout): ?><a href="<?= BASE_URL ?>/user/checkout.php" class="btn btn-primary">&larr; Kembali ke Checkout</a>
    <?php else: ?><a href="<?= BASE_URL ?>/user/profile.php" class="btn btn-outline">&larr; Kembali ke Profil</a><?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
