<?php
require_once __DIR__ . '/../includes/auth.php';
require_login('/user/login.php');

$userId = (int) $_SESSION['user_id'];
pay_expire_unpaid($pdo);   // pesanan QRIS yang lewat batas bayar dibatalkan otomatis
$useBook = addr_ready($pdo);
$addrs = $useBook ? addr_list($pdo, $userId) : [];
$selAddr = $_POST['address_id'] ?? ($addrs ? (string) $addrs[0]['id'] : 'new');
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$w = (war_ready($pdo) && $id) ? war_get($pdo, $id) : null;
if (!$w){ header("Location: " . BASE_URL . "/user/wars.php"); exit; }

$early = war_early_seconds($pdo);
$phase = war_phase($w, null, $early);
$bought = war_user_bought($pdo, $id, $userId);
$leftForUser = max(0, (int) $w['max_per_user'] - $bought);
$maxQty = min($leftForUser, (int) $w['stock']);

$savedPhone = '';
if (db_has_column($pdo, 'users', 'phone')){
    $stmt = $pdo->prepare("SELECT phone FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $savedPhone = (string) $stmt->fetchColumn();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $qty = max(1, (int) ($_POST['qty'] ?? 1));
    $paymentMethod = $_POST['payment_method'] ?? 'transfer';
    $paymentLabels = ['transfer' => 'Transfer Bank', 'qris' => 'QRIS / E-Wallet'];
    if (!isset($paymentLabels[$paymentMethod])) $paymentMethod = 'transfer';
    $paymentLabel = $paymentLabels[$paymentMethod];
    $needProof = ($paymentMethod === 'transfer');   // QRIS tanpa bukti: admin konfirmasi lewat dana masuk
    $isQrisPay = ($paymentMethod === 'qris');
    $proofName = null;
    $address = ''; $phone = ''; $shipName = null;

    if (!csrf_valid()){
        $error = 'Sesi tidak valid, muat ulang halaman lalu coba lagi.';
    } elseif ($isQrisPay && (!pay_ready($pdo) || !qris_dynamic(QRIS_STATIC, 10000))){
        $error = 'Pembayaran QRIS belum aktif. Jalankan database/migration_v16.sql dulu, atau pilih metode lain.';
    } else {
        if ($useBook){
            if ($selAddr === 'new'){
                list($d, $err) = addr_validate(['label' => $_POST['new_label'] ?? '', 'recipient' => $_POST['new_recipient'] ?? '', 'phone' => $_POST['new_phone'] ?? '', 'address' => $_POST['new_address'] ?? '']);
                if (!$d) $error = $err;
                else {
                    list($newId, $err) = addr_save($pdo, $userId, $d, !empty($_POST['new_default']));
                    if (!$newId) $error = $err; else { $a = addr_get($pdo, $userId, $newId); $addrs = addr_list($pdo, $userId); $selAddr = (string) $newId; }
                }
            } else {
                $a = addr_get($pdo, $userId, (int) $selAddr);
                if (!$a) $error = 'Pilih alamat pengiriman dulu.';
            }
            if (!$error && !empty($a)){ $address = $a['address']; $phone = $a['phone']; $shipName = $a['recipient']; }
        } else {
            $address = trim($_POST['address'] ?? '');
            $phone = normalize_phone($_POST['phone'] ?? '');
            if ($phone === false) $error = 'Nomor HP penerima tidak valid. Contoh: 081234567890';
            elseif ($address === '') $error = 'Alamat pengiriman wajib diisi.';
        }
    }

    if ($error){
        // sudah ada pesan error
    } elseif ($needProof && empty($_FILES['payment_proof']['name'])){
        $error = 'Bukti pembayaran wajib diupload untuk metode ' . $paymentLabel . '.';
    } elseif ($phase !== 'live'){
        $error = $phase === 'upcoming' ? 'War belum dibuka.' : 'War sudah tidak berlangsung.';
    } else {
        if ($needProof){
            $ext = strtolower(pathinfo($_FILES['payment_proof']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)){
                $error = 'Format bukti transfer harus JPG, PNG, atau WEBP.';
            } else {
                $proofName = 'bukti_' . uniqid() . '.' . $ext;
                if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0777, true);
                move_uploaded_file($_FILES['payment_proof']['tmp_name'], UPLOAD_DIR . $proofName);
            }
        }
        if (!$error){
            $extra = [];
            if ($shipName !== null) $extra['shipping_name'] = $shipName;
            if ($isQrisPay){ $extra['pay_status'] = 'menunggu'; $extra['pay_expires_at'] = pay_deadline(); }
            list($ok, $res) = war_purchase($pdo, $id, $userId, $qty, $address, $phone, $paymentLabel, $proofName, $extra);
            if ($ok){
                if ($proofName) upload_backup_save($pdo, $proofName);
                if ($isQrisPay) header("Location: " . BASE_URL . "/user/pay_qris.php?id=" . $res);
                else header("Location: " . BASE_URL . "/user/index.php?struk=" . $res . "&success=1");
                exit;
            }
            if ($proofName && is_file(UPLOAD_DIR . $proofName)) @unlink(UPLOAD_DIR . $proofName);   // gagal: jangan tinggalkan file yatim
            $error = $res;
            // segarkan data setelah gagal
            $w = war_get($pdo, $id);
            $phase = war_phase($w, null, $early);
            $bought = war_user_bought($pdo, $id, $userId);
            $leftForUser = max(0, (int) $w['max_per_user'] - $bought);
            $maxQty = min($leftForUser, (int) $w['stock']);
        }
    }
}

$pageTitle = 'Checkout War';
$active = 'wars';
require __DIR__ . '/../includes/store_header.php';

$perks = member_perks($pdo);
$isMember = $perks !== null;
$pm = $_POST['payment_method'] ?? 'transfer';
?>
<div class="cart-page">
  <h1 style="font-size:26px; font-weight:800; margin-bottom:20px;">⚡ Checkout War</h1>
  <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

  <div class="panel" style="margin-bottom:20px; padding:16px; display:flex; gap:16px; align-items:center;">
    <img src="<?= h(war_cover_url($w)) ?>" alt="" style="width:64px; height:90px; object-fit:cover; border-radius:6px;">
    <div>
      <div class="war-edition"><?= h($w['title']) ?></div>
      <strong><?= h($w['book_title']) ?></strong>
      <div style="color:var(--primary); font-weight:800;"><?= rupiah($w['price']) ?></div>
      <div style="font-size:12.5px; color:var(--gray);">Sisa stok war: <?= (int) $w['stock'] ?> &middot; jatahmu tinggal <?= $leftForUser ?></div>
    </div>
  </div>

  <?php if ($phase !== 'live' || $maxQty < 1): ?>
    <div class="alert alert-error"><?= $leftForUser < 1 ? 'Kamu sudah mencapai batas beli war ini.' : ($phase === 'upcoming' ? 'War belum dibuka.' : 'War ini sudah tidak berlangsung atau stok habis.') ?></div>
    <a href="<?= BASE_URL ?>/user/war_detail.php?id=<?= $id ?>" class="btn btn-outline">&larr; Kembali</a>
  <?php else: ?>
  <form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">

    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:8px;">Jumlah</label>
      <input type="number" name="qty" id="warQty" value="<?= (int) min($maxQty, max(1, (int) ($_POST['qty'] ?? 1))) ?>" min="1" max="<?= $maxQty ?>" style="width:90px; padding:12px; border:1.5px solid #ccc; border-radius:8px;" required>
    </div>
    <?php if ($useBook): ?>
    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:10px;">Alamat Pengiriman</label>
      <?php foreach ($addrs as $a): ?>
      <label class="payment-option">
        <input type="radio" name="address_id" value="<?= (int) $a['id'] ?>" onclick="toggleNewAddr(false)" <?= (string) $selAddr === (string) $a['id'] ? 'checked' : '' ?>>
        <div class="payment-option-body">
          <strong><?= h($a['recipient']) ?> &middot; <?= h($a['phone']) ?>
            <span class="badge badge-baru" style="margin-left:6px;"><?= h($a['label']) ?></span>
            <?php if ($a['is_default']): ?><span class="badge badge-selesai" style="margin-left:4px;">Utama</span><?php endif; ?></strong>
          <p><?= nl2br(h($a['address'])) ?></p>
        </div>
      </label>
      <?php endforeach; ?>
      <label class="payment-option">
        <input type="radio" name="address_id" value="new" onclick="toggleNewAddr(true)" <?= $selAddr === 'new' ? 'checked' : '' ?>>
        <div class="payment-option-body"><strong>+ Tambah alamat baru</strong><p>Alamat baru otomatis tersimpan di buku alamatmu.</p></div>
      </label>
      <div id="newAddrBox" class="transfer-box" style="display:<?= $selAddr === 'new' ? 'block' : 'none' ?>;">
        <?= addr_fields('new_', ['recipient' => $_POST['new_recipient'] ?? '', 'phone' => $_POST['new_phone'] ?? $savedPhone, 'address' => $_POST['new_address'] ?? '', 'label' => $_POST['new_label'] ?? '']) ?>
        <label style="display:flex; gap:8px; align-items:center; margin-top:12px; font-size:14px; font-weight:400; text-transform:none; letter-spacing:normal; color:inherit;"><input type="checkbox" name="new_default" value="1" <?= (!$addrs || !empty($_POST['new_default'])) ? 'checked' : '' ?>> Jadikan alamat utama</label>
      </div>
      <?php if ($addrs): ?><a href="<?= BASE_URL ?>/user/addresses.php?from=checkout" style="font-size:13px; font-weight:700; color:var(--primary);">Kelola alamat</a><?php endif; ?>
      <script>function toggleNewAddr(on){ document.getElementById('newAddrBox').style.display = on ? 'block' : 'none'; }</script>
    </div>
    <?php else: ?>
    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:8px;">Nomor HP Penerima</label>
      <input type="tel" name="phone" placeholder="Contoh: 081234567890" value="<?= h($_POST['phone'] ?? $savedPhone) ?>" style="width:100%; padding:12px; border:1.5px solid #ccc; border-radius:8px;" required>
    </div>
    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:8px;">Alamat Pengiriman</label>
      <textarea name="address" rows="3" placeholder="Masukkan alamat lengkap pengiriman" style="width:100%; padding:12px; border:1.5px solid #ccc; border-radius:8px;" required><?= h($_POST['address'] ?? '') ?></textarea>
    </div>
    <?php endif; ?>

    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:10px;">Metode Pembayaran</label>
      <label class="payment-option">
        <input type="radio" name="payment_method" value="transfer" onclick="selectPay('transfer')" <?= $pm==='transfer'?'checked':'' ?>>
        <div class="payment-option-body"><strong>🏦 Transfer Bank</strong><p>Transfer ke rekening toko, lalu upload bukti transfer.</p></div>
      </label>
      <label class="payment-option">
        <input type="radio" name="payment_method" value="qris" onclick="selectPay('qris')" <?= $pm==='qris'?'checked':'' ?>>
        <div class="payment-option-body"><strong>📱 QRIS / E-Wallet</strong><p>QR nominal pas muncul setelah pesanan dibuat. Tanpa upload bukti.</p></div>
      </label>
      <div id="transferBox" class="transfer-box" style="display:<?= $pm==='transfer' ? 'block' : 'none' ?>;">
        <div class="transfer-rekening">🏦 <strong>Bank BSI</strong> &middot; 7370615769 &middot; a.n. Arkan Naufal</div>
      </div>
      <div id="qrisBox" class="transfer-box" style="display:<?= $pm==='qris' ? 'block' : 'none' ?>;">
        <p style="font-size:13px; line-height:1.55; margin:0;">Setelah klik <strong>Buat Pesanan War</strong>, QRIS dengan <strong>nominal pas</strong> langsung muncul (terkunci, tidak bisa kurang/lebih). Tanpa upload bukti: pesanan diproses begitu pembayaran masuk. Bayar dalam <strong><?= qris_expire_minutes() ?> menit</strong>, kalau lewat pesanan batal otomatis dan stok war dikembalikan.</p>
      </div>
      <div id="proofBox" class="transfer-box" style="display:<?= $pm==='transfer' ? 'block' : 'none' ?>;">
        <label style="font-weight:700; font-size:13px; display:block; margin:0 0 6px;">Upload Bukti Pembayaran</label>
        <input type="file" name="payment_proof" accept="image/jpeg,image/png,image/webp">
        <p style="font-size:12px; color:var(--gray); margin-top:6px;">Format JPG/PNG/WEBP. Stok war langsung diamankan untukmu saat pesanan dibuat.</p>
      </div>
      <script>
      function selectPay(m){
        document.getElementById('transferBox').style.display = (m === 'transfer') ? 'block' : 'none';
        document.getElementById('qrisBox').style.display     = (m === 'qris') ? 'block' : 'none';
        document.getElementById('proofBox').style.display    = (m === 'transfer') ? 'block' : 'none';
      }
      </script>
    </div>

    <div class="cart-summary">
      <div class="row"><span>Harga War x <span id="sumQty">1</span></span><span id="sumSub"><?= rupiah($w['price']) ?></span></div>
      <div class="row"><span>Ongkos Kirim</span><span id="sumShip"></span></div>
      <div class="row total"><span>Total Bayar</span><span id="sumTotal"></span></div>
      <p style="font-size:12px; color:var(--gray); margin-top:8px;">Harga war sudah harga khusus, jadi diskon member tidak berlaku<?= $isMember ? ' (benefit ongkir paket kamu tetap berlaku)' : '' ?>.</p>
      <button type="submit" class="btn btn-primary" style="width:100%; margin-top:16px;">⚡ Buat Pesanan War</button>
      <a href="<?= BASE_URL ?>/user/war_detail.php?id=<?= $id ?>" class="btn btn-outline" style="display:block; width:100%; margin-top:10px; text-align:center;">&larr; Kembali</a>
    </div>
  </form>
  <script>
  (function(){
    var price = <?= (float) $w['price'] ?>, shipMin = <?= $isMember ? (int) $perks['ship_min'] : -1 ?>;
    var q = document.getElementById('warQty');
    function rp(n){ return 'Rp ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
    function calc(){
      var n = Math.max(1, parseInt(q.value, 10) || 1), sub = price * n;
      var ship = (sub >= 150000 || (shipMin >= 0 && sub >= shipMin)) ? 0 : 15000;
      document.getElementById('sumQty').textContent = n;
      document.getElementById('sumSub').textContent = rp(sub);
      document.getElementById('sumShip').textContent = ship === 0 ? 'GRATIS' : rp(ship);
      document.getElementById('sumTotal').textContent = rp(sub + ship);
    }
    q.addEventListener('input', calc); calc();
  })();
  </script>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
