<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();
if (is_admin()){ header("Location: " . BASE_URL . "/admin/chat.php"); exit; }
$user = current_user();
$uid = (int) $user['id'];
$ready = chat_ready($pdo);

// Pesanan yang bisa dikirim sebagai kartu (tombol "Kirim pesanan") + pesanan dari ?order=
$orders = [];
if ($ready){
    $st = $pdo->prepare("SELECT o.id, o.status, o.total, o.order_date,
        (SELECT b.title FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = o.id ORDER BY oi.id LIMIT 1) AS title
        FROM orders o WHERE o.user_id = ? ORDER BY o.id DESC LIMIT 8");
    $st->execute([$uid]);
    $orders = $st->fetchAll();
}
$preOrder = (int) ($_GET['order'] ?? 0);
if ($preOrder && !in_array($preOrder, array_map('intval', array_column($orders, 'id')), true)) $preOrder = 0;

// Tombol cepat "Minta pengembalian dana": ke pesanan Selesai terbaru yang masih bisa diajukan, kalau tidak ada ke riwayat pesanan
$returnLink = BASE_URL . '/user/profile.php';
if ($ready && return_ready($pdo)){
    $rq = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? AND status = 'Selesai' ORDER BY id DESC LIMIT 10");
    $rq->execute([$uid]);
    foreach ($rq->fetchAll() as $ro){
        if (return_eligible($ro)){ $returnLink = BASE_URL . '/user/return_order.php?id=' . (int) $ro['id']; break; }
    }
}

// Kirim lewat form biasa (cadangan kalau JavaScript mati; normalnya dikirim lewat chat.js)
$error = '';
if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST'){
    if (($_SERVER['CONTENT_LENGTH'] ?? 0) > 0 && empty($_POST) && empty($_FILES)){
        $error = 'Foto terlalu besar untuk server (post_max_size di php.ini).';
    } elseif (!csrf_valid()){
        $error = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } else {
        list($okImg, $img) = chat_save_image($pdo, 'image');
        if (!$okImg){ $error = $img; }
        else {
            list($ok, $res) = chat_send($pdo, $uid, 'user', $_POST['message'] ?? '', (int) ($_POST['order_id'] ?? 0) ?: null, $img);
            if ($ok){ header("Location: " . BASE_URL . "/user/chat.php"); exit; }
            if ($img) @unlink(UPLOAD_DIR . $img);
            $error = $res;
        }
    }
}

$msgs = [];
if ($ready){
    $msgs = array_map(function($r){ return chat_format($r, 'user'); }, chat_fetch($pdo, $uid, 0));
    chat_mark_read($pdo, $uid, 'user');   // pesan dari penjual dianggap dibaca saat percakapan dibuka
}
$last = $msgs ? end($msgs) : null;
$logo = BASE_URL . '/assets/images/logo-circle.png';
$emojis = ['😊','😀','😂','😍','🙏','👍','👌','🙌','😢','😅','🤔','😮','❤️','🔥','🎉','📚','📦','🚚','✅','❗'];

$pageTitle = 'Chat Penjual';
$active = '';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="section chat-section">
  <div class="chat-card">
    <div class="chat-head">
      <a href="<?= BASE_URL ?>/user/inbox.php" class="ch-back" aria-label="Kembali">&#8592;</a>
      <img class="ch-avatar" src="<?= $logo ?>" alt="">
      <div class="ch-title"><b><?= h(STORE_NAME) ?></b><small>Tanya soal buku atau pesananmu di sini</small></div>
      <a class="ch-store" href="<?= BASE_URL ?>/user/books.php" title="Lihat toko">&#127980;</a>
    </div>

    <?php if (!$ready): ?>
      <div class="alert alert-error" style="margin:14px;">Fitur chat belum aktif. Jalankan <code>database/migration_v13.sql</code> dulu.</div>
    <?php else: ?>
    <div class="chat-box" id="chat-box"
         data-api="<?= BASE_URL ?>/chat_api.php" data-me="user" data-thread="<?= $uid ?>"
         data-after="<?= $last ? (int) $last['id'] : 0 ?>" data-last-ts="<?= $last ? (int) $last['ts'] : 0 ?>" data-last-date="<?= $last ? h($last['date']) : '' ?>"
         data-avatar="<?= h($logo) ?>">
      <?= chat_render_list($msgs, '<img class="msg-av" src="' . h($logo) . '" alt="">') ?>
      <div class="chat-empty" id="chat-empty" <?= $msgs ? 'hidden' : '' ?>>Belum ada pesan.<br>Sapa penjual atau kirim pesananmu untuk mulai chat.</div>
    </div>
    <button type="button" id="chat-latest" class="chat-latest" hidden>&#8964; Lihat yang paling baru</button>
    <div id="chat-error" class="chat-error" <?= $error ? '' : 'hidden' ?>><?= h($error) ?></div>

    <form id="chat-form" method="post" enctype="multipart/form-data" class="chat-form">
      <?= csrf_field() ?>
      <input type="hidden" name="order_id" id="chat-order-id" value="<?= $preOrder ?: '' ?>">
      <div class="chat-chips">
        <a class="chip" href="<?= $returnLink ?>">&#8617; Minta pengembalian dana</a>
        <button type="button" class="chip" id="chip-order">&#129534; Kirim pesanan</button>
      </div>
      <div id="order-pick" class="order-pick" hidden>
        <select id="order-select">
          <option value="">-- Pilih pesanan --</option>
          <?php foreach ($orders as $o): $lbl = '#' . str_pad($o['id'], 5, '0', STR_PAD_LEFT); ?>
            <option value="<?= (int) $o['id'] ?>" data-label="<?= h($lbl) ?>" <?= $preOrder === (int) $o['id'] ? 'selected' : '' ?>><?= h($lbl . ' · ' . $o['status'] . ' · ' . rupiah($o['total'])) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (!$orders): ?><small>Kamu belum punya pesanan.</small><?php endif; ?>
      </div>
      <div id="chat-attach" class="chat-attach"></div>
      <div class="chat-bar">
        <textarea name="message" id="chat-text" rows="1" maxlength="1000" placeholder="Kirim pesan…"></textarea>
        <button type="button" class="cb-btn" id="btn-emoji" aria-label="Emoji">&#128522;</button>
        <button type="button" class="cb-btn" id="btn-plus" aria-label="Lampirkan foto">&#65291;</button>
        <button type="submit" class="cb-send" aria-label="Kirim">&#10148;</button>
        <input type="file" name="image" id="chat-file" accept="image/jpeg,image/png,image/webp" hidden>
      </div>
      <div class="emoji-pop" id="emoji-pop" hidden>
        <?php foreach ($emojis as $e): ?><button type="button" data-emoji="<?= $e ?>"><?= $e ?></button><?php endforeach; ?>
      </div>
    </form>
    <?php endif; ?>
  </div>
</div>
<?php if ($ready): ?><script src="<?= BASE_URL ?>/assets/js/chat.js"></script><?php endif; ?>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
