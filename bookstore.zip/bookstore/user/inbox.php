<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();
if (is_admin()){ header("Location: " . BASE_URL . "/admin/chat.php"); exit; }
$user = current_user();
$uid = (int) $user['id'];

$notifs = inbox_notifications($pdo, $uid, 5);       // "Peringatan belanja": status pesanan terbaru
$ready = chat_ready($pdo);
$last = $ready ? chat_last_for_user($pdo, $uid) : null;
$unread = $ready ? chat_unread_user($pdo, $uid) : 0;
$logo = BASE_URL . '/assets/images/logo-circle.png';

$pageTitle = 'Pesan';
$active = '';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="section inbox">
  <div class="inbox-head"><a href="<?= BASE_URL ?>/user/index.php" class="ch-back" aria-label="Kembali">&#8592;</a><h2>Pesan</h2></div>

  <div class="inbox-sec">
    <span>Peringatan belanja</span>
    <a href="<?= BASE_URL ?>/user/profile.php">Lainnya &#8250;</a>
  </div>
  <?php foreach ($notifs as $n): ?>
    <a class="inbox-notif" href="<?= BASE_URL ?>/user/profile.php">
      <span class="ib-ic">&#128717;&#65039;</span>
      <span class="ib-body">
        <b><?= h($n['title']) ?></b>
        <span><?= h($n['text']) ?> <em><?= h(time_ago($n['ts'])) ?></em></span>
        <img src="<?= h($n['cover']) ?>" alt="">
      </span>
    </a>
  <?php endforeach; ?>
  <?php if (!$notifs): ?><p class="inbox-empty">Belum ada pesanan. Notifikasi status pesananmu akan muncul di sini.</p><?php endif; ?>

  <div class="inbox-sec" style="margin-top:22px;"><span>Chat</span></div>
  <a class="inbox-chat" href="<?= BASE_URL ?>/user/chat.php">
    <img src="<?= $logo ?>" alt="">
    <span class="ic-body">
      <b><?= h(STORE_NAME) ?></b>
      <span><?= $last ? h(($last['sender'] === 'user' ? 'Kamu: ' : '') . chat_snippet($last)) : 'Mulai chat dengan penjual' ?></span>
    </span>
    <span class="ic-meta">
      <?= $last ? h(time_ago(strtotime($last['last_at']))) : '' ?>
      <?php if ($unread > 0): ?><i class="un"><?= $unread ?></i><?php endif; ?>
    </span>
  </a>
  <?php if (!$ready): ?><p class="inbox-empty">Fitur chat belum aktif. Jalankan <code>database/migration_v13.sql</code>.</p><?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
