<?php
// Endpoint JSON ringan: dipanggil halaman war untuk update sisa stok & status secara live
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$w = war_ready($pdo) ? war_get($pdo, (int) ($_GET['id'] ?? 0)) : null;
if (!$w){ http_response_code(404); echo json_encode(['error' => 'not_found']); exit; }
$early = war_early_seconds($pdo);
$phase = war_phase($w, null, $early);
echo json_encode([
    'phase' => $phase,
    'label' => war_phase_label($phase),
    'stock' => (int) $w['stock'],
    'total' => (int) $w['total_stock'],
    'now' => time() * 1000,
    'start' => (strtotime($w['start_at']) - $early) * 1000,
    'end' => strtotime($w['end_at']) * 1000,
]);
