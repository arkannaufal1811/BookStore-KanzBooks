<?php
require_once __DIR__ . '/../includes/auth.php';
require_login('/user/login.php');

$userId = $_SESSION['user_id'];
pay_expire_unpaid($pdo);   // pesanan QRIS yang lewat batas bayar dibatalkan otomatis

// Buku alamat (alamat utama paling atas)
$useBook = addr_ready($pdo);
$addrs = $useBook ? addr_list($pdo, $userId) : [];
$selAddr = $_POST['address_id'] ?? ($addrs ? (string) $addrs[0]['id'] : 'new');

// Nomor HP tersimpan di akun (kalau sudah ada)
$savedPhone = '';
if (db_has_column($pdo, 'users', 'phone')){
    $stmt = $pdo->prepare("SELECT phone FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $savedPhone = (string) $stmt->fetchColumn();
}

// Ubah jumlah langsung di halaman checkout (dibatasi stok)
$qtyNotice = '';
if (isset($_GET['inc']) || isset($_GET['dec'])){
    $itemId = $_GET['inc'] ?? $_GET['dec'];
    $stmt = $pdo->prepare("SELECT ci.*, b.stock FROM cart_items ci JOIN books b ON b.id = ci.book_id WHERE ci.id = ? AND ci.user_id = ?");
    $stmt->execute([$itemId, $userId]);
    $row = $stmt->fetch();
    $flag = '';
    if ($row){
        if (isset($_GET['inc'])){
            if ($row['qty'] >= $row['stock']){ $newQty = max(1, (int) $row['stock']); $flag = '?limited=1'; }
            else { $newQty = $row['qty'] + 1; }
        } else {
            $newQty = max(1, $row['qty'] - 1);
        }
        $pdo->prepare("UPDATE cart_items SET qty = ? WHERE id = ?")->execute([$newQty, $itemId]);
    }
    header("Location: " . BASE_URL . "/user/checkout.php" . $flag);
    exit;
}
if (isset($_GET['limited'])) $qtyNotice = 'Jumlah dibatasi sesuai stok yang tersedia.';

$stmt = $pdo->prepare("
    SELECT ci.id AS cart_id, ci.qty, b.* FROM cart_items ci
    JOIN books b ON b.id = ci.book_id WHERE ci.user_id = ?
");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

if (!$items){
    header("Location: " . BASE_URL . "/user/cart.php");
    exit;
}

$subtotal = 0;
foreach ($items as $it){ $subtotal += $it['price'] * $it['qty']; }

$perks = member_perks($pdo);              // benefit sesuai paket member (null = bukan member)
$isMember = $perks !== null;
$memberDiscount = $isMember ? round($subtotal * $perks['discount'] / 100) : 0;
$subtotalAfterDiscount = $subtotal - $memberDiscount;
$ongkir = shipping_cost($perks, $subtotalAfterDiscount);
$total = $subtotalAfterDiscount + $ongkir;

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $paymentMethod = $_POST['payment_method'] ?? 'transfer';

    $paymentLabels = ['transfer' => 'Transfer Bank', 'qris' => 'QRIS / E-Wallet'];
    if (!isset($paymentLabels[$paymentMethod])) $paymentMethod = 'transfer';
    $paymentLabel = $paymentLabels[$paymentMethod];
    $needProof = ($paymentMethod === 'transfer');     // QRIS TIDAK pakai bukti: admin konfirmasi lewat notifikasi dana masuk
    $isQrisPay = ($paymentMethod === 'qris');
    $proofName = null;
    $address = ''; $phone = ''; $shipName = null;

    if (!csrf_valid()){
        $error = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } elseif ($isQrisPay && (!pay_ready($pdo) || !qris_dynamic(QRIS_STATIC, 10000))){
        $error = 'Pembayaran QRIS belum aktif. Jalankan database/migration_v16.sql dulu, atau pilih metode lain.';
    } else {
        // ----- alamat: pilih dari buku alamat, atau isi alamat baru (otomatis tersimpan) -----
        if ($useBook){
            if ($selAddr === 'new'){
                list($d, $err) = addr_validate(['label' => $_POST['new_label'] ?? '', 'recipient' => $_POST['new_recipient'] ?? '', 'phone' => $_POST['new_phone'] ?? '', 'address' => $_POST['new_address'] ?? '']);
                if (!$d) $error = $err;
                else {
                    list($newId, $err) = addr_save($pdo, $userId, $d, !empty($_POST['new_default']));
                    if (!$newId) $error = $err; else { $a = addr_get($pdo, $userId, $newId); $addrs = addr_list($pdo, $userId); $selAddr = (string) $newId; }   // kalau gagal di langkah lain, jangan tersimpan dobel saat dicoba lagi
                }
            } else {
                $a = addr_get($pdo, $userId, (int) $selAddr);
                if (!$a) $error = 'Pilih alamat pengiriman dulu.';
            }
            if (!$error && !empty($a)){ $address = $a['address']; $phone = $a['phone']; $shipName = $a['recipient']; }
        } else {
            $address = trim($_POST['address'] ?? '');
            $phone = normalize_phone($_POST['phone'] ?? '');
            if ($phone === false) $error = 'Nomor HP penerima tidak valid. Contoh: 081234567890';
            elseif ($address === '') $error = 'Alamat pengiriman wajib diisi.';
        }
    }

    if ($error){
        // sudah ada pesan error
    } elseif ($needProof && empty($_FILES['payment_proof']['name'])){
        $error = 'Bukti pembayaran wajib diupload untuk metode ' . $paymentLabel . '.';
    } else {
        if ($needProof && !empty($_FILES['payment_proof']['name'])){
            $ext = strtolower(pathinfo($_FILES['payment_proof']['name'], PATHINFO_EXTENSION));
            $allowedExt = ['jpg','jpeg','png','webp'];
            if (!in_array($ext, $allowedExt)){
                $error = 'Format bukti transfer harus JPG, PNG, atau WEBP.';
            } else {
                $proofName = 'bukti_' . uniqid() . '.' . $ext;
                if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0777, true);
                move_uploaded_file($_FILES['payment_proof']['tmp_name'], UPLOAD_DIR . $proofName);
                upload_backup_save($pdo, $proofName);
            }
        }

        if (!$error){
            $pdo->beginTransaction();
            try {
                // ===== SISTEM ANTI-REBUTAN STOK (siapa checkout duluan yang dapat) =====
                // Kunci baris buku yang mau dibeli, biar kalau ada 2 orang checkout stok terakhir
                // bersamaan, cuma salah satu yang berhasil (gak bisa oversell / stok minus).
                $stmtLock = $pdo->prepare("SELECT id, title, stock FROM books WHERE id = ? FOR UPDATE");
                foreach ($items as $it){
                    $stmtLock->execute([$it['id']]);
                    $locked = $stmtLock->fetch();
                    if (!$locked || $locked['stock'] < $it['qty']){
                        throw new Exception("Yah, kehabisan! Stok '{$it['title']}' baru aja diambil pembeli lain. Coba kurangi jumlahnya atau pilih buku lain ya.");
                    }
                }

                $cols = ['user_id' => $userId, 'total' => $total, 'payment_method' => $paymentLabel, 'payment_proof' => $proofName, 'shipping_address' => $address, 'status' => 'Baru'];
                if (db_has_column($pdo, 'orders', 'shipping_phone')) $cols['shipping_phone'] = $phone;
                if ($shipName !== null && db_has_column($pdo, 'orders', 'shipping_name')) $cols['shipping_name'] = $shipName;
                if ($isQrisPay){ $cols['pay_status'] = 'menunggu'; $cols['pay_expires_at'] = pay_deadline(); }
                $pdo->prepare("INSERT INTO orders (" . implode(',', array_keys($cols)) . ") VALUES (" . implode(',', array_fill(0, count($cols), '?')) . ")")->execute(array_values($cols));

                $orderId = $pdo->lastInsertId();
                // simpan nomor HP ke akun kalau belum ada (setelah ID pesanan diambil)
                if (db_has_column($pdo, 'users', 'phone') && $savedPhone === ''){
                    $pdo->prepare("UPDATE users SET phone = ? WHERE id = ?")->execute([$phone, $userId]);
                }

                $stmtItem = $pdo->prepare("INSERT INTO order_items (order_id, book_id, qty, price) VALUES (?, ?, ?, ?)");
                $stmtStock = $pdo->prepare("UPDATE books SET stock = stock - ? WHERE id = ?");
                foreach ($items as $it){
                    $stmtItem->execute([$orderId, $it['id'], $it['qty'], $it['price']]);
                    $stmtStock->execute([$it['qty'], $it['id']]);
                }

                $pdo->prepare("DELETE FROM cart_items WHERE user_id = ?")->execute([$userId]);

                // Poin reward buat member: 1 poin tiap Rp10.000 dibayar, dikali pengali paket (1x / 1,5x / 2x)
                $earnedPoints = points_for_total($perks, $total);
                if ($earnedPoints > 0){
                    $pdo->prepare("UPDATE users SET points = points + ? WHERE id = ?")->execute([$earnedPoints, $userId]);
                }
                // catat poin pesanan ini supaya pas dibatalkan / diretur poin yang ditarik pas
                if (db_has_column($pdo, 'orders', 'points_earned')){
                    $pdo->prepare("UPDATE orders SET points_earned = ? WHERE id = ?")->execute([$earnedPoints, $orderId]);
                }

                $pdo->commit();

                if ($isQrisPay) header("Location: " . BASE_URL . "/user/pay_qris.php?id=" . $orderId);
                else header("Location: " . BASE_URL . "/user/index.php?struk=" . $orderId . "&success=1");
                exit;
            } catch (Throwable $e){
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = ($e instanceof PDOException) ? 'Database error: ' . $e->getMessage() . ' (cek apakah semua migration sudah dijalankan)' : ($e->getMessage() ?: 'Terjadi kesalahan saat memproses pesanan. Coba lagi.');
            }
        }
    }
}

$pageTitle = 'Checkout';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="cart-page">
  <h1 style="font-size:26px; font-weight:800; margin-bottom:20px;">Checkout</h1>
  <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
  <?php if ($qtyNotice): ?><div class="alert alert-error"><?= h($qtyNotice) ?></div><?php endif; ?>

  <div class="panel" style="margin-bottom:20px;">
    <table class="data-table">
      <thead><tr><th>Buku</th><th>Jumlah</th><th>Subtotal</th></tr></thead>
      <tbody>
        <?php foreach ($items as $it): ?>
        <tr>
          <td><?= h($it['title']) ?></td>
          <td>
            <div class="qty" style="display:flex; align-items:center; gap:10px;">
              <a href="?dec=<?= $it['cart_id'] ?>"><button type="button" style="width:28px; height:28px; border:1.5px solid #333; background:#fff; border-radius:6px; font-weight:800;">-</button></a>
              <span><?= $it['qty'] ?></span>
              <?php if ($it['qty'] >= $it['stock']): ?>
                <button type="button" disabled title="Sudah mencapai batas stok" style="width:28px; height:28px; border:1.5px solid #333; background:#fff; border-radius:6px; font-weight:800; opacity:.4; cursor:not-allowed;">+</button>
              <?php else: ?>
                <a href="?inc=<?= $it['cart_id'] ?>"><button type="button" style="width:28px; height:28px; border:1.5px solid #333; background:#fff; border-radius:6px; font-weight:800;">+</button></a>
              <?php endif; ?>
            </div>
            <div style="font-size:12px; color:<?= $it['qty'] >= $it['stock'] ? '#a51c1c' : 'var(--gray)' ?>; margin-top:4px;">Stok: <?= (int) $it['stock'] ?></div>
          </td>
          <td><?= rupiah($it['price'] * $it['qty']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <?php if ($useBook): ?>
    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:10px;">Alamat Pengiriman</label>
      <?php foreach ($addrs as $a): ?>
      <label class="payment-option">
        <input type="radio" name="address_id" value="<?= (int) $a['id'] ?>" onclick="toggleNewAddr(false)" <?= (string) $selAddr === (string) $a['id'] ? 'checked' : '' ?>>
        <div class="payment-option-body">
          <strong><?= h($a['recipient']) ?> &middot; <?= h($a['phone']) ?>
            <span class="badge badge-baru" style="margin-left:6px;"><?= h($a['label']) ?></span>
            <?php if ($a['is_default']): ?><span class="badge badge-selesai" style="margin-left:4px;">Utama</span><?php endif; ?></strong>
          <p><?= nl2br(h($a['address'])) ?></p>
        </div>
      </label>
      <?php endforeach; ?>
      <label class="payment-option">
        <input type="radio" name="address_id" value="new" onclick="toggleNewAddr(true)" <?= $selAddr === 'new' ? 'checked' : '' ?>>
        <div class="payment-option-body"><strong>+ Tambah alamat baru</strong><p>Alamat baru otomatis tersimpan di buku alamatmu.</p></div>
      </label>
      <div id="newAddrBox" class="transfer-box" style="display:<?= $selAddr === 'new' ? 'block' : 'none' ?>;">
        <?= addr_fields('new_', ['recipient' => $_POST['new_recipient'] ?? '', 'phone' => $_POST['new_phone'] ?? ($savedPhone), 'address' => $_POST['new_address'] ?? '', 'label' => $_POST['new_label'] ?? '']) ?>
        <label style="display:flex; gap:8px; align-items:center; margin-top:12px; font-size:14px; font-weight:400; text-transform:none; letter-spacing:normal; color:inherit;"><input type="checkbox" name="new_default" value="1" <?= (!$addrs || !empty($_POST['new_default'])) ? 'checked' : '' ?>> Jadikan alamat utama</label>
      </div>
      <?php if ($addrs): ?><a href="<?= BASE_URL ?>/user/addresses.php?from=checkout" style="font-size:13px; font-weight:700; color:var(--primary);">Kelola alamat</a><?php endif; ?>
      <script>function toggleNewAddr(on){ document.getElementById('newAddrBox').style.display = on ? 'block' : 'none'; }</script>
    </div>
    <?php else: ?>
    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:8px;">Nomor HP Penerima</label>
      <input type="tel" name="phone" placeholder="Contoh: 081234567890" value="<?= h($_POST['phone'] ?? $savedPhone) ?>" style="width:100%; padding:12px; border:1.5px solid #ccc; border-radius:8px;" required>
    </div>
    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:8px;">Alamat Pengiriman</label>
      <textarea name="address" rows="3" placeholder="Masukkan alamat lengkap pengiriman" style="width:100%; padding:12px; border:1.5px solid #ccc; border-radius:8px;" required><?= h($_POST['address'] ?? '') ?></textarea>
    </div>
    <?php endif; ?>

    <div class="form-group">
      <label style="font-weight:700; display:block; margin-bottom:10px;">Metode Pembayaran</label>

      <label class="payment-option">
        <input type="radio" name="payment_method" value="transfer" onclick="selectPay('transfer')" <?= (($_POST['payment_method'] ?? 'transfer')==='transfer')?'checked':'' ?>>
        <div class="payment-option-body">
          <strong>🏦 Transfer Bank</strong>
          <p>Transfer ke rekening toko, lalu upload bukti transfer.</p>
        </div>
      </label>

      <div id="transferBox" class="transfer-box" style="display:<?= (($_POST['payment_method'] ?? '')==='transfer') ? 'block' : 'none' ?>;">
        <div class="transfer-rekening">
          🏦 <strong>Bank BSI</strong> &middot; 7370615769 &middot; a.n. Arkan Naufal
        </div>
      </div>

      <label class="payment-option">
        <input type="radio" name="payment_method" value="qris" onclick="selectPay('qris')" <?= (($_POST['payment_method'] ?? '')==='qris')?'checked':'' ?>>
        <div class="payment-option-body">
          <strong>📱 QRIS / E-Wallet</strong>
          <p>QR nominal pas muncul setelah pesanan dibuat. Tanpa upload bukti.</p>
        </div>
      </label>

      <div id="qrisBox" class="transfer-box" style="display:<?= (($_POST['payment_method'] ?? '')==='qris') ? 'block' : 'none' ?>;">
        <div style="margin-bottom:8px; display:flex; gap:6px; flex-wrap:wrap;">
          <span class="ewallet-chip" style="background:#118eea;">DANA</span>
          <span class="ewallet-chip" style="background:#4c2a86;">OVO</span>
          <span class="ewallet-chip" style="background:#00aed6;">GoPay</span>
          <span class="ewallet-chip" style="background:#ee4d2d;">ShopeePay</span>
        </div>
        <p style="font-size:13px; line-height:1.55; margin:0;">Setelah klik <strong>Buat Pesanan</strong>, QRIS dengan <strong>nominal pas <?= rupiah($total) ?></strong> langsung muncul. Nominalnya terkunci di QR, jadi tidak bisa kurang atau lebih. Tidak perlu upload bukti: pesananmu diproses begitu pembayaran masuk ke penjual. Bayar dalam <strong><?= qris_expire_minutes() ?> menit</strong>, kalau lewat pesanan batal otomatis.</p>
      </div>

      <div id="proofBox" class="transfer-box" style="display:<?= (($_POST['payment_method'] ?? '')==='transfer') ? 'block' : 'none' ?>;">
        <label style="font-weight:700; font-size:13px; display:block; margin:0 0 6px;">Upload Bukti Pembayaran</label>
        <input type="file" name="payment_proof" accept="image/jpeg,image/png,image/webp">
        <p style="font-size:12px; color:var(--gray); margin-top:6px;">Format JPG/PNG/WEBP. Pesanan akan diverifikasi admin setelah bukti pembayaran diterima.</p>
      </div>

      <script>
      function selectPay(m){
        var tBox = document.getElementById('transferBox'), qBox = document.getElementById('qrisBox'), proof = document.getElementById('proofBox');
        tBox.style.display = (m === 'transfer') ? 'block' : 'none';
        qBox.style.display = (m === 'qris') ? 'block' : 'none';
        proof.style.display = (m === 'transfer') ? 'block' : 'none';
        tBox.parentNode.insertBefore(proof, tBox.nextSibling);   // upload bukti hanya untuk transfer bank
      }
      var checkedPay = document.querySelector('input[name="payment_method"]:checked');
      selectPay(checkedPay ? checkedPay.value : 'transfer');
      </script>
    </div>

    <div class="cart-summary">
      <?php if ($isMember): ?>
        <div class="alert alert-success" style="margin-bottom:14px;">👑 Kamu member KanzBooks Club paket <?= h($perks['label']) ?> — diskon <?= (int) $perks['discount'] ?>%<?= $ongkir == 0 ? ' & gratis ongkir' : '' ?> otomatis diterapkan!<?php if ($ongkir > 0): ?> Belanja <?= rupiah($perks['ship_min']) ?> ke atas gratis ongkir.<?php endif; ?></div>
      <?php endif; ?>
      <div class="row"><span>Subtotal</span><span><?= rupiah($subtotal) ?></span></div>
      <?php if ($isMember): ?>
        <div class="row" style="color:#178a4c;"><span>Diskon Member (<?= (int) $perks['discount'] ?>%)</span><span>- <?= rupiah($memberDiscount) ?></span></div>
      <?php endif; ?>
      <div class="row"><span>Ongkos Kirim</span><span><?= $ongkir == 0 ? 'GRATIS' : rupiah($ongkir) ?></span></div>
      <div class="row total"><span>Total Bayar</span><span><?= rupiah($total) ?></span></div>
      <button type="submit" class="btn btn-primary" style="width:100%; margin-top:16px;">Buat Pesanan</button>
      <a href="<?= BASE_URL ?>/user/cart.php" class="btn btn-outline" style="display:block; width:100%; margin-top:10px; text-align:center;">&larr; Kembali</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
