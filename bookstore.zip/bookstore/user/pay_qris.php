<?php
require_once __DIR__ . '/../includes/auth.php';
require_login('/user/login.php');

$userId = (int) $_SESSION['user_id'];
$id = (int) ($_GET['id'] ?? 0);
pay_expire_unpaid($pdo);

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $userId]);
$order = $stmt->fetch();
if (!$order || !pay_ready($pdo) || !pay_is_qris($order) || empty($order['pay_status'])){
    header("Location: " . BASE_URL . "/user/profile.php"); exit;
}

// Pembeli membatalkan sendiri SELAMA belum membayar (langsung batal, tanpa persetujuan admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_unpaid']) && csrf_valid()){
    $claim = $pdo->prepare("UPDATE orders SET pay_status = 'dibatalkan' WHERE id = ? AND user_id = ? AND pay_status = 'menunggu' AND status = 'Baru'");
    $claim->execute([$id, $userId]);
    if ($claim->rowCount() > 0) cancel_order($pdo, $id, 'pembeli', 'Dibatalkan pembeli sebelum membayar QRIS.', '');
    header("Location: " . BASE_URL . "/user/pay_qris.php?id=" . $id); exit;
}

// Endpoint polling: halaman ini bertanya status tiap beberapa detik
if (isset($_GET['poll'])){
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['pay' => $order['pay_status'], 'status' => $order['status']]);
    exit;
}

$state = $order['pay_status'];
if ($order['status'] === 'Dibatalkan' && $state !== 'kedaluwarsa') $state = 'dibatalkan';
$payload = ($state === 'menunggu') ? qris_dynamic(QRIS_STATIC, $order['total']) : null;
$left = !empty($order['pay_expires_at']) ? max(0, strtotime($order['pay_expires_at']) - time()) : 0;
$invNo = '#' . str_pad($order['id'], 5, '0', STR_PAD_LEFT);

$pageTitle = 'Bayar QRIS';
require __DIR__ . '/../includes/store_header.php';
?>
<div class="cart-page" style="max-width:520px; margin:0 auto;">
  <h1 style="font-size:24px; font-weight:800; margin-bottom:4px;">Bayar dengan QRIS</h1>
  <p style="color:var(--gray); margin-bottom:18px;">Pesanan <?= $invNo ?></p>

  <?php if ($state === 'menunggu' && $payload): ?>
  <div class="panel" id="payBox" style="padding:22px; text-align:center;">
    <div style="font-size:13px; color:var(--gray);">Total yang harus dibayar</div>
    <div style="font-size:32px; font-weight:800; color:var(--primary); margin:2px 0 10px;"><?= rupiah($order['total']) ?></div>
    <div style="display:inline-block; border:1px solid #ddd; border-radius:12px; padding:8px; background:#fff;"><?= qr_svg($payload, 260) ?></div>
    <div style="margin:12px 0 4px; display:flex; gap:6px; justify-content:center; flex-wrap:wrap;">
      <span class="ewallet-chip" style="background:#118eea;">DANA</span><span class="ewallet-chip" style="background:#4c2a86;">OVO</span><span class="ewallet-chip" style="background:#00aed6;">GoPay</span><span class="ewallet-chip" style="background:#ee4d2d;">ShopeePay</span>
    </div>
    <div style="margin-top:14px; font-size:14px;">Selesaikan dalam <strong id="cd" style="color:#a51c1c;">--:--</strong></div>
    <ul style="text-align:left; font-size:13px; color:#555; margin:16px 0 0; padding-left:18px; line-height:1.6;">
      <li>Scan QR ini dengan aplikasi e-wallet / m-banking.</li>
      <li>Nominal <strong><?= rupiah($order['total']) ?></strong> sudah terkunci di QR, tidak bisa diubah (tidak bisa kurang atau lebih).</li>
      <li>Tidak perlu upload bukti. Pesananmu diproses setelah penjual menerima notifikasi dana masuk.</li>
      <li>Halaman ini otomatis berubah begitu pembayaranmu dikonfirmasi.</li>
      <li>Lewat batas waktu, pesanan batal otomatis dan stok dikembalikan.</li>
    </ul>
  </div>
  <div style="display:flex; gap:8px; margin-top:14px; flex-wrap:wrap;">
    <a href="<?= BASE_URL ?>/user/profile.php" class="btn btn-outline">Lihat Pesanan Saya</a>
    <form method="post" onsubmit="return confirm('Batalkan pesanan ini? Jangan batalkan kalau kamu sudah membayar.');"><?= csrf_field() ?><input type="hidden" name="cancel_unpaid" value="1"><button type="submit" class="btn btn-cancel">Batalkan Pesanan</button></form>
  </div>
  <script>
  (function(){
    var left = <?= (int) $left ?>, cd = document.getElementById('cd');
    function pad(n){ return n < 10 ? '0' + n : n; }
    function tick(){
      if (left <= 0){ cd.textContent = '00:00'; location.reload(); return; }
      cd.textContent = pad(Math.floor(left / 60)) + ':' + pad(left % 60); left--;
    }
    tick(); setInterval(tick, 1000);
    setInterval(function(){
      fetch('?id=<?= (int) $order['id'] ?>&poll=1', {cache: 'no-store'}).then(function(r){ return r.json(); }).then(function(j){
        if (j.pay !== 'menunggu' || j.status === 'Dibatalkan') location.reload();
      }).catch(function(){});
    }, 5000);
  })();
  </script>

  <?php elseif ($state === 'dibayar'): ?>
  <div class="panel" style="padding:26px; text-align:center;">
    <div style="font-size:44px;">✅</div>
    <h2 style="margin:6px 0;">Pembayaran diterima</h2>
    <p style="color:var(--gray);">Pesanan <?= $invNo ?> sebesar <?= rupiah($order['total']) ?> sudah dikonfirmasi penjual dan akan segera diproses.</p>
    <div style="display:flex; gap:8px; justify-content:center; margin-top:16px; flex-wrap:wrap;">
      <a href="<?= BASE_URL ?>/user/index.php?struk=<?= (int) $order['id'] ?>&success=1" class="btn btn-primary">Lihat Invoice</a>
      <a href="<?= BASE_URL ?>/user/profile.php" class="btn btn-outline">Pesanan Saya</a>
    </div>
  </div>

  <?php else: ?>
  <div class="panel" style="padding:26px; text-align:center;">
    <div style="font-size:44px;">⌛</div>
    <h2 style="margin:6px 0;">Pesanan <?= $state === 'kedaluwarsa' ? 'kedaluwarsa' : 'dibatalkan' ?></h2>
    <p style="color:var(--gray);"><?= $state === 'kedaluwarsa' ? 'Pembayaran tidak diterima dalam ' . qris_expire_minutes() . ' menit, jadi pesanan dibatalkan dan stok dikembalikan. Kalau kamu sudah terlanjur membayar, hubungi penjual lewat Chat dengan menyebut nomor pesanan ini.' : 'Pesanan ini sudah dibatalkan.' ?></p>
    <div style="display:flex; gap:8px; justify-content:center; margin-top:16px; flex-wrap:wrap;">
      <a href="<?= BASE_URL ?>/user/books.php" class="btn btn-primary">Belanja Lagi</a>
      <a href="<?= BASE_URL ?>/user/chat.php?order=<?= (int) $order['id'] ?>" class="btn btn-outline">💬 Chat Penjual</a>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/store_footer.php'; ?>
