<?php
// Ekspor pesanan ke CSV (bisa dibuka di Excel). Filter: ?from=YYYY-MM-DD&to=YYYY-MM-DD&status=Selesai
require_once __DIR__ . '/../includes/auth.php';
require_admin();

$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$status = $_GET['status'] ?? '';
$validDate = function($d){ $t = DateTime::createFromFormat('Y-m-d', $d); return $t && $t->format('Y-m-d') === $d; };

$where = []; $params = [];
if ($from !== '' && $validDate($from)){ $where[] = 'o.order_date >= ?'; $params[] = $from . ' 00:00:00'; }
if ($to !== '' && $validDate($to)){ $where[] = 'o.order_date <= ?'; $params[] = $to . ' 23:59:59'; }
if (in_array($status, ['Baru','Diproses','Dikirim','Selesai'], true)){ $where[] = 'o.status = ?'; $params[] = $status; }

$hasVoucher = vouchers_ready($pdo);
$hasPhone = db_has_column($pdo, 'orders', 'shipping_phone');
$hasCourier = db_has_column($pdo, 'orders', 'courier') && db_has_column($pdo, 'orders', 'tracking_no');

$sql = "SELECT o.id, o.order_date, o.status, o.total, o.payment_method, o.shipping_address, u.name AS buyer, u.email"
     . ($hasPhone ? ", o.shipping_phone" : ", NULL AS shipping_phone")
     . ($hasCourier ? ", o.courier, o.tracking_no" : ", NULL AS courier, NULL AS tracking_no")
     . ($hasVoucher ? ", o.voucher_code, o.voucher_discount" : ", NULL AS voucher_code, 0 AS voucher_discount")
     . ", (SELECT GROUP_CONCAT(CONCAT(b.title, ' x', oi.qty) SEPARATOR '; ') FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = o.id) AS items"
     . " FROM orders o JOIN users u ON u.id = o.user_id"
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY o.order_date DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

// Cegah CSV/formula injection: sel yang diawali = + - @ diberi tanda petik di depan
$cell = function($v){
    $v = (string) $v;
    $v = str_replace(["\r", "\n"], ' ', $v);
    if ($v !== '' && strpos("=+-@\t", $v[0]) !== false) $v = "'" . $v;
    return $v;
};

$filename = 'pesanan-' . date('Ymd-His') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF");   // BOM supaya Excel membaca UTF-8
fputcsv($out, ['No. Pesanan','Tanggal','Status','Pembeli','Email','No. HP','Alamat','Metode Bayar','Voucher','Potongan Voucher','Total','Kurir','No. Resi','Item']);
while ($r = $stmt->fetch()){
    fputcsv($out, [
        $r['id'], $r['order_date'], $r['status'], $cell($r['buyer']), $cell($r['email']), $cell($r['shipping_phone']),
        $cell($r['shipping_address']), $cell($r['payment_method']), $cell($r['voucher_code']), (float) $r['voucher_discount'],
        (float) $r['total'], $cell($r['courier']), $cell($r['tracking_no']), $cell($r['items']),
    ]);
}
fclose($out);
