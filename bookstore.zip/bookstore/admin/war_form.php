<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

if (!war_ready($pdo)){ header("Location: " . BASE_URL . "/admin/wars.php"); exit; }

$id = (int) ($_GET['id'] ?? 0);
$isEdit = $id > 0;
$war = ['book_id' => '', 'title' => '', 'description' => '', 'cover_image' => '', 'price' => '', 'total_stock' => '', 'stock' => 0, 'max_per_user' => 1, 'start_at' => '', 'end_at' => '', 'status' => 'active'];
$sold = 0;
$hasOrders = false;

if ($isEdit){
    $stmt = $pdo->prepare("SELECT * FROM book_wars WHERE id = ?");
    $stmt->execute([$id]);
    $war = $stmt->fetch();
    if (!$war){ header("Location: " . BASE_URL . "/admin/wars.php"); exit; }
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE war_id = ?");
    $stmt->execute([$id]);
    $hasOrders = (int) $stmt->fetchColumn() > 0;
}

$books = $pdo->query("SELECT id, title, price FROM books ORDER BY title")->fetchAll();
$error = '';
$toLocal = fn($d) => $d ? date('Y-m-d\TH:i', strtotime($d)) : '';
$fromLocal = function($v){
    $t = DateTime::createFromFormat('Y-m-d\TH:i', (string) $v);
    return $t ? $t->format('Y-m-d H:i:00') : null;
};

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $bookId = (int) ($_POST['book_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $price = $_POST['price'] ?? '';
    $totalStock = (int) ($_POST['total_stock'] ?? 0);
    $maxPer = (int) ($_POST['max_per_user'] ?? 1);
    $startAt = $fromLocal($_POST['start_at'] ?? '');
    $endAt = $fromLocal($_POST['end_at'] ?? '');

    // tampilkan lagi isian kalau ada error
    $war = array_merge($war, ['book_id' => $bookId, 'title' => $title, 'description' => $desc, 'price' => $price, 'total_stock' => $totalStock, 'max_per_user' => $maxPer, 'start_at' => $startAt ?? '', 'end_at' => $endAt ?? '']);

    if (!csrf_valid()){
        $error = 'Sesi tidak valid, muat ulang halaman lalu coba lagi.';
    } elseif ($title === '' || $bookId < 1){
        $error = 'Buku dan nama edisi wajib diisi.';
    } elseif (!is_numeric($price) || $price < 0){
        $error = 'Harga war tidak valid.';
    } elseif ($totalStock < 1){
        $error = 'Stok war minimal 1.';
    } elseif ($maxPer < 1){
        $error = 'Batas beli per akun minimal 1.';
    } elseif (!$startAt || !$endAt){
        $error = 'Waktu mulai dan selesai wajib diisi.';
    } elseif (strtotime($endAt) <= strtotime($startAt)){
        $error = 'Waktu selesai harus setelah waktu mulai.';
    } else {
        $newCover = null;
        try {
            $newCover = war_save_cover('cover');
            $pdo->beginTransaction();
            $chk = $pdo->prepare("SELECT id FROM books WHERE id = ?");
            $chk->execute([$bookId]);
            if (!$chk->fetch()) throw new Exception('Buku tidak ditemukan.');

            if ($isEdit){
                // kunci baris war supaya tidak bentrok dengan pembeli yang sedang checkout
                $stmt = $pdo->prepare("SELECT * FROM book_wars WHERE id = ? FOR UPDATE");
                $stmt->execute([$id]);
                $cur = $stmt->fetch();
                $soldNow = (int) $cur['total_stock'] - (int) $cur['stock'];   // terjual (termasuk yang masih aktif di pesanan)
                $ord = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE war_id = ?");
                $ord->execute([$id]);
                $hasOrdersNow = (int) $ord->fetchColumn() > 0;

                if ($hasOrdersNow && $bookId !== (int) $cur['book_id']) throw new Exception('Buku tidak bisa diganti karena war ini sudah punya pesanan.');
                if ($totalStock < $soldNow) throw new Exception("Stok total tidak boleh di bawah jumlah yang sudah terjual ($soldNow).");
                $newRemain = $totalStock - $soldNow;

                $cover = $newCover ?? $cur['cover_image'];
                $pdo->prepare("UPDATE book_wars SET book_id=?, title=?, description=?, cover_image=?, price=?, total_stock=?, stock=?, max_per_user=?, start_at=?, end_at=? WHERE id=?")
                    ->execute([$bookId, $title, $desc, $cover, $price, $totalStock, $newRemain, $maxPer, $startAt, $endAt, $id]);
            } else {
                $pdo->prepare("INSERT INTO book_wars (book_id, title, description, cover_image, price, total_stock, stock, max_per_user, start_at, end_at) VALUES (?,?,?,?,?,?,?,?,?,?)")
                    ->execute([$bookId, $title, $desc, $newCover, $price, $totalStock, $totalStock, $maxPer, $startAt, $endAt]);
            }
            $pdo->commit();
            header("Location: " . BASE_URL . "/admin/wars.php?msg=saved");
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            if ($newCover && is_file(UPLOAD_DIR . $newCover)) @unlink(UPLOAD_DIR . $newCover);
            $error = $e->getMessage();
        }
    }
}

$sold = $isEdit ? max(0, (int) $war['total_stock'] - (int) $war['stock']) : 0;
$pageTitle = $isEdit ? 'Edit War' : 'Buat War Baru';
$active = 'wars';
require __DIR__ . '/../includes/admin_header.php';
?>
<div class="admin-topbar"><h1><?= $isEdit ? 'Edit War' : 'Buat War Baru' ?></h1></div>
<?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

<form method="post" class="admin-form" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="form-group">
    <label>Buku</label>
    <select name="book_id" required <?= $hasOrders ? 'style="pointer-events:none; background:#f3f3f3;" tabindex="-1"' : '' ?>>
      <option value="">-- Pilih Buku --</option>
      <?php foreach ($books as $b): ?>
        <option value="<?= $b['id'] ?>" <?= (int) $war['book_id'] === (int) $b['id'] ? 'selected' : '' ?>><?= h($b['title']) ?> (harga normal <?= rupiah($b['price']) ?>)</option>
      <?php endforeach; ?>
    </select>
    <?php if ($hasOrders): ?><p style="font-size:12px; color:var(--gray); margin-top:4px;">Buku dikunci karena war ini sudah punya pesanan.</p><?php endif; ?>
  </div>
  <div class="form-group">
    <label>Nama Edisi</label>
    <input type="text" name="title" value="<?= h($war['title']) ?>" placeholder="Contoh: Limited Edition - Cover Hardcase + Tanda Tangan" maxlength="150" required>
  </div>
  <div class="form-group">
    <label>Deskripsi War (opsional)</label>
    <textarea name="description" rows="4" placeholder="Apa yang spesial dari edisi ini? Bonus, nomor seri, dll."><?= h($war['description']) ?></textarea>
  </div>
  <div class="form-group">
    <label>Harga War (Rp)</label>
    <input type="number" name="price" value="<?= h($war['price']) ?>" min="0" step="1" required>
  </div>
  <div class="form-group">
    <label>Total Stok War</label>
    <input type="number" name="total_stock" value="<?= h($war['total_stock']) ?>" min="1" required>
    <p style="font-size:12px; color:var(--gray); margin-top:4px;">
      Stok khusus war, terpisah dari stok toko biasa.
      <?php if ($isEdit): ?>Saat ini terjual <strong><?= $sold ?></strong>, sisa <strong><?= (int) $war['stock'] ?></strong>. Mengubah total otomatis menyesuaikan sisa stok.<?php endif; ?>
    </p>
  </div>
  <div class="form-group">
    <label>Maksimal Beli per Akun</label>
    <input type="number" name="max_per_user" value="<?= h($war['max_per_user']) ?>" min="1" required>
  </div>
  <div class="form-group">
    <label>Waktu Mulai (WIB)</label>
    <input type="datetime-local" name="start_at" value="<?= h($toLocal($war['start_at'])) ?>" required>
  </div>
  <div class="form-group">
    <label>Waktu Selesai (WIB)</label>
    <input type="datetime-local" name="end_at" value="<?= h($toLocal($war['end_at'])) ?>" required>
    <p style="font-size:12px; color:var(--gray); margin-top:4px;">War ditutup otomatis saat waktu selesai tiba, atau lebih cepat kalau stok habis.</p>
  </div>
  <div class="form-group">
    <label>Cover Edisi Khusus (opsional)</label>
    <input type="file" name="cover" accept="image/jpeg,image/png,image/webp">
    <p style="font-size:12px; color:var(--gray); margin-top:4px;">Kosongkan untuk memakai cover buku biasa.</p>
    <?php if (!empty($war['cover_image'])): ?>
      <div style="margin-top:8px;"><img src="<?= UPLOAD_URL . h($war['cover_image']) ?>" style="width:80px; border-radius:6px;"></div>
    <?php endif; ?>
  </div>
  <button type="submit" class="btn btn-primary">Simpan</button>
  <a href="<?= BASE_URL ?>/admin/wars.php" class="btn btn-outline">Batal</a>
</form>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
