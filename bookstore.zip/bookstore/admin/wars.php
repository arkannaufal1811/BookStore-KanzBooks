<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

$ready = war_ready($pdo);
$msg = '';
$err = '';

// Aksi admin (POST + CSRF): akhiri sekarang / batalkan / hapus
if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST'){
    $id = (int) ($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if (!csrf_valid()){
        $err = 'Sesi tidak valid, muat ulang halaman lalu coba lagi.';
    } else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM book_wars WHERE id = ? FOR UPDATE");
            $stmt->execute([$id]);
            $w = $stmt->fetch();
            if (!$w) throw new Exception('War tidak ditemukan.');
            $phase = war_phase($w);

            if ($action === 'end'){
                if ($phase !== 'live') throw new Exception('Hanya war yang sedang berlangsung yang bisa diakhiri.');
                $pdo->prepare("UPDATE book_wars SET end_at = NOW() WHERE id = ?")->execute([$id]);
                $msg = 'War diakhiri sekarang.';
            } elseif ($action === 'cancel'){
                if (!in_array($phase, ['upcoming', 'live', 'soldout'], true)) throw new Exception('War ini sudah selesai / dibatalkan.');
                $pdo->prepare("UPDATE book_wars SET status = 'cancelled' WHERE id = ?")->execute([$id]);
                $msg = 'War dibatalkan. Pesanan yang sudah masuk tetap diproses seperti biasa (batalkan manual di menu Pesanan bila perlu).';
            } elseif ($action === 'delete'){
                if (war_sold_any($pdo, $id)) throw new Exception('War yang sudah punya pesanan tidak bisa dihapus. Gunakan Batalkan.');
                $pdo->prepare("DELETE FROM book_wars WHERE id = ?")->execute([$id]);
                $msg = 'War dihapus.';
            } else {
                throw new Exception('Aksi tidak dikenal.');
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $err = $e->getMessage();
        }
    }
}

// Ada pesanan (apa pun statusnya) yang terkait war ini?
function war_sold_any($pdo, $id){
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE war_id = ?");
    $stmt->execute([(int) $id]);
    return (int) $stmt->fetchColumn() > 0;
}

$wars = [];
if ($ready){
    $wars = $pdo->query("
        SELECT w.*, b.title AS book_title, b.cover_image AS book_cover,
          (SELECT COUNT(*) FROM orders o WHERE o.war_id = w.id) AS order_count
        FROM book_wars w JOIN books b ON b.id = w.book_id
        ORDER BY w.start_at DESC, w.id DESC
    ")->fetchAll();
}

if (isset($_GET['msg']) && !$msg) $msg = 'War berhasil disimpan.';

$pageTitle = 'War Buku';
$active = 'wars';
require __DIR__ . '/../includes/admin_header.php';
?>
<div class="admin-topbar">
  <h1>⚡ War Buku</h1>
  <?php if ($ready): ?><a href="<?= BASE_URL ?>/admin/war_form.php" class="btn btn-primary">+ Buat War Baru</a><?php endif; ?>
</div>

<?php if (!$ready): ?>
  <div class="alert alert-error">Fitur War Buku belum aktif di database. Jalankan <strong>database/migration_v14.sql</strong> di phpMyAdmin (tab SQL), lalu muat ulang halaman ini.</div>
<?php else: ?>
  <?php if ($msg): ?><div class="alert alert-success"><?= h($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="alert alert-error"><?= h($err) ?></div><?php endif; ?>

  <p style="color:var(--gray); margin-bottom:16px; max-width:760px;">Rilis buku limited edition dengan jadwal dan stok terbatas. Stok war terpisah dari stok toko biasa. Buka dan tutup war berjalan otomatis sesuai jadwal.</p>

  <div class="panel">
    <table class="data-table">
      <thead><tr><th>Edisi / Buku</th><th>Harga War</th><th>Stok</th><th>Jadwal</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($wars as $w): $phase = war_phase($w); $sold = (int) $w['total_stock'] - (int) $w['stock']; $pct = $w['total_stock'] > 0 ? round($sold / $w['total_stock'] * 100) : 0; ?>
        <tr>
          <td>
            <div style="display:flex; gap:12px; align-items:center;">
              <img src="<?= h(war_cover_url($w + ['book_cover' => $w['book_cover']])) ?>" alt="" style="width:44px; height:62px; object-fit:cover; border-radius:4px;">
              <div>
                <strong><?= h($w['title']) ?></strong>
                <div style="font-size:12.5px; color:var(--gray);"><?= h($w['book_title']) ?></div>
              </div>
            </div>
          </td>
          <td><?= rupiah($w['price']) ?><div style="font-size:12px; color:var(--gray);">maks. <?= (int) $w['max_per_user'] ?>/akun</div></td>
          <td style="min-width:130px;">
            <strong><?= (int) $w['stock'] ?></strong> / <?= (int) $w['total_stock'] ?> sisa
            <div style="height:6px; background:#eee; border-radius:4px; margin-top:6px; overflow:hidden;"><div style="width:<?= $pct ?>%; height:100%; background:var(--primary);"></div></div>
          </td>
          <td style="font-size:13px; white-space:nowrap;">
            <?= date('d M Y H:i', strtotime($w['start_at'])) ?><br>
            s/d <?= date('d M Y H:i', strtotime($w['end_at'])) ?>
          </td>
          <td><span class="badge <?= war_badge_class($phase) ?>"><?= h(war_phase_label($phase)) ?></span></td>
          <td>
            <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
              <a class="btn btn-outline btn-sm" href="<?= BASE_URL ?>/admin/war_form.php?id=<?= $w['id'] ?>">Edit</a>
              <?php if ($phase === 'live'): ?>
                <form method="post" onsubmit="return confirm('Akhiri war ini sekarang? Pembeli tidak bisa lagi mengambil stok.');" style="display:inline;">
                  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $w['id'] ?>"><input type="hidden" name="action" value="end">
                  <button class="btn btn-outline btn-sm" type="submit">Akhiri</button>
                </form>
              <?php endif; ?>
              <?php if (in_array($phase, ['upcoming', 'live', 'soldout'], true)): ?>
                <form method="post" onsubmit="return confirm('Batalkan war ini?');" style="display:inline;">
                  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $w['id'] ?>"><input type="hidden" name="action" value="cancel">
                  <button class="btn btn-cancel btn-sm" type="submit">Batalkan</button>
                </form>
              <?php endif; ?>
              <?php if ((int) $w['order_count'] === 0): ?>
                <form method="post" onsubmit="return confirm('Hapus war ini?');" style="display:inline;">
                  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $w['id'] ?>"><input type="hidden" name="action" value="delete">
                  <button class="btn btn-cancel btn-sm" type="submit">Hapus</button>
                </form>
              <?php endif; ?>
            </div>
            <?php if ($w['order_count'] > 0): ?><div style="font-size:12px; color:var(--gray); margin-top:4px;"><?= (int) $w['order_count'] ?> pesanan</div><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$wars): ?>
        <tr><td colspan="6" style="text-align:center; color:#999;">Belum ada war. Klik "Buat War Baru" untuk merilis buku limited edition.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
