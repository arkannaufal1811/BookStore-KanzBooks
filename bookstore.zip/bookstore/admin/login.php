<?php
// Login admin sekarang memakai halaman login yang sama dengan user (user/login.php).
// Akun dengan role "admin" otomatis diarahkan ke dashboard setelah login.
// File ini dipertahankan supaya alamat lama /admin/login.php tidak error.
require_once __DIR__ . '/../includes/auth.php';
header("Location: " . BASE_URL . (is_admin() ? "/admin/dashboard.php" : "/user/login.php"));
exit;
