<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

$ready = vouchers_ready($pdo);
$msg = ''; $error = '';
$edit = null;

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST'){
    if (!csrf_valid()){
        $error = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } else {
        $action = $_POST['action'] ?? '';
        $vid = (int) ($_POST['id'] ?? 0);

        if ($action === 'delete'){
            $pdo->prepare("DELETE FROM vouchers WHERE id = ?")->execute([$vid]);
            header("Location: " . BASE_URL . "/admin/vouchers.php?msg=deleted"); exit;
        }
        if ($action === 'toggle'){
            $pdo->prepare("UPDATE vouchers SET is_active = 1 - is_active WHERE id = ?")->execute([$vid]);
            header("Location: " . BASE_URL . "/admin/vouchers.php?msg=toggled"); exit;
        }
        if ($action === 'save'){
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $desc = trim($_POST['description'] ?? '');
            $type = ($_POST['type'] ?? '') === 'fixed' ? 'fixed' : 'percent';
            $value = (float) ($_POST['value'] ?? 0);
            $maxDisc = ($_POST['max_discount'] ?? '') !== '' ? (float) $_POST['max_discount'] : null;
            $minPurchase = max(0, (float) ($_POST['min_purchase'] ?? 0));
            $quota = ($_POST['quota'] ?? '') !== '' ? max(0, (int) $_POST['quota']) : null;
            $expires = trim($_POST['expires_at'] ?? '');
            $expiresSql = null;
            if ($expires !== ''){
                $ts = strtotime($expires);
                $expiresSql = $ts ? date('Y-m-d H:i:s', $ts) : false;
            }

            if (!preg_match('/^[A-Z0-9_-]{3,30}$/', $code)){
                $error = 'Kode 3–30 karakter: huruf, angka, strip (-) atau garis bawah (_), tanpa spasi.';
            } elseif ($value <= 0){
                $error = 'Nilai diskon harus lebih dari 0.';
            } elseif ($type === 'percent' && $value > 100){
                $error = 'Diskon persen maksimal 100.';
            } elseif ($expiresSql === false){
                $error = 'Format tanggal kedaluwarsa tidak valid.';
            } else {
                if ($type === 'fixed') $maxDisc = null;
                try {
                    if ($vid){
                        $pdo->prepare("UPDATE vouchers SET code=?, description=?, type=?, value=?, max_discount=?, min_purchase=?, quota=?, expires_at=? WHERE id=?")
                            ->execute([$code, $desc, $type, $value, $maxDisc, $minPurchase, $quota, $expiresSql, $vid]);
                    } else {
                        $pdo->prepare("INSERT INTO vouchers (code, description, type, value, max_discount, min_purchase, quota, expires_at) VALUES (?,?,?,?,?,?,?,?)")
                            ->execute([$code, $desc, $type, $value, $maxDisc, $minPurchase, $quota, $expiresSql]);
                    }
                    header("Location: " . BASE_URL . "/admin/vouchers.php?msg=saved"); exit;
                } catch (PDOException $e){
                    $error = ($e->errorInfo[1] ?? 0) == 1062 ? 'Kode voucher "' . $code . '" sudah dipakai voucher lain.' : 'Database error: ' . $e->getMessage();
                }
                // kembalikan isian ke form kalau gagal
                $edit = ['id'=>$vid,'code'=>$code,'description'=>$desc,'type'=>$type,'value'=>$value,'max_discount'=>$maxDisc,'min_purchase'=>$minPurchase,'quota'=>$quota,'expires_at'=>$expiresSql];
            }
            if (!$edit) $edit = ['id'=>$vid,'code'=>$code,'description'=>$desc,'type'=>$type,'value'=>$_POST['value'] ?? '','max_discount'=>$_POST['max_discount'] ?? '','min_purchase'=>$_POST['min_purchase'] ?? 0,'quota'=>$_POST['quota'] ?? '','expires_at'=>$expires];
        }
    }
}

if ($ready && !$edit && isset($_GET['edit'])){
    $stmt = $pdo->prepare("SELECT * FROM vouchers WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $edit = $stmt->fetch() ?: null;
}

$flash = ['saved' => 'Voucher disimpan.', 'deleted' => 'Voucher dihapus.', 'toggled' => 'Status voucher diubah.'];
if (isset($_GET['msg'], $flash[$_GET['msg']])) $msg = $flash[$_GET['msg']];

$vouchers = $ready ? $pdo->query("SELECT * FROM vouchers ORDER BY is_active DESC, created_at DESC")->fetchAll() : [];

$f = $edit ?: ['id'=>0,'code'=>'','description'=>'','type'=>'percent','value'=>'','max_discount'=>'','min_purchase'=>0,'quota'=>'','expires_at'=>''];
$expiresVal = $f['expires_at'] ? date('Y-m-d\TH:i', strtotime($f['expires_at'])) : '';

$pageTitle = 'Voucher';
$active = 'vouchers';
require __DIR__ . '/../includes/admin_header.php';
?>
<div class="admin-topbar"><h1>Voucher / Kode Promo</h1></div>

<?php if (!$ready): ?>
  <div class="alert alert-error">Fitur voucher belum aktif. Jalankan <code>database/migration_v10.sql</code> di phpMyAdmin, lalu muat ulang halaman ini.</div>
<?php else: ?>
<?php if ($msg): ?><div class="alert alert-success"><?= h($msg) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>

<div class="panel" style="margin-bottom:28px;">
  <div class="panel-head"><h2><?= $f['id'] ? 'Edit Voucher' : 'Buat Voucher Baru' ?></h2></div>
  <form method="post" class="admin-form voucher-admin-form" style="max-width:none; padding:0 22px 22px;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
    <div class="form-grid">
      <div class="form-group"><label>Kode</label><input type="text" name="code" value="<?= h($f['code']) ?>" maxlength="30" style="text-transform:uppercase;" required></div>
      <div class="form-group"><label>Jenis Diskon</label>
        <select name="type">
          <option value="percent" <?= $f['type']==='percent'?'selected':'' ?>>Persen (%)</option>
          <option value="fixed" <?= $f['type']==='fixed'?'selected':'' ?>>Potongan tetap (Rp)</option>
        </select></div>
      <div class="form-group"><label>Nilai (% atau Rp)</label><input type="number" name="value" step="1" min="1" value="<?= h($f['value']) ?>" required></div>
      <div class="form-group"><label>Maks. Potongan (Rp, khusus persen)</label><input type="number" name="max_discount" min="0" step="1" value="<?= h($f['max_discount']) ?>" placeholder="kosong = tanpa batas"></div>
      <div class="form-group"><label>Minimal Belanja (Rp)</label><input type="number" name="min_purchase" min="0" step="1" value="<?= h($f['min_purchase']) ?>"></div>
      <div class="form-group"><label>Kuota (kali pakai)</label><input type="number" name="quota" min="0" step="1" value="<?= h($f['quota']) ?>" placeholder="kosong = tanpa batas"></div>
      <div class="form-group"><label>Berlaku Sampai</label><input type="datetime-local" name="expires_at" value="<?= h($expiresVal) ?>"></div>
      <div class="form-group"><label>Keterangan</label><input type="text" name="description" value="<?= h($f['description']) ?>" maxlength="150"></div>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    <?php if ($f['id']): ?><a href="<?= BASE_URL ?>/admin/vouchers.php" class="btn btn-outline">Batal</a><?php endif; ?>
    <p style="font-size:12.5px; color:var(--gray); margin-top:12px;">Tiap akun hanya bisa memakai satu kode voucher 1 kali. Potongan dihitung dari belanja setelah diskon member, sebelum ongkir.</p>
  </form>
</div>

<div class="panel">
  <table class="data-table">
    <thead><tr><th>Kode</th><th>Diskon</th><th>Min. Belanja</th><th>Terpakai</th><th>Berlaku s/d</th><th>Status</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($vouchers as $v):
        $expired = $v['expires_at'] && strtotime($v['expires_at']) < time();
        $full = $v['quota'] !== null && $v['used_count'] >= $v['quota'];
        if (!$v['is_active']){ $st = ['Nonaktif','badge-diproses']; }
        elseif ($expired){ $st = ['Kedaluwarsa','badge-diproses']; }
        elseif ($full){ $st = ['Kuota habis','badge-diproses']; }
        else { $st = ['Aktif','badge-selesai']; }
      ?>
      <tr>
        <td><strong><?= h($v['code']) ?></strong><?php if ($v['description']): ?><div style="font-size:12px; color:var(--gray);"><?= h($v['description']) ?></div><?php endif; ?></td>
        <td><?= $v['type']==='percent' ? rtrim(rtrim(number_format($v['value'],2,'.',''),'0'),'.') . '%' . ($v['max_discount'] !== null ? ' (maks ' . rupiah($v['max_discount']) . ')' : '') : rupiah($v['value']) ?></td>
        <td><?= rupiah($v['min_purchase']) ?></td>
        <td><?= (int) $v['used_count'] ?><?= $v['quota'] !== null ? ' / ' . (int) $v['quota'] : '' ?></td>
        <td><?= $v['expires_at'] ? date('d M Y H:i', strtotime($v['expires_at'])) : '—' ?></td>
        <td><span class="badge <?= $st[1] ?>"><?= $st[0] ?></span></td>
        <td>
          <div class="action-icons">
            <a class="edit" href="?edit=<?= (int) $v['id'] ?>" title="Edit">✏️</a>
            <form method="post" style="display:contents;"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $v['id'] ?>">
              <button type="submit" class="icon-btn" title="<?= $v['is_active'] ? 'Nonaktifkan' : 'Aktifkan' ?>"><?= $v['is_active'] ? '⏸️' : '▶️' ?></button></form>
            <form method="post" style="display:contents;" onsubmit="return confirm('Hapus voucher ini?');"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $v['id'] ?>">
              <button type="submit" class="icon-btn del" title="Hapus">🗑️</button></form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$vouchers): ?>
      <tr><td colspan="7" style="text-align:center; color:#999;">Belum ada voucher</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
