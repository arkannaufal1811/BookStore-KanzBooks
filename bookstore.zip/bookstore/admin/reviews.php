<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete' && csrf_valid()){
    $pdo->prepare("DELETE FROM reviews WHERE id = ?")->execute([(int) ($_POST['id'] ?? 0)]);
    header("Location: " . BASE_URL . "/admin/reviews.php?msg=deleted" . (isset($_POST['page']) ? '&page=' . (int) $_POST['page'] : ''));
    exit;
}

$perPage = 15;
$page = max(1, (int) ($_GET['page'] ?? 1));
$ratingFilter = (int) ($_GET['rating'] ?? 0);
$where = ''; $params = [];
if ($ratingFilter >= 1 && $ratingFilter <= 5){ $where = 'WHERE r.rating = ?'; $params[] = $ratingFilter; }

$stmt = $pdo->prepare("SELECT COUNT(*) FROM reviews r $where");
$stmt->execute($params);
$totalRows = (int) $stmt->fetchColumn();
$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare("
    SELECT r.*, b.title, u.name AS user_name, u.email
    FROM reviews r JOIN books b ON b.id = r.book_id JOIN users u ON u.id = r.user_id
    $where ORDER BY r.created_at DESC LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$reviews = $stmt->fetchAll();

$pageTitle = 'Ulasan';
$active = 'reviews';
require __DIR__ . '/../includes/admin_header.php';
$qs = $ratingFilter ? 'rating=' . $ratingFilter . '&' : '';
?>
<div class="admin-topbar">
  <h1>Ulasan Pembeli <span style="font-size:15px; color:var(--gray); font-weight:500;">(<?= $totalRows ?>)</span></h1>
  <form method="get" class="filter-inline">
    <select name="rating" onchange="this.form.submit()">
      <option value="0">Semua rating</option>
      <?php for ($i = 5; $i >= 1; $i--): ?><option value="<?= $i ?>" <?= $ratingFilter===$i?'selected':'' ?>><?= str_repeat('★', $i) ?> (<?= $i ?>)</option><?php endfor; ?>
    </select>
  </form>
</div>
<?php if (($_GET['msg'] ?? '') === 'deleted'): ?><div class="alert alert-success">Ulasan dihapus. Rating buku dihitung ulang otomatis.</div><?php endif; ?>

<div class="panel">
  <table class="data-table">
    <thead><tr><th>Buku</th><th>Pembeli</th><th>Rating</th><th>Ulasan</th><th>Tanggal</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($reviews as $r): ?>
      <tr>
        <td><a href="<?= BASE_URL ?>/user/book_detail.php?id=<?= (int) $r['book_id'] ?>" target="_blank" style="font-weight:600;"><?= h($r['title']) ?></a></td>
        <td><?= h($r['user_name']) ?><div style="font-size:12px; color:var(--gray);"><?= h($r['email']) ?></div></td>
        <td style="color:#e0a415; white-space:nowrap;"><?= str_repeat('★', (int) $r['rating']) . str_repeat('☆', 5 - (int) $r['rating']) ?></td>
        <td style="max-width:340px;"><?= $r['comment'] !== null && $r['comment'] !== '' ? nl2br(h($r['comment'])) : '<span style="color:#999;">(tanpa komentar)</span>' ?></td>
        <td style="white-space:nowrap;"><?= date('d M Y', strtotime($r['created_at'])) ?></td>
        <td>
          <form method="post" onsubmit="return confirm('Hapus ulasan ini?');" class="action-icons">
            <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="page" value="<?= $page ?>">
            <button type="submit" class="icon-btn del" title="Hapus ulasan">🗑️</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$reviews): ?>
      <tr><td colspan="6" style="text-align:center; color:#999;">Belum ada ulasan</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination">
  <?php if ($page > 1): ?><a href="?<?= $qs ?>page=<?= $page-1 ?>" class="page-btn">‹ Sebelumnya</a><?php endif; ?>
  <span class="page-btn" style="background:var(--primary); color:#fff; border-color:var(--primary);"><?= $page ?> / <?= $totalPages ?></span>
  <?php if ($page < $totalPages): ?><a href="?<?= $qs ?>page=<?= $page+1 ?>" class="page-btn">Berikutnya ›</a><?php endif; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
