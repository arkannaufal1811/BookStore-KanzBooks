<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

$id = $_GET['id'] ?? null;
if (!$id){ header("Location: " . BASE_URL . "/admin/orders.php"); exit; }

// Endpoint kecil: buat nomor resi otomatis untuk kurir tertentu (dipakai tombol/dropdown di form)
if (isset($_GET['gen_resi'])){
    header('Content-Type: text/plain; charset=utf-8');
    echo generate_resi($pdo, $_GET['gen_resi'], (int) $id);
    exit;
}

pay_expire_unpaid($pdo);   // QRIS lewat batas bayar dibatalkan otomatis
auto_finish_received($pdo);
$proofMsg = '';
$cancelErr = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_proof'])){
    if (empty($_FILES['proof']['name'])){
        $proofMsg = 'Pilih file gambar dulu.';
    } else {
        $ext = strtolower(pathinfo($_FILES['proof']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','webp'])){
            $proofMsg = 'Format harus JPG, PNG, atau WEBP.';
        } else {
            $name = 'bukti_' . uniqid() . '.' . $ext;
            if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0777, true);
            if (move_uploaded_file($_FILES['proof']['tmp_name'], UPLOAD_DIR . $name)){
                upload_backup_save($pdo, $name);
                $pdo->prepare("UPDATE orders SET payment_proof = ? WHERE id = ?")->execute([$name, $id]);
                header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=proof");
                exit;
            }
            $proofMsg = 'Gagal menyimpan file. Cek izin folder uploads.';
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_action']) && cancel_ready($pdo)){
    $act = $_POST['cancel_action'];
    $note = trim($_POST['note'] ?? '');
    $cur = $pdo->prepare("SELECT cancel_status, cancel_reason FROM orders WHERE id = ?");
    $cur->execute([$id]);
    $cur = $cur->fetch() ?: [];
    if ($act === 'admin_cancel'){
        if (strlen($note) < 5){ $cancelErr = 'Alasan pembatalan wajib diisi (minimal 5 huruf).'; }
        else {
            list($ok, $msg) = cancel_order($pdo, $id, 'admin', $note, '');
            if ($ok){ header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=cancelled"); exit; }
            $cancelErr = $msg;
        }
    } elseif ($act === 'approve_cancel'){
        if (($cur['cancel_status'] ?? '') !== 'diajukan'){ $cancelErr = 'Tidak ada pengajuan pembatalan yang menunggu.'; }
        else {
            list($ok, $msg) = cancel_order($pdo, $id, 'disetujui', $cur['cancel_reason'] ?? '', $note);
            if ($ok){ header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=approved"); exit; }
            $cancelErr = $msg;
        }
    } elseif ($act === 'reject_cancel'){
        if (strlen($note) < 5){ $cancelErr = 'Alasan penolakan wajib diisi (minimal 5 huruf).'; }
        else {
            $pdo->prepare("UPDATE orders SET cancel_status = 'ditolak', cancel_note = ? WHERE id = ? AND cancel_status = 'diajukan'")
                ->execute([mb_substr_safe($note, 255), $id]);
            header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=rejected"); exit;
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_pay'])){
    // ===== QRIS: admin sudah melihat dana masuk (notifikasi e-wallet) -> pembayaran dikonfirmasi =====
    if (!csrf_valid()){
        $cancelErr = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } else {
        list($ok, $msg) = pay_confirm($pdo, $id);
        if ($ok){ header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=paid"); exit; }
        $cancelErr = $msg;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_shipping'])){
    if (db_has_column($pdo, 'orders', 'courier')){
        $courier = trim($_POST['courier'] ?? '');
        $resi = trim($_POST['tracking_no'] ?? '');
        if ($courier !== '' && $resi === '') $resi = generate_resi($pdo, $courier, (int) $id);   // otomatis kalau dikosongkan
        $pdo->prepare("UPDATE orders SET courier = ?, tracking_no = ? WHERE id = ?")
            ->execute([$courier !== '' ? $courier : null, $resi !== '' ? $resi : null, $id]);
    }
    header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=shipping");
    exit;
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_action']) && return_ready($pdo)){
    // ===== Pengembalian barang: setujui / tolak pengajuan pembeli =====
    if (!csrf_valid()){
        $cancelErr = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } else {
        $act = $_POST['return_action'];
        $note = trim($_POST['note'] ?? '');
        if ($act === 'approve_return'){
            list($ok, $msg) = approve_return($pdo, $id, $note, !empty($_POST['restock']));
            if ($ok){ header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=return_approved"); exit; }
            $cancelErr = $msg;
        } elseif ($act === 'reject_return'){
            if (strlen($note) < 5){ $cancelErr = 'Alasan penolakan wajib diisi (minimal 5 huruf) supaya pembeli tahu.'; }
            else {
                list($ok, $msg) = reject_return($pdo, $id, $note);
                if ($ok){ header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=return_rejected"); exit; }
                $cancelErr = $msg;
            }
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST'){
    // ===== Ubah status: HANYA maju satu langkah (Baru > Diproses > Dikirim > Selesai), tidak bisa mundur =====
    if (!csrf_valid()){
        $cancelErr = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } else {
        list($ok, $msg) = advance_order_status($pdo, $id, $_POST['status'] ?? '');
        if ($ok){ header("Location: " . BASE_URL . "/admin/order_detail.php?id=$id&msg=saved"); exit; }
        $cancelErr = $msg;
    }
}

$stmt = $pdo->prepare("SELECT o.*, u.name AS nama_pemesan, u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE o.id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order){ header("Location: " . BASE_URL . "/admin/orders.php"); exit; }

$stmt = $pdo->prepare("SELECT oi.*, b.title FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = ?");
$stmt->execute([$id]);
$items = $stmt->fetchAll();

$warInfo = null;
if (!empty($order['war_id']) && war_ready($pdo)) $warInfo = war_get($pdo, $order['war_id']);

$pageTitle = 'Detail Pesanan';
$active = 'orders';
require __DIR__ . '/../includes/admin_header.php';
?>
<div class="admin-topbar">
  <h1>Detail Pesanan #<?= $order['id'] ?></h1>
  <div style="display:flex; gap:8px; flex-wrap:wrap;">
    <a href="<?= BASE_URL ?>/struk.php?id=<?= $order['id'] ?>&doc=label" target="_blank" class="btn btn-primary">🏷️ Cetak Label Pengiriman (penjual)</a>
    <a href="<?= BASE_URL ?>/struk.php?id=<?= $order['id'] ?>" target="_blank" class="btn btn-outline">🧾 Invoice Pembeli</a>
    <a href="<?= BASE_URL ?>/admin/chat.php?user=<?= (int) $order['user_id'] ?>&order=<?= (int) $order['id'] ?>" class="btn btn-outline">💬 Chat Pembeli</a>
  </div>
</div>
<?php if ($warInfo): ?>
  <div class="alert alert-success" style="background:#f3d1fb; color:#6b1b8c;">⚡ Pesanan War Buku: <?= h($warInfo['title']) ?>. Kalau pesanan ini dibatalkan, stok dikembalikan ke stok war (bukan stok toko biasa).</div>
<?php endif; ?>

<?php if (($_GET['msg'] ?? '') === 'cancelled'): ?><div class="alert alert-success">Pesanan dibatalkan. Stok buku sudah dikembalikan.</div>
<?php elseif (($_GET['msg'] ?? '') === 'approved'): ?><div class="alert alert-success">Pembatalan disetujui. Pesanan dibatalkan dan stok buku dikembalikan.</div>
<?php elseif (($_GET['msg'] ?? '') === 'rejected'): ?><div class="alert alert-success">Pengajuan pembatalan ditolak. Pesanan tetap berjalan.</div>
<?php elseif (($_GET['msg'] ?? '') === 'shipping'): ?><div class="alert alert-success">Info pengiriman disimpan.</div>
<?php elseif (($_GET['msg'] ?? '') === 'paid'): ?><div class="alert alert-success">Pembayaran QRIS dikonfirmasi. Pesanan sekarang bisa diproses.</div>
<?php elseif (($_GET['msg'] ?? '') === 'proof'): ?><div class="alert alert-success">Bukti transfer disimpan.</div>
<?php elseif (($_GET['msg'] ?? '') === 'return_approved'): ?><div class="alert alert-success">Pengembalian disetujui. Status pesanan menjadi Dikembalikan. Jangan lupa kembalikan dana ke pembeli.</div>
<?php elseif (($_GET['msg'] ?? '') === 'return_rejected'): ?><div class="alert alert-success">Pengajuan pengembalian ditolak. Pembeli akan melihat alasannya.</div>
<?php elseif (isset($_GET['msg'])): ?><div class="alert alert-success">Status pesanan diperbarui.</div><?php endif; ?>
<?php if ($cancelErr): ?><div class="alert alert-error"><?= h($cancelErr) ?></div><?php endif; ?>
<?php if ($proofMsg): ?><div class="alert alert-error"><?= h($proofMsg) ?></div><?php endif; ?>

<div class="panel" style="margin-bottom:24px;">
  <div class="panel-head"><h2>Informasi Pemesan</h2></div>
  <div style="padding:0 22px 22px;">
    <p><strong>Nama Akun:</strong> <?= h($order['nama_pemesan']) ?></p>
    <?php if (!empty($order['shipping_name'])): ?><p><strong>Nama Penerima:</strong> <?= h($order['shipping_name']) ?></p><?php endif; ?>
    <p><strong>Email:</strong> <?= h($order['email']) ?></p>
    <?php if (!empty($order['shipping_phone'])): ?>
      <p><strong>No. HP Penerima:</strong> <a href="https://wa.me/<?= '62' . substr(h($order['shipping_phone']), 1) ?>" target="_blank"><?= h($order['shipping_phone']) ?></a></p>
    <?php endif; ?>
    <p><strong>Alamat Pengiriman:</strong> <?= nl2br(h($order['shipping_address'])) ?></p>

    <?php if (db_has_column($pdo, 'orders', 'courier')): ?>
    <form method="post" style="margin:12px 0; padding:12px 14px; background:#faf5fb; border-radius:10px;">
      <input type="hidden" name="save_shipping" value="1">
      <label style="font-size:13px; font-weight:700;">Info Pengiriman (tampil di label &amp; invoice pembeli)</label>
      <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:6px;">
        <?php $couriers = ['JNE','J&T Express','SiCepat','AnterAja','Pos Indonesia','Ninja Xpress','Gojek / Grab Instant','Kurir Toko']; ?>
        <select name="courier" id="courierSel" style="padding:8px 10px; border:1.5px solid #ccc; border-radius:8px;">
          <option value="">-- Pilih kurir --</option>
          <?php foreach ($couriers as $c): ?>
            <option value="<?= h($c) ?>" <?= ($order['courier'] ?? '') === $c ? 'selected' : '' ?>><?= h($c) ?></option>
          <?php endforeach; ?>
        </select>
        <input type="text" name="tracking_no" id="resiInput" value="<?= h($order['tracking_no'] ?? '') ?>" placeholder="Nomor resi (otomatis)" style="padding:8px 10px; border:1.5px solid #ccc; border-radius:8px; min-width:200px;">
        <button type="button" id="resiRand" class="btn btn-outline" style="padding:6px 12px;" title="Acak ulang nomor resi">🎲 Acak</button>
        <button type="submit" class="btn btn-outline" style="padding:6px 14px;">Simpan</button>
      </div>
      <p style="font-size:12px; color:#888; margin-top:6px;">Nomor resi terisi otomatis saat kurir dipilih (format beda tiap kurir) dan bisa diubah manual. Ini nomor contoh dari sistem, bukan resi asli kurir.</p>
    </form>
    <script>
    (function(){
      var sel = document.getElementById('courierSel'), inp = document.getElementById('resiInput'), btn = document.getElementById('resiRand');
      var auto = inp.value === '';   // resi kosong = boleh diisi otomatis
      function gen(){
        if (!sel.value){ return; }
        fetch('?id=<?= (int) $order['id'] ?>&gen_resi=' + encodeURIComponent(sel.value))
          .then(function(r){ return r.text(); })
          .then(function(t){ inp.value = t.trim(); auto = true; });
      }
      sel.addEventListener('change', function(){ if (auto || inp.value === '') gen(); });
      btn.addEventListener('click', function(){ if (!sel.value){ alert('Pilih kurir dulu.'); return; } gen(); });
      inp.addEventListener('input', function(){ auto = false; });
    })();
    </script>
    <?php else: ?>
      <p style="color:#a51c1c; font-size:13px;">⚠️ Jalankan <code>database/migration_v9.sql</code> untuk mengaktifkan nomor HP, kurir &amp; resi.</p>
    <?php endif; ?>
    <p><strong>Metode Pembayaran:</strong> <?= h($order['payment_method']) ?></p>
    <?php if (!empty($order['payment_proof'])): ?>
      <p><strong>Bukti Transfer:</strong></p>
      <?php if (upload_ensure($pdo, $order['payment_proof'])): ?>
        <a href="<?= UPLOAD_URL . h(basename($order['payment_proof'])) ?>" target="_blank">
          <img src="<?= UPLOAD_URL . h(basename($order['payment_proof'])) ?>" alt="Bukti Transfer" style="max-width:280px; border-radius:8px; border:1.5px solid var(--border); margin-top:6px;">
        </a>
        <p style="font-size:12.5px; color:var(--gray); margin-top:4px;">Klik gambar untuk lihat ukuran penuh</p>
      <?php else: ?>
        <p style="color:#a51c1c;">⚠️ File gambar <code><?= h($order['payment_proof']) ?></code> tidak ditemukan di folder <code>uploads/</code> (kemungkinan terhapus saat file project ditimpa). Kalau masih ada backup, copy lagi file itu ke folder uploads.</p>
      <?php endif; ?>
    <?php elseif (!empty($order['pay_status'])): ?>
      <p style="color:#555;">QRIS dinamis: tanpa bukti upload, konfirmasi lewat notifikasi dana masuk (lihat panel Pembayaran QRIS di bawah).</p>
    <?php elseif ((stripos($order['payment_method'], 'transfer') !== false || stripos($order['payment_method'], 'qris') !== false)): ?>
      <p style="color:#a51c1c;"><strong>⚠️ Belum ada bukti transfer diupload.</strong></p>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" style="margin:10px 0;">
      <input type="hidden" name="upload_proof" value="1">
      <label style="font-size:13px; font-weight:700;">Pasang / ganti gambar bukti transfer:</label><br>
      <input type="file" name="proof" accept="image/jpeg,image/png,image/webp">
      <button type="submit" class="btn btn-outline" style="padding:6px 14px;">Simpan Bukti</button>
    </form>
    <p><strong>Tanggal:</strong> <?= date('d F Y H:i', strtotime($order['order_date'])) ?></p>
  </div>
</div>

<?php if (!empty($order['pay_status'])): $ps = $order['pay_status']; ?>
<div class="panel" style="padding:16px 18px; margin-bottom:24px; border:1.5px solid <?= $ps === 'menunggu' ? '#e0b400' : '#222' ?>;">
  <h3 style="margin-bottom:8px;">Pembayaran QRIS</h3>
  <?php if ($ps === 'menunggu' && $order['status'] === 'Baru'): ?>
    <div class="alert alert-error" style="margin-bottom:12px; background:#fff3cd; color:#6b5400;">
      <strong>Menunggu pembayaran.</strong> Nominal yang harus masuk: <strong><?= rupiah($order['total']) ?></strong> (pas, QR-nya terkunci).
      Batas bayar: <strong><?= !empty($order['pay_expires_at']) ? date('d F Y H:i', strtotime($order['pay_expires_at'])) : '-' ?> WIB</strong>, setelah itu pesanan batal otomatis.
    </div>
    <p style="font-size:13px; color:#555; margin-bottom:10px;">Buka aplikasi penerima QRIS (DANA Bisnis / e-wallet toko), cek ada dana masuk <strong><?= rupiah($order['total']) ?></strong> sekitar waktu pesanan dibuat (<?= date('H:i', strtotime($order['order_date'])) ?> WIB). Kalau sudah ada, tekan tombol di bawah. Pesanan <u>tidak bisa diproses</u> sebelum ini.</p>
    <form method="post" onsubmit="return confirm('Pastikan dana <?= h(rupiah($order['total'])) ?> benar-benar sudah masuk. Lanjut konfirmasi?');">
      <?= csrf_field() ?>
      <button type="submit" name="confirm_pay" value="1" class="btn btn-primary">✔ Pembayaran Diterima (<?= h(rupiah($order['total'])) ?>)</button>
    </form>
  <?php elseif ($ps === 'dibayar'): ?>
    <p style="color:#1a7f37;"><strong>Pembayaran sudah dikonfirmasi</strong><?= !empty($order['paid_at']) ? ' pada ' . date('d F Y H:i', strtotime($order['paid_at'])) : '' ?>.</p>
  <?php elseif ($ps === 'kedaluwarsa'): ?>
    <p style="color:#a51c1c;"><strong>Kedaluwarsa:</strong> pembayaran tidak masuk sebelum batas waktu, pesanan dibatalkan otomatis dan stok dikembalikan. Kalau ternyata pembeli sudah bayar, kembalikan dananya atau minta pembeli memesan ulang.</p>
  <?php else: ?>
    <p style="color:#a51c1c;">Pesanan dibatalkan sebelum dibayar.</p>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="panel" style="margin-bottom:24px;">
  <table class="data-table">
    <thead><tr><th>Buku</th><th>Qty</th><th>Harga</th><th>Subtotal</th></tr></thead>
    <tbody>
      <?php foreach ($items as $it): ?>
      <tr>
        <td><?= h($it['title']) ?></td>
        <td><?= $it['qty'] ?></td>
        <td><?= rupiah($it['price']) ?></td>
        <td><?= rupiah($it['price'] * $it['qty']) ?></td>
      </tr>
      <?php endforeach; ?>
      <tr><td colspan="3" style="text-align:right; font-weight:800;">Total</td><td style="font-weight:800;"><?= rupiah($order['total']) ?></td></tr>
    </tbody>
  </table>
</div>

<?php if (cancel_ready($pdo)): $cs = $order['cancel_status'] ?? ''; $canCancel = in_array($order['status'], ['Baru','Diproses'], true); ?>
<div class="panel" style="padding:16px 18px; margin-bottom:16px; border:1.5px solid <?= $order['status'] === 'Dibatalkan' ? '#c0392b' : '#222' ?>;">
  <h3 style="margin-bottom:8px;">Pembatalan Pesanan</h3>
  <?php if ($order['status'] === 'Dibatalkan'): ?>
    <p style="color:#a51c1c;"><strong>Pesanan ini dibatalkan</strong> <?= $cs === 'admin' ? 'oleh admin' : 'atas permintaan pembeli (disetujui admin)' ?><?= !empty($order['cancelled_at']) ? ' pada ' . date('d F Y H:i', strtotime($order['cancelled_at'])) : '' ?>.</p>
    <p><strong>Alasan:</strong> <?= h($order['cancel_reason'] ?? '-') ?></p>
    <?php if (!empty($order['cancel_note'])): ?><p><strong>Catatan admin:</strong> <?= h($order['cancel_note']) ?></p><?php endif; ?>
    <p style="font-size:12.5px; color:#888;">Stok buku sudah dikembalikan dan pesanan tidak masuk laporan penjualan.</p>
  <?php else: ?>
    <?php if ($cs === 'diajukan'): ?>
      <div class="alert alert-error" style="margin-bottom:12px;">
        <strong>Pembeli mengajukan pembatalan.</strong><br>Alasan: <?= h($order['cancel_reason'] ?? '-') ?>
      </div>
      <form method="post">
        <textarea name="note" rows="2" placeholder="Catatan untuk pembeli (wajib diisi kalau menolak)" style="width:100%; padding:10px; border:1.5px solid #ccc; border-radius:8px; margin-bottom:8px;"></textarea>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <?php if ($canCancel): ?><button type="submit" name="cancel_action" value="approve_cancel" class="btn btn-primary" onclick="return confirm('Setujui pembatalan? Pesanan dibatalkan dan stok dikembalikan.');">Setujui Pembatalan</button><?php endif; ?>
          <button type="submit" name="cancel_action" value="reject_cancel" class="btn btn-outline">Tolak Pengajuan</button>
        </div>
      </form>
    <?php else: ?>
      <?php if ($cs === 'ditolak'): ?><p style="color:#96730a; margin-bottom:8px;">Pengajuan pembatalan pembeli sebelumnya <strong>ditolak</strong><?= !empty($order['cancel_note']) ? ': ' . h($order['cancel_note']) : '' ?>.</p><?php endif; ?>
      <?php if ($canCancel): ?>
        <p style="font-size:13px; color:#666; margin-bottom:8px;">Batalkan kalau bukti transfer atau informasi pesanan tidak valid. Pembeli akan melihat alasannya.</p>
        <form method="post" onsubmit="return confirm('Batalkan pesanan ini? Stok buku akan dikembalikan.');">
          <input type="hidden" name="cancel_action" value="admin_cancel">
          <textarea name="note" rows="2" required placeholder="Alasan pembatalan, misal: bukti transfer tidak sesuai nominal" style="width:100%; padding:10px; border:1.5px solid #ccc; border-radius:8px; margin-bottom:8px;"></textarea>
          <button type="submit" class="btn btn-outline" style="border-color:#c0392b; color:#c0392b;">Batalkan Pesanan</button>
        </form>
      <?php else: ?>
        <p style="color:#888; font-size:13px;">Pesanan berstatus <?= h($order['status']) ?> tidak bisa dibatalkan lagi.</p>
      <?php endif; ?>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if (return_ready($pdo)): $rs = $order['return_status'] ?? ''; $dl = return_days_left($order); ?>
  <?php if ($order['status'] === 'Selesai' || $rs !== '' || ($order['status'] === 'Dikirim' && !empty($order['received_at']))): ?>
  <div class="panel" style="padding:16px 18px; margin-bottom:16px; border:1.5px solid <?= $rs === 'diajukan' ? '#c0392b' : '#222' ?>;">
    <h3 style="margin-bottom:8px;">Pengembalian Dana dan Barang</h3>
    <?php if ($rs === 'diajukan'): ?>
      <div class="alert alert-error" style="margin-bottom:12px;">
        <strong>Pembeli mengajukan pengembalian</strong><?= !empty($order['return_requested_at']) ? ' pada ' . date('d F Y H:i', strtotime($order['return_requested_at'])) : '' ?>.<br>
        Alasan: <?= h($order['return_reason'] ?? '-') ?>
      </div>
      <p style="font-weight:700;">Bukti 1: kondisi barang</p>
      <?= proof_media_html($pdo, $order['return_proof'] ?? '') ?>
      <p style="font-weight:700;">Bukti 2: nomor resi pengembalian</p>
      <?= proof_media_html($pdo, $order['return_proof_resi'] ?? '') ?>
      <form method="post" style="margin-top:10px;">
        <?= csrf_field() ?>
        <textarea name="note" rows="2" maxlength="200" placeholder="Catatan untuk pembeli (wajib diisi kalau menolak)" style="width:100%; padding:10px; border:1.5px solid #ccc; border-radius:8px; margin-bottom:8px;"></textarea>
        <label style="display:block; font-size:13px; margin-bottom:10px;"><input type="checkbox" name="restock" value="1"> Kembalikan stok buku (centang hanya kalau barang retur masih layak dijual lagi)</label>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button type="submit" name="return_action" value="approve_return" class="btn btn-primary" onclick="return confirm('Setujui pengembalian? Status pesanan menjadi Dikembalikan dan tidak bisa diubah lagi.');">Setujui Pengembalian</button>
          <button type="submit" name="return_action" value="reject_return" class="btn btn-outline">Tolak Pengajuan</button>
        </div>
        <p style="font-size:12.5px; color:#96730a; margin-top:8px;">💸 Kalau disetujui, kembalikan dana ke pembeli secara manual (hubungi lewat WhatsApp).</p>
      </form>
    <?php elseif ($rs === 'disetujui' || $order['status'] === 'Dikembalikan'): ?>
      <p style="color:#5b2a86;"><strong>Pengembalian disetujui</strong><?= !empty($order['return_resolved_at']) ? ' pada ' . date('d F Y H:i', strtotime($order['return_resolved_at'])) : '' ?>. Pesanan tidak masuk laporan penjualan.</p>
      <p><strong>Alasan pembeli:</strong> <?= h($order['return_reason'] ?? '-') ?></p>
      <?php if (!empty($order['return_note'])): ?><p><strong>Catatan admin:</strong> <?= h($order['return_note']) ?></p><?php endif; ?>
      <p style="font-weight:700;">Bukti 1: kondisi barang</p>
      <?= proof_media_html($pdo, $order['return_proof'] ?? '') ?>
      <p style="font-weight:700;">Bukti 2: nomor resi pengembalian</p>
      <?= proof_media_html($pdo, $order['return_proof_resi'] ?? '') ?>
    <?php elseif ($rs === 'ditolak'): ?>
      <p style="color:#96730a;"><strong>Pengajuan pengembalian ditolak</strong><?= !empty($order['return_note']) ? ': ' . h($order['return_note']) : '' ?>.</p>
      <p><strong>Alasan pembeli:</strong> <?= h($order['return_reason'] ?? '-') ?></p>
      <?= proof_media_html($pdo, $order['return_proof'] ?? '') ?>
      <?= proof_media_html($pdo, $order['return_proof_resi'] ?? '') ?>
    <?php elseif ($order['status'] === 'Dikirim'): ?>
      <p style="font-size:13px; color:#666;">Pembeli sudah menekan <strong>Diterima</strong><?= !empty($order['received_at']) ? ' pada ' . date('d F Y H:i', strtotime($order['received_at'])) : '' ?>. Menunggu pembeli memilih Selesai atau Pengembalian<?= $dl !== null ? ' (sisa ' . (int) $dl . ' hari, lewat itu otomatis Selesai)' : '' ?>.</p>
    <?php else: ?>
      <p style="font-size:13px; color:#888;">Tidak ada pengajuan pengembalian. Pesanan yang sudah Selesai tidak bisa dikembalikan lagi.</p>
    <?php endif; ?>
  </div>
  <?php endif; ?>
<?php endif; ?>

<?php $next = order_next_status($order['status']); $recv = ($order['status'] === 'Dikirim' && !empty($order['received_at'])); ?>
<div class="panel" style="padding:16px 18px; margin-bottom:16px;">
  <h3 style="margin-bottom:8px;">Status Pesanan</h3>
  <p style="font-size:13px; color:#666; margin-bottom:8px;">
    <?= !empty($order['shipped_at']) ? 'Dikirim: ' . date('d F Y H:i', strtotime($order['shipped_at'])) . '. ' : '' ?>
    <?= !empty($order['completed_at']) ? 'Selesai: ' . date('d F Y H:i', strtotime($order['completed_at'])) . '.' : '' ?>
  </p>
  <?php if ($recv): ?>
    <p>Barang sudah <strong>diterima</strong> pada <?= date('d F Y H:i', strtotime($order['received_at'])) ?>. Menunggu pembeli memilih <strong>Selesai</strong> atau <strong>Pengembalian Dana dan Barang</strong>.</p>
    <a href="<?= BASE_URL ?>/admin/orders.php" class="btn btn-outline" style="margin-top:10px;">Kembali</a>
  <?php elseif ($next === null): ?>
    <p>Status <strong><?= h($order['status']) ?></strong> sudah <strong>final dan tidak bisa diubah lagi</strong>.</p>
    <p style="font-size:13px; color:#666; margin-top:6px;">Kalau ada masalah: sebelum Dikirim, pakai <em>Batalkan Pesanan</em>. Pengembalian hanya bisa diajukan pembeli sebelum menekan Selesai (dengan bukti); kamu menyetujui atau menolaknya di panel Pengembalian Dana dan Barang.</p>
  <?php else: ?>
    <p>Status sekarang: <strong><?= h($order['status']) ?></strong>. Status hanya bisa <strong>maju satu langkah</strong> dan tidak bisa dimundurkan.</p>
    <?php if ($next === 'Diproses' && ($order['pay_status'] ?? '') === 'menunggu'): ?>
      <p style="margin-top:10px; color:#96730a;"><strong>Belum bisa diproses:</strong> pembayaran QRIS belum dikonfirmasi.</p>
      <a href="<?= BASE_URL ?>/admin/orders.php" class="btn btn-outline">Kembali</a>
    <?php else: ?>
    <form method="post" style="margin-top:10px;" onsubmit="return confirm('<?= $next === 'Selesai' ? 'Tandai barang sudah diterima pembeli?' : 'Ubah status ke ' . h($next) . '?' ?> Setelah ini tidak bisa dimundurkan.');">
      <?= csrf_field() ?><input type="hidden" name="status" value="<?= h($next) ?>">
      <button type="submit" class="btn btn-primary">➡ Tandai <?= $next === 'Selesai' ? 'Diterima' : h($next) ?></button>
      <a href="<?= BASE_URL ?>/admin/orders.php" class="btn btn-outline">Kembali</a>
    </form>
    <?php endif; ?>
    <?php if ($next === 'Dikirim'): ?><p style="font-size:12.5px; color:#96730a; margin-top:8px;">Pastikan kurir dan nomor resi sudah disimpan di kotak Info Pengiriman. Setelah Dikirim, pesanan tidak bisa dibatalkan lagi.</p><?php endif; ?>
    <?php if ($next === 'Selesai'): ?><p style="font-size:12.5px; color:#96730a; margin-top:8px;">Biasanya pembeli yang menekan "Pesanan Diterima". Kalau kamu tandai Diterima, pembeli tetap bisa memilih <strong>Selesai</strong> atau <strong>Pengembalian Dana dan Barang</strong> (dengan bukti). Pesanan baru berstatus Selesai setelah pembeli menekan Selesai (atau otomatis kalau <?= RETURN_WINDOW_DAYS ?> hari lewat), dan setelah itu tidak bisa dikembalikan.</p><?php endif; ?>
  <?php endif; ?>
</div>
<?php if ($next === null && !$recv): ?><a href="<?= BASE_URL ?>/admin/orders.php" class="btn btn-outline">Kembali</a><?php endif; ?>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
