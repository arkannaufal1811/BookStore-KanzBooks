<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
$ready = chat_ready($pdo);

$threads = $ready ? chat_threads($pdo) : [];
$tid = (int) ($_GET['user'] ?? 0);
if (!$tid && $threads){                       // belum memilih: buka yang ada pesan belum dibaca, kalau tidak yang terbaru
    foreach ($threads as $t){ if ($t['unread'] > 0){ $tid = (int) $t['id']; break; } }
    if (!$tid) $tid = (int) $threads[0]['id'];
}
$buyer = null;
if ($ready && $tid){
    $bs = $pdo->prepare("SELECT id, name, email FROM users WHERE id = ? AND role <> 'admin'");
    $bs->execute([$tid]);
    $buyer = $bs->fetch() ?: null;
}
if (!$buyer) $tid = 0;

// Kirim lewat form biasa (cadangan kalau JavaScript mati; normalnya lewat chat.js)
$error = '';
if ($buyer && $_SERVER['REQUEST_METHOD'] === 'POST'){
    if (($_SERVER['CONTENT_LENGTH'] ?? 0) > 0 && empty($_POST) && empty($_FILES)){
        $error = 'Foto terlalu besar untuk server (post_max_size di php.ini).';
    } elseif (!csrf_valid()){
        $error = 'Sesi form kedaluwarsa, muat ulang halaman lalu coba lagi.';
    } else {
        list($okImg, $img) = chat_save_image($pdo, 'image');
        if (!$okImg){ $error = $img; }
        else {
            list($ok, $res) = chat_send($pdo, $tid, 'admin', $_POST['message'] ?? '', (int) ($_POST['order_id'] ?? 0) ?: null, $img);
            if ($ok){ header("Location: " . BASE_URL . "/admin/chat.php?user=$tid"); exit; }
            if ($img) @unlink(UPLOAD_DIR . $img);
            $error = $res;
        }
    }
}

$msgs = []; $orders = [];
if ($buyer){
    $msgs = array_map(function($r){ return chat_format($r, 'admin'); }, chat_fetch($pdo, $tid, 0));
    chat_mark_read($pdo, $tid, 'admin');
    foreach ($threads as &$t){ if ((int) $t['id'] === $tid) $t['unread'] = 0; } unset($t);
    $st = $pdo->prepare("SELECT o.id, o.status, o.total FROM orders o WHERE o.user_id = ? ORDER BY o.id DESC LIMIT 10");
    $st->execute([$tid]);
    $orders = $st->fetchAll();
}
$preOrder = (int) ($_GET['order'] ?? 0);
if ($preOrder && !in_array($preOrder, array_map('intval', array_column($orders, 'id')), true)) $preOrder = 0;
$last = $msgs ? end($msgs) : null;
$initial = $buyer ? strtoupper(mb_substr_safe(trim($buyer['name']), 1)) : '?';
$emojis = ['😊','😀','🙏','👍','👌','🙌','😅','❤️','🎉','📚','📦','🚚','✅','❗'];
$quick = ['Terima kasih sudah berbelanja ya!', 'Pesanan kamu sedang kami proses ya.', 'Mohon kirim foto atau video buktinya ya.', 'Maaf atas ketidaknyamanannya, kami bantu cek dulu ya.'];

$pageTitle = 'Chat';
$active = 'chat';
require __DIR__ . '/../includes/admin_header.php';
?>
<div class="admin-topbar"><h1>Chat Pembeli</h1></div>
<?php if (!$ready): ?><div class="alert alert-error">⚠️ Jalankan <code>database/migration_v13.sql</code> untuk mengaktifkan fitur chat.</div><?php endif; ?>

<div class="chat-admin">
  <div class="chat-list">
    <?php foreach ($threads as $t): ?>
      <a href="<?= BASE_URL ?>/admin/chat.php?user=<?= (int) $t['id'] ?>" class="<?= (int) $t['id'] === $tid ? 'on' : '' ?>">
        <span class="nm"><span><?= h($t['name']) ?></span><?= $t['unread'] > 0 ? '<i class="un">' . (int) $t['unread'] . '</i>' : '' ?></span>
        <span class="sn"><?= h(chat_snippet($t)) ?></span>
        <span class="tm"><?= h(time_ago(strtotime($t['last_at']))) ?></span>
      </a>
    <?php endforeach; ?>
    <?php if (!$threads): ?><p class="chat-list-empty">Belum ada percakapan. Pembeli bisa memulai lewat menu Pesan di toko, atau kamu bisa membuka chat dari halaman detail pesanan.</p><?php endif; ?>
  </div>

  <div class="chat-card">
  <?php if (!$buyer): ?>
    <div class="chat-empty" style="padding:60px 20px;">Pilih percakapan di sebelah kiri.</div>
  <?php else: ?>
    <div class="chat-head">
      <span class="ch-avatar init"><?= h($initial) ?></span>
      <div class="ch-title"><b><?= h($buyer['name']) ?></b><small><?= h($buyer['email']) ?></small></div>
    </div>
    <div class="chat-box" id="chat-box"
         data-api="<?= BASE_URL ?>/chat_api.php" data-me="admin" data-thread="<?= $tid ?>" data-initial="<?= h($initial) ?>" data-avatar=""
         data-after="<?= $last ? (int) $last['id'] : 0 ?>" data-last-ts="<?= $last ? (int) $last['ts'] : 0 ?>" data-last-date="<?= $last ? h($last['date']) : '' ?>">
      <?= chat_render_list($msgs, '<span class="msg-av init">' . h($initial) . '</span>') ?>
      <div class="chat-empty" id="chat-empty" <?= $msgs ? 'hidden' : '' ?>>Belum ada pesan dengan <?= h($buyer['name']) ?>.<br>Kirim pesan pertama di bawah.</div>
    </div>
    <button type="button" id="chat-latest" class="chat-latest" hidden>&#8964; Lihat yang paling baru</button>
    <div id="chat-error" class="chat-error" <?= $error ? '' : 'hidden' ?>><?= h($error) ?></div>

    <form id="chat-form" method="post" enctype="multipart/form-data" class="chat-form">
      <?= csrf_field() ?>
      <input type="hidden" name="order_id" id="chat-order-id" value="<?= $preOrder ?: '' ?>">
      <div class="chat-chips">
        <?php foreach ($quick as $q): ?><button type="button" class="chip qr" data-text="<?= h($q) ?>"><?= h($q) ?></button><?php endforeach; ?>
        <button type="button" class="chip" id="chip-order">&#129534; Kirim pesanan</button>
      </div>
      <div id="order-pick" class="order-pick" hidden>
        <select id="order-select">
          <option value="">-- Pilih pesanan pembeli --</option>
          <?php foreach ($orders as $o): $lbl = '#' . str_pad($o['id'], 5, '0', STR_PAD_LEFT); ?>
            <option value="<?= (int) $o['id'] ?>" data-label="<?= h($lbl) ?>" <?= $preOrder === (int) $o['id'] ? 'selected' : '' ?>><?= h($lbl . ' · ' . $o['status'] . ' · ' . rupiah($o['total'])) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (!$orders): ?><small>Pembeli ini belum punya pesanan.</small><?php endif; ?>
      </div>
      <div id="chat-attach" class="chat-attach"></div>
      <div class="chat-bar">
        <textarea name="message" id="chat-text" rows="1" maxlength="1000" placeholder="Balas pembeli…"></textarea>
        <button type="button" class="cb-btn" id="btn-emoji" aria-label="Emoji">&#128522;</button>
        <button type="button" class="cb-btn" id="btn-plus" aria-label="Lampirkan foto">&#65291;</button>
        <button type="submit" class="cb-send" aria-label="Kirim">&#10148;</button>
        <input type="file" name="image" id="chat-file" accept="image/jpeg,image/png,image/webp" hidden>
      </div>
      <div class="emoji-pop" id="emoji-pop" hidden>
        <?php foreach ($emojis as $e): ?><button type="button" data-emoji="<?= $e ?>"><?= $e ?></button><?php endforeach; ?>
      </div>
    </form>
  <?php endif; ?>
  </div>
</div>
<?php if ($buyer): ?><script src="<?= BASE_URL ?>/assets/js/chat.js"></script><?php endif; ?>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
